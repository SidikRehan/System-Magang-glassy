<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;

class OrderController extends Controller
{
    /**
     * Store New Order (Admin Toko - Multi Item Kaca Specification)
     */
    public function storeOrder(Request $request)
    {
        $validated = $request->validate([
            'order_date' => 'nullable|date',
            'customer_name' => 'required|string',
            'customer_phone' => 'required|string',
            'customer_address' => 'required|string',
            'glass_type' => 'nullable|string',
            'length_cm' => 'nullable',
            'width_cm' => 'nullable',
            'thickness_mm' => 'nullable',
            'processes' => 'nullable|array',
            'items' => 'nullable|array',
            'accessories' => 'nullable|array',
            'description' => 'nullable|string',
            'sketch_photo' => 'nullable|image|mimes:jpeg,png,jpg,webp|max:5120',
            'priority_status' => 'required|string',
            'priority_fee' => 'nullable|numeric',
            'custom_fee' => 'nullable|numeric',
            'deadline_date' => 'nullable|date',
            'used_scrap_rak' => 'nullable|string',
            'status' => 'nullable|string|in:draft,pengerjaan',
            'is_company_use' => 'nullable|boolean',
        ]);

        $isCompanyUse = (bool)$request->input('is_company_use', false);

        $targetStatus = $validated['status'] ?? 'pengerjaan';
        $isDraft = ($targetStatus === 'draft');

        $latestOrder = Order::orderBy('id', 'desc')->first();
        $nextId = $latestOrder ? ($latestOrder->id + 1) : 1;
        $spoNumber = 'SPO-' . str_pad($nextId, 4, '0', STR_PAD_LEFT);

        $rawItems = $request->input('items');
        $items = [];
        $subtotal = 0;

        if (is_array($rawItems) && count($rawItems) > 0) {
            foreach ($rawItems as $it) {
                $calc = $this->calculateItemPricing($it, $isCompanyUse);
                $subtotal += $calc['subtotal'];
                $items[] = $calc;
            }
        } else {
            $defaultIt = [
                'glass_type' => $validated['glass_type'] ?? 'Kaca Cermin 5 mm polos',
                'length_cm' => $validated['length_cm'] ?? 150,
                'width_cm' => $validated['width_cm'] ?? 120,
                'thickness_mm' => $validated['thickness_mm'] ?? 5,
                'qty' => 1,
                'processes' => $validated['processes'] ?? ['HT']
            ];
            $calc = $this->calculateItemPricing($defaultIt, $isCompanyUse);
            $subtotal = $calc['subtotal'];
            $items[] = $calc;
        }

        $priorityFee = $validated['priority_status'] === 'Prioritas' 
            ? (float) $request->input('priority_fee', 0) 
            : 0;

        $customFee = $request->filled('custom_fee') ? (float) $request->input('custom_fee') : 0;
        
        // Calculate dynamic accessory costs
        $accessoryFee = 0;
        $rawAccessories = $request->input('accessories', []);
        if (is_array($rawAccessories)) {
            foreach ($rawAccessories as $acc) {
                if (is_array($acc)) {
                    $accPrice = (float)($acc['price'] ?? 0);
                    $accQty = max(1, (int)($acc['qty'] ?? 1));
                    $accessoryFee += ($accPrice * $accQty);
                }
            }
        }

        $totalPrice = $subtotal + $accessoryFee + $priorityFee + $customFee;

        // Summary glass_type for primary view
        $primaryItem = $items[0];
        $summaryGlassType = count($items) > 1 
            ? $primaryItem['glass_type'] . ' (+ ' . (count($items) - 1) . ' item lainnya)'
            : $primaryItem['glass_type'];

        $sketchPath = null;
        if ($request->hasFile('sketch_photo')) {
            $sketchPath = $request->file('sketch_photo')->store('sketches', 'public');
        }

        // Handle flexible payment selection (Cash, Transfer, QRIS with Auto DP / Lunas)
        $paymentMethod = $request->input('payment_method', 'cash');
        $rawPaid = $request->input('custom_paid_amount', $request->input('paid_amount', null));

        if ($isDraft) {
            $paidAmount = (float)($rawPaid ?? 0);
            $paymentStatus = 'Belum Lunas';
        } else {
            $paidAmount = $request->filled('custom_paid_amount') ? (float)$request->input('custom_paid_amount') : 0;
            if ($paidAmount >= $totalPrice && $totalPrice > 0) {
                $paidAmount = $totalPrice;
                $paymentStatus = 'Lunas';
            } else if ($paidAmount > 0) {
                $calcPct = round(($paidAmount / max(1, $totalPrice)) * 100);
                $paymentStatus = 'DP (' . $calcPct . '%)';
            } else {
                $paymentStatus = 'Belum Lunas';
            }
        }

        $order = Order::create([
            'order_date' => $validated['order_date'] ?? now()->toDateString(),
            'spo_number' => $spoNumber,
            'customer_name' => !empty(trim($validated['customer_name'] ?? '')) ? $validated['customer_name'] : '-',
            'customer_phone' => !empty(trim($validated['customer_phone'] ?? '')) ? $validated['customer_phone'] : '-',
            'customer_address' => !empty(trim($validated['customer_address'] ?? '')) ? $validated['customer_address'] : '-',
            'glass_type' => $summaryGlassType,
            'length_cm' => $primaryItem['length_cm'],
            'width_cm' => $primaryItem['width_cm'],
            'thickness_mm' => $primaryItem['thickness_mm'],
            'processes' => $primaryItem['processes'],
            'accessories' => $validated['accessories'] ?? [],
            'items' => $items,
            'description' => !empty(trim($validated['description'] ?? '')) ? $validated['description'] : '-',
            'sketch_photo_path' => $sketchPath,
            'priority_status' => $validated['priority_status'],
            'deadline_date' => $validated['deadline_date'] ?? now()->addDays(3)->toDateString(),
            'subtotal' => $subtotal,
            'priority_fee' => $priorityFee,
            'custom_fee' => $customFee,
            'total_price' => $totalPrice,
            'paid_amount' => $paidAmount,
            'payment_status' => $paymentStatus,
            'status' => $targetStatus,
            'current_division' => $isDraft ? 'admin_toko' : 'admin_gudang',
            'gudang_released_at' => $isDraft ? null : now(),
            'division_progress' => $this->buildDivisionProgress($items, $validated['processes'] ?? []),
            'used_scrap_rak' => !empty(trim($validated['used_scrap_rak'] ?? '')) ? $validated['used_scrap_rak'] : '-',
            'is_company_use' => $isCompanyUse,
        ]);

        $message = $isDraft 
            ? 'Draft Order #' . $spoNumber . ' Berhasil Disimpan!' 
            : 'SPO Orderan Baru #' . $spoNumber . ' (' . $paymentStatus . ') Berhasil Diterbitkan ke Admin Gudang!';

        return redirect()->back()->with('message', $message);
    }

    /**
     * Update Draft / Active Order (Admin Toko - Multi Item Kaca Edit & Flexible Payment)
     */
    public function updateOrder(Request $request, $id)
    {
        $order = Order::findOrFail($id);

        $validated = $request->validate([
            'order_date' => 'nullable|date',
            'customer_name' => 'required|string',
            'customer_phone' => 'required|string',
            'customer_address' => 'required|string',
            'glass_type' => 'nullable|string',
            'length_cm' => 'nullable',
            'width_cm' => 'nullable',
            'thickness_mm' => 'nullable',
            'processes' => 'nullable|array',
            'items' => 'nullable|array',
            'accessories' => 'nullable|array',
            'description' => 'nullable|string',
            'revision_notes' => 'nullable|string',
            'sketch_photo' => 'nullable|image|mimes:jpeg,png,jpg,webp|max:5120',
            'priority_status' => 'required|string',
            'priority_fee' => 'nullable|numeric',
            'custom_fee' => 'nullable|numeric',
            'deadline_date' => 'nullable|date',
            'used_scrap_rak' => 'nullable|string',
            'status' => 'nullable|string|in:draft,pengerjaan',
            'payment_option' => 'nullable|string',
            'dp_percent' => 'nullable|numeric',
            'custom_paid_amount' => 'nullable|numeric',
            'is_company_use' => 'nullable|boolean',
        ]);

        $isCompanyUse = $request->has('is_company_use') 
            ? (bool)$request->input('is_company_use') 
            : (bool)($order->is_company_use ?? false);

        $rawItems = $request->input('items');
        $items = [];
        $subtotal = 0;

        if (is_array($rawItems) && count($rawItems) > 0) {
            foreach ($rawItems as $it) {
                $calc = $this->calculateItemPricing($it, $isCompanyUse);
                $subtotal += $calc['subtotal'];
                $items[] = $calc;
            }
        } else {
            $defaultIt = [
                'glass_type' => $validated['glass_type'] ?? 'Kaca Cermin 5 mm polos',
                'length_cm' => $validated['length_cm'] ?? 150,
                'width_cm' => $validated['width_cm'] ?? 120,
                'thickness_mm' => $validated['thickness_mm'] ?? 5,
                'qty' => 1,
                'processes' => $validated['processes'] ?? ['HT']
            ];
            $calc = $this->calculateItemPricing($defaultIt, $isCompanyUse);
            $subtotal = $calc['subtotal'];
            $items[] = $calc;
        }

        $priorityFee = $validated['priority_status'] === 'Prioritas' 
            ? (float) $request->input('priority_fee', 0) 
            : 0;

        $customFee = $request->filled('custom_fee') ? (float) $request->input('custom_fee') : 0;

        // Calculate dynamic accessory costs
        $accessoryFee = 0;
        $rawAccessories = $request->input('accessories', []);
        if (is_array($rawAccessories)) {
            foreach ($rawAccessories as $acc) {
                if (is_array($acc)) {
                    $accPrice = (float)($acc['price'] ?? 0);
                    $accQty = max(1, (int)($acc['qty'] ?? 1));
                    $accessoryFee += ($accPrice * $accQty);
                }
            }
        }

        $totalPrice = $subtotal + $accessoryFee + $priorityFee + $customFee;

        $primaryItem = $items[0];
        $summaryGlassType = count($items) > 1 
            ? $primaryItem['glass_type'] . ' (+ ' . (count($items) - 1) . ' item lainnya)'
            : $primaryItem['glass_type'];

        if ($request->hasFile('sketch_photo')) {
            $order->sketch_photo_path = $request->file('sketch_photo')->store('sketches', 'public');
        }

        $targetStatus = $request->input('status', $order->status);
        $isPromoted = ($order->status === 'draft' && $targetStatus === 'pengerjaan');
        $isRevisionUpdate = ($order->status === 'pengerjaan' && !$isPromoted);

        $paymentOption = $request->input('payment_option', 'dp');
        $dpPercent = (float)$request->input('dp_percent', 50);

        $order->order_date = $validated['order_date'] ?? $order->order_date;
        $order->customer_name = !empty(trim($validated['customer_name'] ?? '')) ? $validated['customer_name'] : '-';
        $order->customer_phone = !empty(trim($validated['customer_phone'] ?? '')) ? $validated['customer_phone'] : '-';
        $order->customer_address = !empty(trim($validated['customer_address'] ?? '')) ? $validated['customer_address'] : '-';
        $order->glass_type = $summaryGlassType;
        $order->length_cm = $primaryItem['length_cm'];
        $order->width_cm = $primaryItem['width_cm'];
        $order->thickness_mm = $primaryItem['thickness_mm'];
        $order->processes = $primaryItem['processes'];
        $order->accessories = $validated['accessories'] ?? [];
        $order->items = $items;
        $order->description = !empty(trim($validated['description'] ?? '')) ? $validated['description'] : '-';
        $order->priority_status = $validated['priority_status'];
        $order->deadline_date = $validated['deadline_date'] ?? $order->deadline_date;
        $order->subtotal = $subtotal;
        $order->priority_fee = $priorityFee;
        $order->custom_fee = $customFee;
        $order->total_price = $totalPrice;
        $order->is_company_use = $isCompanyUse;

        if ($isRevisionUpdate) {
            $order->is_revised = true;
            $order->revision_count = ($order->revision_count ?? 0) + 1;
            
            $rawRevNotes = trim($request->input('revision_notes', ''));

            // Calculate automatic detailed diffs
            $diffs = [];

            // 1. Qty comparison
            $oldTotalQty = 0;
            if (!empty($order->items) && is_array($order->items)) {
                foreach ($order->items as $it) {
                    $oldTotalQty += max(1, (int)($it['qty'] ?? 1));
                }
            } else {
                $oldTotalQty = max(1, (int)($order->qty ?? 1));
            }

            $newTotalQty = 0;
            foreach ($items as $it) {
                $newTotalQty += max(1, (int)($it['qty'] ?? 1));
            }

            if ($oldTotalQty !== $newTotalQty) {
                $diffs[] = "Total Qty Kaca: diubah dari {$oldTotalQty} pcs ➔ {$newTotalQty} pcs";
            }

            // 2. Glass type / summary comparison
            if ($order->glass_type !== $summaryGlassType) {
                $diffs[] = "Jenis Kaca: diubah dari '{$order->glass_type}' ➔ '{$summaryGlassType}'";
            }

            // 3. Dimensions comparison
            $oldLen = (float)$order->length_cm;
            $oldWid = (float)$order->width_cm;
            $newLen = (float)$primaryItem['length_cm'];
            $newWid = (float)$primaryItem['width_cm'];
            if ($oldLen !== $newLen || $oldWid !== $newWid) {
                $diffs[] = "Ukuran Kaca Utama: diubah dari {$oldLen}x{$oldWid} cm ➔ {$newLen}x{$newWid} cm";
            }

            // 4. Customer Address comparison
            $newAddress = !empty(trim($validated['customer_address'] ?? '')) ? $validated['customer_address'] : '-';
            if ($order->customer_address !== $newAddress) {
                $diffs[] = "Alamat Pengiriman: diubah dari '{$order->customer_address}' ➔ '{$newAddress}'";
            }

            // 5. Custom notes typed by Toko
            if (!empty($rawRevNotes) && $rawRevNotes !== '-') {
                $diffs[] = "Catatan Toko: \"{$rawRevNotes}\"";
            }

            $autoDiffText = !empty($diffs) 
                ? implode(' | ', $diffs) 
                : (!empty($rawRevNotes) ? $rawRevNotes : 'Revisi spesifikasi/desain dari Admin Toko.');

            $order->revision_notes = $autoDiffText;
            
            if ($order->current_division === 'admin_gudang') {
                $order->revision_status = 'pending_gudang';
            } else {
                $order->revision_status = 'pending_division';
            }

            $history = (array) ($order->revision_history ?? []);
            $history[] = [
                'revision_number' => $order->revision_count,
                'revised_at' => now()->toDateTimeString(),
                'revised_by' => auth()->user()->name ?? 'Admin Toko',
                'notes' => $autoDiffText,
                'user_notes' => $rawRevNotes,
                'changes_list' => $diffs,
                'glass_summary' => $summaryGlassType,
                'old_qty' => $oldTotalQty,
                'new_qty' => $newTotalQty,
            ];
            $order->revision_history = $history;
        }

        if ($isPromoted || $targetStatus === 'pengerjaan') {
            $order->status = 'pengerjaan';
            $rawPaid = $request->input('custom_paid_amount', $request->input('paid_amount', 0));
            $paidAmount = $request->filled('custom_paid_amount') ? (float)$rawPaid : 0;

            if ($paidAmount >= $totalPrice && $totalPrice > 0) {
                $order->paid_amount = $totalPrice;
                $order->payment_status = 'Lunas';
            } else if ($paidAmount > 0) {
                $order->paid_amount = $paidAmount;
                $calcPct = round(($paidAmount / max(1, $totalPrice)) * 100);
                $order->payment_status = 'DP (' . $calcPct . '%)';
            } else {
                $order->paid_amount = 0;
                $order->payment_status = 'Belum Lunas';
            }

            if ($isPromoted) {
                $order->current_division = 'admin_gudang';
                $order->gudang_released_at = $order->gudang_released_at ?? now();
                $order->division_progress = [
                    'HT' => 'Menunggu Dispatch',
                    'GM' => 'Belum',
                    'BV' => 'N/A',
                    'Etsa' => 'N/A'
                ];
            }
        } else if ($order->status === 'draft') {
            $order->paid_amount = $request->filled('custom_paid_amount') ? (float)$request->input('custom_paid_amount') : 0;
            $order->payment_status = 'Belum Lunas';
        }

        $order->save();

        if ($isRevisionUpdate) {
            $destTarget = ($order->current_division === 'admin_gudang') ? 'Admin Gudang' : 'Seluruh Divisi Produksi';
            $message = 'Revisi Order #' . $order->spo_number . ' Berhasil Disimpan & Peringatan Terkirim ke ' . $destTarget . '!';
        } else {
            $message = $isPromoted 
                ? 'Draf Order #' . $order->spo_number . ' Berhasil Didealkan & Diterbitkan ke Admin Gudang!' 
                : 'Perubahan Draf Order #' . $order->spo_number . ' Berhasil Diperbarui!';
        }

        return redirect()->back()->with('message', $message);
    }

    /**
     * Calculate Item Glass & Process Option Pricing
     */
    private function calculateItemPricing(array $it, bool $isCompanyUse = false): array
    {
        $lRaw = str_replace(',', '.', (string)($it['length_cm'] ?? 100));
        $wRaw = str_replace(',', '.', (string)($it['width_cm'] ?? 100));
        $l = (float)$lRaw;
        $w = (float)$wRaw;

        $gt = $it['glass_type'] ?? 'Kaca Cermin 5 mm polos';
        
        // Auto extract thickness from glass_type if present (e.g. 5, 8, 12)
        $t = 5;
        if (preg_match('/(\d+)\s*(?:mm|mili)/i', $gt, $matches)) {
            $t = (int)$matches[1];
        } elseif (isset($it['thickness_mm']) && (int)$it['thickness_mm'] > 0) {
            $t = (int)$it['thickness_mm'];
        }

        $q = max(1, (int)($it['qty'] ?? 1));
        $procs = is_array($it['processes'] ?? null) ? $it['processes'] : ['HT'];

        // 1. Luas & Keliling
        $areaM2 = ($l * $w) / 10000;
        $perimeterM = (2 * ($l + $w)) / 100;

        // 2. Harga Dasar Kaca (per m2 proporsional sesuai katalog jenis kaca)
        $pricePerM2 = (float)($it['price_per_m2'] ?? 0);
        if ($pricePerM2 <= 0) {
            if ($t >= 12) $pricePerM2 = 950000;
            elseif ($t >= 10) $pricePerM2 = 720000;
            elseif ($t >= 8) $pricePerM2 = 450000;
            else $pricePerM2 = 380000;
        }
        $rawBasePrice = round($areaM2 * $pricePerM2);
        // Harga dasar kaca murni proporsional luas area m2 (0 jika Orderan Kosong / Dipakai Perusahaan)
        $baseGlassPrice = $isCompanyUse ? 0 : ($rawBasePrice * $q);

        // 3. Biaya GM, HT, BV, Etsa dengan tarif kustom per jenis kaca (dengan fallback default)
        $rateGM = (float)($it['rate_gm'] ?? 10000);
        $rateHT = (float)($it['rate_ht'] ?? 1000);
        $rateBV = (float)($it['rate_bv'] ?? 15000);
        $rateEtsa = (float)($it['rate_etsa'] ?? 50000);

        // 3. Biaya GM (Gosok Mesin)
        // GM hanya dihitung dari sisi yang dipilih (default 2 sisi panjang + 2 sisi lebar)
        $gmSidesL = isset($it['gm_sides_length']) && $it['gm_sides_length'] !== '' ? min(2, max(0, (int)$it['gm_sides_length'])) : 2;
        $gmSidesW = isset($it['gm_sides_width']) && $it['gm_sides_width'] !== '' ? min(2, max(0, (int)$it['gm_sides_width'])) : 2;
        $gmLengthM = (($gmSidesL * $l) + ($gmSidesW * $w)) / 100;
        $feeGM = in_array('GM', $procs) ? round($gmLengthM * $rateGM) * $q : 0;

        // 4. Biaya HT (Gosok HT / Halus Tepi)
        $feeHT = in_array('HT', $procs) ? round($perimeterM * $rateHT) * $q : 0;

        // 5. Biaya BV (Beveling)
        $bevelWidthCm = (float)str_replace(',', '.', (string)($it['bevel_width_cm'] ?? 1));
        $bvSidesL = isset($it['bv_sides_length']) && $it['bv_sides_length'] !== '' ? min(2, max(0, (int)$it['bv_sides_length'])) : 2;
        $bvSidesW = isset($it['bv_sides_width']) && $it['bv_sides_width'] !== '' ? min(2, max(0, (int)$it['bv_sides_width'])) : 2;
        $bvLengthM = (($bvSidesL * $l) + ($bvSidesW * $w)) / 100;
        $feeBV = in_array('BV', $procs) ? round(($bvLengthM * $rateBV) + ($bevelWidthCm * 10000)) * $q : 0;

        // 6. Biaya Bor (Coakan): Keliling ruas lubang cm * Rp 2.500 * jumlah lubang (Mendukung multi-lubang)
        $feeBor = 0;
        $holesSpecs = [];
        if (in_array('Bor', $procs)) {
            if (isset($it['holes']) && is_array($it['holes']) && count($it['holes']) > 0) {
                foreach ($it['holes'] as $h) {
                    $hl = (float)str_replace(',', '.', (string)($h['hole_length_cm'] ?? $h['length_cm'] ?? 2));
                    $hw = (float)str_replace(',', '.', (string)($h['hole_width_cm'] ?? $h['width_cm'] ?? 2));
                    $hq = max(1, (int)($h['hole_qty'] ?? $h['qty'] ?? 1));
                    $ruas = 2 * ($hl + $hw);
                    $feeBor += round($ruas * 2500) * $hq * $q;
                    $holesSpecs[] = [
                        'hole_length_cm' => $hl,
                        'hole_width_cm' => $hw,
                        'hole_qty' => $hq,
                    ];
                }
            } else {
                $holeLCm = (float)str_replace(',', '.', (string)($it['hole_length_cm'] ?? 2));
                $holeWCm = (float)str_replace(',', '.', (string)($it['hole_width_cm'] ?? 2));
                $holeQty = max(1, (int)($it['hole_qty'] ?? 1));
                $holeRuasCm = 2 * ($holeLCm + $holeWCm);
                $feeBor = round($holeRuasCm * 2500) * $holeQty * $q;
                $holesSpecs[] = [
                    'hole_length_cm' => $holeLCm,
                    'hole_width_cm' => $holeWCm,
                    'hole_qty' => $holeQty,
                ];
            }
        }
        $primaryHoleL = $holesSpecs[0]['hole_length_cm'] ?? 2;
        $primaryHoleW = $holesSpecs[0]['hole_width_cm'] ?? 2;
        $primaryHoleQ = $holesSpecs[0]['hole_qty'] ?? 1;

        // 7. Biaya Etsa (Sandblast): Langsung dihitung dari Luas Area Etsa (m2)
        $etsaLCm = (float)str_replace(',', '.', (string)($it['etsa_length_cm'] ?? $l));
        $etsaWCm = (float)str_replace(',', '.', (string)($it['etsa_width_cm'] ?? $w));
        $etsaQty = max(1, (int)($it['etsa_qty'] ?? 1));
        $etsaAreaM2 = ($etsaLCm * $etsaWCm) / 10000;

        $feeEtsa = 0;
        if (in_array('Etsa', $procs)) {
            $feeEtsa = round($etsaAreaM2 * $etsaQty * $rateEtsa) * $q;
            // Batas minimum biaya etsa (setengah tarif per m2) per unit
            $feeEtsa = max(($rateEtsa / 2) * $q, $feeEtsa);
        }

        // Total Item Subtotal (0 jika Orderan Kosong / Dipakai Perusahaan)
        if ($isCompanyUse) {
            $feeGM = 0;
            $feeHT = 0;
            $feeBV = 0;
            $feeBor = 0;
            $feeEtsa = 0;
        }

        $itemSubtotal = $baseGlassPrice + $feeGM + $feeHT + $feeBV + $feeBor + $feeEtsa;

        return [
            'glass_type' => $gt,
            'length_cm' => $l,
            'width_cm' => $w,
            'thickness_mm' => $t,
            'qty' => $q,
            'processes' => $procs,
            'bevel_width_cm' => $bevelWidthCm,
            'gm_sides_length' => $gmSidesL,
            'gm_sides_width' => $gmSidesW,
            'bv_sides_length' => $bvSidesL,
            'bv_sides_width' => $bvSidesW,
            'holes' => $holesSpecs,
            'hole_length_cm' => $primaryHoleL,
            'hole_width_cm' => $primaryHoleW,
            'hole_qty' => $primaryHoleQ,
            'etsa_length_cm' => $etsaLCm,
            'etsa_width_cm' => $etsaWCm,
            'etsa_qty' => $etsaQty,
            'etsa_area_m2' => $etsaAreaM2,
            'base_glass_price' => $baseGlassPrice,
            'price_per_m2' => $pricePerM2,
            'rate_gm' => $rateGM,
            'rate_ht' => $rateHT,
            'rate_bv' => $rateBV,
            'rate_etsa' => $rateEtsa,
            'fee_gm' => $feeGM,
            'fee_ht' => $feeHT,
            'fee_bv' => $feeBV,
            'fee_bor' => $feeBor,
            'fee_etsa' => $feeEtsa,
            'subtotal' => $itemSubtotal
        ];
    }

    /**
     * Helper to dynamically generate division_progress array based on required item processes
     */
    private function buildDivisionProgress($items = [], $processes = [])
    {
        $req = [];
        if (is_array($processes)) {
            foreach ($processes as $p) {
                $req[strtoupper((string)$p)] = true;
            }
        }
        if (is_array($items)) {
            foreach ($items as $it) {
                if (isset($it['processes']) && is_array($it['processes'])) {
                    foreach ($it['processes'] as $p) {
                        $req[strtoupper((string)$p)] = true;
                    }
                }
            }
        }

        $divKeys = ['HT', 'GM', 'BV', 'Etsa'];
        $progress = [];
        foreach ($divKeys as $code) {
            $upperCode = strtoupper($code);
            // HT (Potong) is ALWAYS mandatory for every order (potong kaca lembaran)
            if ($upperCode === 'HT' || isset($req[$upperCode])) {
                $progress[$code] = 'Belum';
            } else {
                $progress[$code] = 'N/A';
            }
        }
        return $progress;
    }
}
