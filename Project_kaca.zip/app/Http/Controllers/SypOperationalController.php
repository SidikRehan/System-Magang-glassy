<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Inertia\Inertia;
use App\Models\Order;
use App\Models\ScrapGlass;
use App\Models\Delivery;
use App\Models\User;
use App\Models\ActivityLog;
use App\Models\FinanceTransaction;
use App\Models\SheetGlass;
use App\Models\Supplier;
use App\Models\Accessory;
use App\Models\Tool;
use App\Models\Supply;
use Illuminate\Support\Facades\Hash;

class SypOperationalController extends Controller
{
    /**
     * Public Landing Page View with Glass Simulator & Cost Estimator
     */
    public function welcome()
    {
        return Inertia::render('Welcome', [
            'scrapCount' => ScrapGlass::where('status', 'Layak Pakai')->count(),
            'totalOrders' => Order::count(),
        ]);
    }

    /**
     * Syp Dashboard Utama
     */
    public function dashboard()
    {
        return Inertia::render('Dashboard', [
            // ── Props yang sering berubah: dibungkus closure agar partial reload
            //    hanya mengevaluasi query yang diminta oleh klien. ─────────────
            'orders'              => fn() => Order::orderBy('id', 'desc')->get(),
            'metrics'             => fn() => $this->computeDashboardMetrics(),

            // ── Props data pendukung: dievaluasi saat initial visit dan saat diminta partial reload ───────
            'scrapGlasses'        => fn() => ScrapGlass::where('status', '!=', 'Terpakai')->latest()->get(),
            'deliveries'          => fn() => Delivery::with(['order', 'gateChecker:id,name,role'])->latest()->get(),
            'users'               => fn() => User::select('id', 'name', 'email', 'role', 'created_at')->orderBy('id', 'desc')->get(),
            'activityLogs'        => fn() => ActivityLog::latest()->take(100)->get(),
            'financeTransactions' => fn() => FinanceTransaction::with(['user', 'approver'])->orderBy('transaction_date', 'desc')->orderBy('id', 'desc')->get(),
            'sheetGlasses'        => fn() => SheetGlass::orderBy('id', 'desc')->get(),
            'suppliers'           => fn() => Supplier::orderBy('id', 'desc')->get(),
            'accessories'         => fn() => Accessory::orderBy('id', 'desc')->get(),
            'tools'               => fn() => Tool::with(['borrows' => fn($q) => $q->latest()])->orderBy('id', 'desc')->get(),
            'supplies'            => fn() => Supply::with(['usages' => fn($q) => $q->latest(), 'restocks' => fn($q) => $q->latest()])->orderBy('id', 'desc')->get(),
        ]);
    }

    /**
     * Hitung semua metrik dashboard dalam satu metode terpusat.
     * Dipanggil via closure sehingga hanya berjalan saat prop 'metrics' diminta.
     */
    private function computeDashboardMetrics(): array
    {
        $otherRevenue       = (float) FinanceTransaction::where('approval_status', 'approved')->where('type', 'pemasukan_lain')->sum('amount');
        $activeOrders       = Order::where('status', '!=', 'draft');
        $completedOrders    = Order::where('status', 'selesai');
        $totalRevenue       = (float) (clone $completedOrders)->sum('total_price') + $otherRevenue;
        $paidRevenue        = (float) (clone $activeOrders)->sum('paid_amount') + $otherRevenue;
        $pendingCODTotal    = (float) (clone $activeOrders)->where('payment_status', '!=', 'Lunas')->sum('total_price');
        $pendingCODPaid     = (float) (clone $activeOrders)->where('payment_status', '!=', 'Lunas')->sum('paid_amount');
        $pendingCOD         = max(0, (float)($pendingCODTotal - $pendingCODPaid));

        $cogsPurchases      = (float) FinanceTransaction::where('approval_status', 'approved')->whereIn('type', ['pembelian_bahan', 'pembelian_aksesoris'])->sum('amount');
        $opexExpenses       = (float) FinanceTransaction::where('approval_status', 'approved')->whereIn('type', ['biaya_operasional', 'pembelian_alat'])->sum('amount');
        $totalExpenses      = $cogsPurchases + $opexExpenses;
        $grossProfit        = $totalRevenue - $cogsPurchases;
        $netProfit          = $totalRevenue - $totalExpenses;
        
        // Valuasi riil potensi penghematan HPP dari kaca sisa rak (Scrap Glass) berdasarkan luas m2 & katalog harga jual
        $usableScraps       = ScrapGlass::where('status', 'Layak Pakai')->get();
        $sheetGlassesCatalog = SheetGlass::all()->keyBy(fn($g) => strtolower($g->name));
        $scrapGlassLoss     = 0;
        foreach ($usableScraps as $sc) {
            $scArea = ((float)$sc->length_cm * (float)$sc->width_cm) / 10000;
            $scNameLower = strtolower($sc->glass_type ?? '');
            $matchedSheet = $sheetGlassesCatalog->get($scNameLower);
            if (!$matchedSheet) {
                foreach ($sheetGlassesCatalog as $name => $sg) {
                    if (str_contains($scNameLower, $name) || str_contains($name, $scNameLower)) {
                        $matchedSheet = $sg;
                        break;
                    }
                }
            }
            $pricePerM2 = $matchedSheet && $matchedSheet->sell_price > 0 ? (float)$matchedSheet->sell_price : 380000;
            $scrapGlassLoss += ($scArea * $pricePerM2);
        }
        $scrapGlassLoss = round($scrapGlassLoss);
        $pendingApprovalCount = FinanceTransaction::where('approval_status', 'pending')->count();

        return [
            'totalOrders'          => (clone $completedOrders)->count(),
            'completedOrdersCount' => (clone $completedOrders)->count(),
            'activeDealOrdersCount'=> (clone $activeOrders)->count(),
            'allOrdersCount'       => Order::count(),
            'draftOrdersCount'     => Order::where('status', 'draft')->count(),
            'draftOrdersTotal'     => (float) Order::where('status', 'draft')->sum('total_price'),
            'inProcess'            => Order::where('status', 'pengerjaan')->count(),
            'readyShip'            => Order::where('status', 'pengiriman')->count(),
            'scrapCount'           => ScrapGlass::count(),
            'scrapGlassLoss'       => $scrapGlassLoss,
            'pendingApprovalCount' => $pendingApprovalCount,
            'totalRevenue'         => $totalRevenue,
            'otherRevenue'         => $otherRevenue,
            'paidRevenue'          => $paidRevenue,
            'pendingCOD'           => $pendingCOD,
            'cogsPurchases'        => $cogsPurchases,
            'opexExpenses'         => $opexExpenses,
            'totalExpenses'        => $totalExpenses,
            'grossProfit'          => $grossProfit,
            'netProfit'            => $netProfit,
            'grossMarginPct'       => $totalRevenue > 0 ? round(($grossProfit / $totalRevenue) * 100, 1) : 0,
            'netMarginPct'         => $totalRevenue > 0 ? round(($netProfit  / $totalRevenue) * 100, 1) : 0,
        ];
    }

    /**
     * Store New Order (Admin Toko - Multi Item Kaca Specification)
     */
    public function storeOrder(Request $request)
    {
        $validated = $request->validate([
            'order_date' => 'nullable|date',
            'customer_name' => 'required|string',
            'customer_phone' => 'required|string',
            'customer_address' => 'required|string',
            'glass_type' => 'nullable|string',
            'length_cm' => 'nullable',
            'width_cm' => 'nullable',
            'thickness_mm' => 'nullable',
            'processes' => 'nullable|array',
            'items' => 'nullable|array',
            'accessories' => 'nullable|array',
            'description' => 'nullable|string',
            'sketch_photo' => 'nullable|image|mimes:jpeg,png,jpg,webp,gif|max:10240',
            'dp_proof' => 'nullable|image|mimes:jpeg,png,jpg,webp,gif|max:10240',
            'priority_status' => 'required|string',
            'priority_fee' => 'nullable|numeric',
            'custom_fee' => 'nullable|numeric',
            'deadline_date' => 'nullable|date',
            'used_scrap_rak' => 'nullable|string',
            'is_company_use' => 'nullable|boolean',
            'status' => 'nullable|string|in:draft,pengerjaan',
        ]);

        $targetStatus = $validated['status'] ?? 'pengerjaan';
        $isDraft = ($targetStatus === 'draft');
        $isCompanyUse = (bool) $request->input('is_company_use', false);

        $latestOrder = Order::orderBy('id', 'desc')->first();
        $nextId = $latestOrder ? ($latestOrder->id + 1) : 1;
        $spoNumber = 'SPO-' . str_pad($nextId, 4, '0', STR_PAD_LEFT);

        $rawItems = $request->input('items');
        $items = [];
        $itemsSubtotal = 0;

        if (is_array($rawItems) && count($rawItems) > 0) {
            $dimensionErr = $this->validateItemGlassDimensions($rawItems);
            if ($dimensionErr) {
                return redirect()->back()->withErrors(['message' => $dimensionErr]);
            }
            foreach ($rawItems as $it) {
                $calc = $this->calculateItemPricing($it, $isCompanyUse);
                $itemsSubtotal += $calc['subtotal'];
                $items[] = $calc;
            }
        } else {
            $defaultIt = [
                'glass_type' => $validated['glass_type'] ?? 'Kaca Cermin 5 mm polos',
                'length_cm' => $validated['length_cm'] ?? 150,
                'width_cm' => $validated['width_cm'] ?? 120,
                'thickness_mm' => $validated['thickness_mm'] ?? 5,
                'qty' => 1,
                'processes' => $validated['processes'] ?? ['HT']
            ];
            $calc = $this->calculateItemPricing($defaultIt, $isCompanyUse);
            $itemsSubtotal = $calc['subtotal'];
            $items[] = $calc;
        }

        $priorityFee = ($validated['priority_status'] === 'Prioritas' && !$isCompanyUse)
            ? (float) $request->input('priority_fee', 0) 
            : 0;

        $customFee = (!$isCompanyUse && $request->filled('custom_fee')) ? (float) $request->input('custom_fee') : 0;
        
        // Calculate dynamic accessory costs
        $accessoryFee = 0;
        $rawAccessories = $request->input('accessories', []);
        if (is_array($rawAccessories)) {
            foreach ($rawAccessories as $acc) {
                if (is_array($acc)) {
                    $accPrice = (float)($acc['price'] ?? 0);
                    $accQty = max(1, (int)($acc['qty'] ?? 1));
                    $accessoryFee += ($accPrice * $accQty);
                }
            }
        }

        // Subtotal = Nilai Barang & Jasa (Kaca + Jasa Proses + Aksesoris)
        $subtotal = $itemsSubtotal + $accessoryFee;
        $totalPrice = $subtotal + $priorityFee + $customFee;

        // Summary glass_type for primary view
        $primaryItem = $items[0];
        $summaryGlassType = count($items) > 1 
            ? $primaryItem['glass_type'] . ' (+ ' . (count($items) - 1) . ' item lainnya)'
            : $primaryItem['glass_type'];

        $sketchPath = null;
        if ($request->hasFile('sketch_photo')) {
            $sketchPath = $request->file('sketch_photo')->store('sketches', 'public');
        }

        $dpProofPath = null;
        if ($request->hasFile('dp_proof')) {
            $dpProofPath = $request->file('dp_proof')->store('payment_proofs', 'public');
        }

        // Handle flexible payment selection (Cash, Transfer, QRIS with Auto DP / Lunas)
        $paymentMethod = $request->input('payment_method', 'cash');
        $rawPaid = $request->input('custom_paid_amount', $request->input('paid_amount', null));

        if ($isDraft) {
            $paidAmount = (float)($rawPaid ?? 0);
            $paymentStatus = 'Belum Lunas';
        } else {
            $paidAmount = $request->filled('custom_paid_amount') ? (float)$rawPaid : round(($totalPrice * (float)$request->input('dp_percent', 50)) / 100);
            if ($paidAmount >= $totalPrice && $totalPrice > 0) {
                $paidAmount = $totalPrice;
                $paymentStatus = 'Lunas';
            } else if ($paidAmount > 0) {
                $calcPct = round(($paidAmount / max(1, $totalPrice)) * 100);
                $paymentStatus = 'DP (' . $calcPct . '%)';
            } else {
                $paymentStatus = 'Belum Lunas';
            }
        }

        // Merge all required processes across all items in standard sequence
        $allProcs = [];
        foreach ($items as $it) {
            if (!empty($it['processes']) && is_array($it['processes'])) {
                foreach ($it['processes'] as $p) {
                    $norm = $this->normalizeDivisionKey((string) $p);
                    if ($norm && !in_array($norm, $allProcs)) {
                        $allProcs[] = $norm;
                    }
                }
            }
        }
        if (empty($allProcs)) {
            $allProcs = ['HT'];
        }
        if (!in_array('HT', $allProcs)) {
            array_unshift($allProcs, 'HT');
        }

        $order = Order::create([
            'order_date' => $validated['order_date'] ?? now()->toDateString(),
            'spo_number' => $spoNumber,
            'customer_name' => !empty(trim($validated['customer_name'] ?? '')) ? $validated['customer_name'] : '-',
            'customer_phone' => !empty(trim($validated['customer_phone'] ?? '')) ? $validated['customer_phone'] : '-',
            'customer_address' => !empty(trim($validated['customer_address'] ?? '')) ? $validated['customer_address'] : '-',
            'glass_type' => $summaryGlassType,
            'length_cm' => $primaryItem['length_cm'],
            'width_cm' => $primaryItem['width_cm'],
            'thickness_mm' => $primaryItem['thickness_mm'],
            'processes' => $allProcs,
            'accessories' => $validated['accessories'] ?? [],
            'items' => $items,
            'description' => !empty(trim($validated['description'] ?? '')) ? $validated['description'] : '-',
            'sketch_photo_path' => $sketchPath,
            'priority_status' => $validated['priority_status'],
            'deadline_date' => $validated['deadline_date'] ?? now()->addDays(3)->toDateString(),
            'subtotal' => $subtotal,
            'priority_fee' => $priorityFee,
            'custom_fee' => $customFee,
            'total_price' => $totalPrice,
            'paid_amount' => $paidAmount,
            'payment_status' => $paymentStatus,
            'payment_method' => $paymentMethod,
            'dp_proof_path' => $dpProofPath,
            'payment_proof_path' => ($paymentStatus === 'Lunas' && $dpProofPath) ? $dpProofPath : null,
            'status' => $targetStatus,
            'is_company_use' => $isCompanyUse,
            'current_division' => $isDraft ? 'admin_toko' : 'admin_gudang',
            'gudang_released_at' => $isDraft ? null : now(),
            'division_progress' => $this->buildDivisionProgress($items, $allProcs),
            'used_scrap_rak' => !empty(trim($validated['used_scrap_rak'] ?? '')) ? $validated['used_scrap_rak'] : '-',
        ]);

        // Potong stok master aksesoris gudang bila order langsung masuk antrean pengerjaan
        if (!$isDraft && is_array($validated['accessories'] ?? null)) {
            foreach ($validated['accessories'] as $acc) {
                if (is_array($acc)) {
                    $accId = $acc['id'] ?? null;
                    $accName = $acc['name'] ?? null;
                    $accQty = max(1, (int)($acc['qty'] ?? 1));
                    $accModel = null;
                    if ($accId && is_numeric($accId)) {
                        $accModel = \App\Models\Accessory::find($accId);
                    }
                    if (!$accModel && $accName) {
                        $accModel = \App\Models\Accessory::where('name', $accName)->first();
                    }
                    if ($accModel) {
                        $accModel->decrement('qty', min($accModel->qty, $accQty));
                        $accModel->update([
                            'status' => $accModel->qty > 20 ? 'Aman' : ($accModel->qty > 0 ? 'Menipis' : 'Habis')
                        ]);
                    }
                }
            }
        }

        // Kunci / Cadangkan Kaca Sisa jika dipilih pada order baru
        if (!empty($validated['used_scrap_rak']) && $validated['used_scrap_rak'] !== '-') {
            preg_match('/(SCRAP-\d+|SCR-\d+-[A-Za-z0-9]+|SC-[A-Za-z0-9-]+)/i', $validated['used_scrap_rak'], $scMatch);
            if (!empty($scMatch[1])) {
                $scItem = ScrapGlass::where('scrap_code', $scMatch[1])->first();
                if ($scItem && $scItem->status === 'Layak Pakai') {
                    $scItem->update(['status' => 'Dicadangkan']);
                }
            }
        }

        $message = $isDraft 
            ? 'Draft Order #' . $spoNumber . ' Berhasil Disimpan!' 
            : 'SPO Orderan Baru #' . $spoNumber . ' (' . $paymentStatus . ') Berhasil Diterbitkan ke Admin Gudang!';

        return redirect()->back()->with('message', $message);
    }

    /**
     * Update Draft / Active Order (Admin Toko - Multi Item Kaca Edit & Flexible Payment)
     */
    public function updateOrder(Request $request, $id)
    {
        $order = Order::findOrFail($id);

        $validated = $request->validate([
            'order_date' => 'nullable|date',
            'customer_name' => 'required|string',
            'customer_phone' => 'required|string',
            'customer_address' => 'required|string',
            'glass_type' => 'nullable|string',
            'length_cm' => 'nullable',
            'width_cm' => 'nullable',
            'thickness_mm' => 'nullable',
            'processes' => 'nullable|array',
            'items' => 'nullable|array',
            'accessories' => 'nullable|array',
            'description' => 'nullable|string',
            'revision_notes' => 'nullable|string',
            'sketch_photo' => 'nullable|image|mimes:jpeg,png,jpg,webp,gif|max:10240',
            'dp_proof' => 'nullable|image|mimes:jpeg,png,jpg,webp,gif|max:10240',
            'priority_status' => 'required|string',
            'priority_fee' => 'nullable|numeric',
            'custom_fee' => 'nullable|numeric',
            'deadline_date' => 'nullable|date',
            'used_scrap_rak' => 'nullable|string',
            'is_company_use' => 'nullable|boolean',
            'status' => 'nullable|string|in:draft,pengerjaan',
            'payment_option' => 'nullable|string',
            'dp_percent' => 'nullable|numeric',
            'custom_paid_amount' => 'nullable|numeric',
        ]);

        $isCompanyUse = $request->has('is_company_use') 
            ? (bool)$request->input('is_company_use') 
            : (bool)$order->is_company_use;

        $rawItems = $request->input('items');
        $items = [];
        $itemsSubtotal = 0;

        if (is_array($rawItems) && count($rawItems) > 0) {
            $dimensionErr = $this->validateItemGlassDimensions($rawItems);
            if ($dimensionErr) {
                return redirect()->back()->withErrors(['message' => $dimensionErr]);
            }
            foreach ($rawItems as $it) {
                $calc = $this->calculateItemPricing($it, $isCompanyUse);
                $itemsSubtotal += $calc['subtotal'];
                $items[] = $calc;
            }
        } else {
            $defaultIt = [
                'glass_type' => $validated['glass_type'] ?? 'Kaca Cermin 5 mm polos',
                'length_cm' => $validated['length_cm'] ?? 150,
                'width_cm' => $validated['width_cm'] ?? 120,
                'thickness_mm' => $validated['thickness_mm'] ?? 5,
                'qty' => 1,
                'processes' => $validated['processes'] ?? ['HT']
            ];
            $calc = $this->calculateItemPricing($defaultIt, $isCompanyUse);
            $itemsSubtotal = $calc['subtotal'];
            $items[] = $calc;
        }

        $priorityFee = ($validated['priority_status'] === 'Prioritas' && !$isCompanyUse)
            ? (float) $request->input('priority_fee', 0) 
            : 0;

        $customFee = (!$isCompanyUse && $request->filled('custom_fee')) ? (float) $request->input('custom_fee') : 0;

        // Calculate dynamic accessory costs
        $accessoryFee = 0;
        $rawAccessories = $request->input('accessories', []);
        if (is_array($rawAccessories)) {
            foreach ($rawAccessories as $acc) {
                if (is_array($acc)) {
                    $accPrice = (float)($acc['price'] ?? 0);
                    $accQty = max(1, (int)($acc['qty'] ?? 1));
                    $accessoryFee += ($accPrice * $accQty);
                }
            }
        }

        // Subtotal = Nilai Barang & Jasa (Kaca + Jasa Proses + Aksesoris)
        $subtotal = $itemsSubtotal + $accessoryFee;
        $totalPrice = $subtotal + $priorityFee + $customFee;

        $primaryItem = $items[0];
        $summaryGlassType = count($items) > 1 
            ? $primaryItem['glass_type'] . ' (+ ' . (count($items) - 1) . ' item lainnya)'
            : $primaryItem['glass_type'];

        if ($request->hasFile('sketch_photo')) {
            $order->sketch_photo_path = $request->file('sketch_photo')->store('sketches', 'public');
        }
        if ($request->hasFile('dp_proof')) {
            $order->dp_proof_path = $request->file('dp_proof')->store('payment_proofs', 'public');
        }

        $targetStatus = $request->input('status', $order->status);
        $isPromoted = ($order->status === 'draft' && $targetStatus === 'pengerjaan');
        $isRevisionUpdate = ($order->status === 'pengerjaan' && !$isPromoted);

        if ($isRevisionUpdate && empty(trim($validated['revision_notes'] ?? ''))) {
            return redirect()->back()->withErrors([
                'revision_notes' => 'Catatan / alasan revisi wajib diisi untuk menginfokan divisi produksi & gudang.'
            ]);
        }

        $paymentOption = $request->input('payment_option', 'dp');
        $dpPercent = (float)$request->input('dp_percent', 50);

        $allProcs = [];
        foreach ($items as $it) {
            if (!empty($it['processes']) && is_array($it['processes'])) {
                foreach ($it['processes'] as $p) {
                    $norm = $this->normalizeDivisionKey((string) $p);
                    if ($norm && !in_array($norm, $allProcs)) {
                        $allProcs[] = $norm;
                    }
                }
            }
        }
        if (empty($allProcs)) {
            $allProcs = ['HT'];
        }
        if (!in_array('HT', $allProcs)) {
            array_unshift($allProcs, 'HT');
        }

        $order->order_date = $validated['order_date'] ?? $order->order_date;
        $order->customer_name = !empty(trim($validated['customer_name'] ?? '')) ? $validated['customer_name'] : '-';
        $order->customer_phone = !empty(trim($validated['customer_phone'] ?? '')) ? $validated['customer_phone'] : '-';
        $order->customer_address = !empty(trim($validated['customer_address'] ?? '')) ? $validated['customer_address'] : '-';
        $order->glass_type = $summaryGlassType;
        $order->length_cm = $primaryItem['length_cm'];
        $order->width_cm = $primaryItem['width_cm'];
        $order->thickness_mm = $primaryItem['thickness_mm'];
        $order->processes = $allProcs;
        $order->accessories = $validated['accessories'] ?? [];
        $order->items = $items;
        $order->description = !empty(trim($validated['description'] ?? '')) ? $validated['description'] : '-';
        $order->priority_status = $validated['priority_status'];
        $order->deadline_date = $validated['deadline_date'] ?? $order->deadline_date;
        $order->subtotal = $subtotal;
        $order->priority_fee = $priorityFee;
        $order->custom_fee = $customFee;
        $order->total_price = $totalPrice;
        $order->is_company_use = $isCompanyUse;

        if ($isRevisionUpdate) {
            $order->is_revised = true;
            $order->revision_count = ($order->revision_count ?? 0) + 1;
            
            $rawRevNotes = trim($request->input('revision_notes', ''));

            // Calculate automatic detailed diffs
            $diffs = [];

            // 1. Qty comparison
            $oldTotalQty = 0;
            if (!empty($order->items) && is_array($order->items)) {
                foreach ($order->items as $it) {
                    $oldTotalQty += max(1, (int)($it['qty'] ?? 1));
                }
            } else {
                $oldTotalQty = max(1, (int)($order->qty ?? 1));
            }

            $newTotalQty = 0;
            foreach ($items as $it) {
                $newTotalQty += max(1, (int)($it['qty'] ?? 1));
            }

            if ($oldTotalQty !== $newTotalQty) {
                $diffs[] = "Total Qty Kaca: diubah dari {$oldTotalQty} pcs ➔ {$newTotalQty} pcs";
            }

            // 2. Glass type / summary comparison
            if ($order->glass_type !== $summaryGlassType) {
                $diffs[] = "Jenis Kaca: diubah dari '{$order->glass_type}' ➔ '{$summaryGlassType}'";
            }

            // 3. Dimensions comparison
            $oldLen = (float)$order->length_cm;
            $oldWid = (float)$order->width_cm;
            $newLen = (float)$primaryItem['length_cm'];
            $newWid = (float)$primaryItem['width_cm'];
            if ($oldLen !== $newLen || $oldWid !== $newWid) {
                $diffs[] = "Ukuran Kaca Utama: diubah dari {$oldLen}x{$oldWid} cm ➔ {$newLen}x{$newWid} cm";
            }

            // 4. Customer Address comparison
            $newAddress = !empty(trim($validated['customer_address'] ?? '')) ? $validated['customer_address'] : '-';
            if ($order->customer_address !== $newAddress) {
                $diffs[] = "Alamat Pengiriman: diubah dari '{$order->customer_address}' ➔ '{$newAddress}'";
            }

            // 5. Custom notes typed by Toko
            if (!empty($rawRevNotes) && $rawRevNotes !== '-') {
                $diffs[] = "Catatan Toko: \"{$rawRevNotes}\"";
            }

            $autoDiffText = !empty($diffs) 
                ? implode(' | ', $diffs) 
                : (!empty($rawRevNotes) ? $rawRevNotes : 'Revisi spesifikasi/desain dari Admin Toko.');

            $order->revision_notes = $autoDiffText;
            
            if ($order->current_division === 'admin_gudang') {
                $order->revision_status = 'pending_gudang';
            } else {
                $order->revision_status = 'pending_division';
            }

            $history = (array) ($order->revision_history ?? []);
            $history[] = [
                'revision_number' => $order->revision_count,
                'revised_at' => now()->toDateTimeString(),
                'revised_by' => auth()->user()->name ?? 'Admin Toko',
                'notes' => $autoDiffText,
                'user_notes' => $rawRevNotes,
                'changes_list' => $diffs,
                'glass_summary' => $summaryGlassType,
                'old_qty' => $oldTotalQty,
                'new_qty' => $newTotalQty,
            ];
            $order->revision_history = $history;
        }

        if ($isPromoted || $targetStatus === 'pengerjaan') {
            $order->status = 'pengerjaan';
            $rawPaid = $request->input('custom_paid_amount', $request->input('paid_amount', null));
            $paidAmount = $request->filled('custom_paid_amount') ? (float)$rawPaid : round(($totalPrice * (float)$request->input('dp_percent', 50)) / 100);

            if ($paidAmount >= $totalPrice && $totalPrice > 0) {
                $order->paid_amount = $totalPrice;
                $order->payment_status = 'Lunas';
            } else if ($paidAmount > 0) {
                $order->paid_amount = $paidAmount;
                $calcPct = round(($paidAmount / max(1, $totalPrice)) * 100);
                $order->payment_status = 'DP (' . $calcPct . '%)';
            } else {
                $order->paid_amount = 0;
                $order->payment_status = 'Belum Lunas';
            }

            if ($isPromoted) {
                $order->current_division = 'admin_gudang';
                $order->gudang_released_at = $order->gudang_released_at ?? now();
                $freshProgress = $this->buildDivisionProgress($items, $allProcs);
                $freshProgress['HT'] = 'Menunggu Dispatch';
                $order->division_progress = $freshProgress;
            } else {
                $existingProgress = (array) ($order->division_progress ?? []);
                $freshProgress = $this->buildDivisionProgress($items, $allProcs);
                foreach ($freshProgress as $code => $status) {
                    if ($status !== 'N/A' && (!isset($existingProgress[$code]) || $existingProgress[$code] === 'N/A')) {
                        $existingProgress[$code] = 'Belum';
                    }
                }
                $order->division_progress = $existingProgress;
            }
        } else if ($order->status === 'draft') {
            $order->paid_amount = $request->filled('custom_paid_amount') ? (float)$request->input('custom_paid_amount') : 0;
            $order->payment_status = 'Belum Lunas';
            $order->division_progress = $this->buildDivisionProgress($items, $allProcs);
        }

        $order->save();

        if ($isRevisionUpdate) {
            $destTarget = ($order->current_division === 'admin_gudang') ? 'Admin Gudang' : 'Seluruh Divisi Produksi';
            $message = 'Revisi Order #' . $order->spo_number . ' Berhasil Disimpan & Peringatan Terkirim ke ' . $destTarget . '!';
        } else {
            $message = $isPromoted 
                ? 'Draf Order #' . $order->spo_number . ' Berhasil Didealkan & Diterbitkan ke Admin Gudang!' 
                : 'Perubahan Draf Order #' . $order->spo_number . ' Berhasil Diperbarui!';
        }

        return redirect()->back()->with('message', $message);
    }

    /**
     * Promote Draft Order to Pengerjaan (Admin Toko / Sales)
     */
    public function promoteDraftToPengerjaan(Request $request, $id)
    {
        $order = Order::findOrFail($id);

        $request->validate([
            'dp_proof' => 'nullable|image|mimes:jpeg,png,jpg,webp,gif|max:10240',
            'payment_method' => 'nullable|string|max:100',
        ]);

        if ($request->hasFile('dp_proof')) {
            $dpPath = $request->file('dp_proof')->store('payment_proofs', 'public');
            $order->dp_proof_path = $dpPath;
        }
        if ($request->filled('payment_method')) {
            $order->payment_method = $request->input('payment_method');
        }

        $paymentOption = $request->input('payment_option', 'dp');
        $dpPercent = (float)$request->input('dp_percent', 50);
        $totalPrice = (float)$order->total_price;

        if ($paymentOption === 'lunas') {
            $paidAmount = $totalPrice;
            $paymentStatus = 'Lunas';
        } else {
            if ($paymentOption === 'custom' && $request->filled('custom_paid_amount') && (float)$request->input('custom_paid_amount') > 0) {
                $paidAmount = (float)$request->input('custom_paid_amount');
                if ($paidAmount >= $totalPrice && $totalPrice > 0) {
                    $paidAmount = $totalPrice;
                    $paymentStatus = 'Lunas';
                } else {
                    $calcPct = round(($paidAmount / max(1, $totalPrice)) * 100);
                    $paymentStatus = 'DP (' . $calcPct . '%)';
                }
            } else {
                $paidAmount = round(($totalPrice * $dpPercent) / 100);
                if ($paidAmount >= $totalPrice && $totalPrice > 0) {
                    $paidAmount = $totalPrice;
                    $paymentStatus = 'Lunas';
                } else {
                    $paymentStatus = 'DP (' . round($dpPercent) . '%)';
                }
            }
        }

        $order->status = 'pengerjaan';
        $order->payment_status = $paymentStatus;
        $order->paid_amount = $paidAmount;
        if ($paymentStatus === 'Lunas' && $order->dp_proof_path && !$order->payment_proof_path) {
            $order->payment_proof_path = $order->dp_proof_path;
        }
        $order->current_division = 'admin_gudang';
        $order->gudang_released_at = $order->gudang_released_at ?? now();
        $freshProgress = $this->buildDivisionProgress((array)($order->items ?? []), (array)($order->processes ?? []));
        $existingProgress = (array)$order->division_progress;
        foreach ($freshProgress as $code => $status) {
            if ($status !== 'N/A' && (!isset($existingProgress[$code]) || $existingProgress[$code] === 'N/A')) {
                $existingProgress[$code] = 'Belum';
            } elseif (!isset($existingProgress[$code])) {
                $existingProgress[$code] = $status;
            }
        }
        $existingProgress['HT'] = 'Menunggu Dispatch Admin Gudang';
        $order->division_progress = $existingProgress;

        // Potong stok master aksesoris gudang saat order deal & masuk pengerjaan
        if (is_array($order->accessories)) {
            foreach ($order->accessories as $acc) {
                if (is_array($acc)) {
                    $accId = $acc['id'] ?? null;
                    $accName = $acc['name'] ?? null;
                    $accQty = max(1, (int)($acc['qty'] ?? 1));
                    $accModel = null;
                    if ($accId && is_numeric($accId)) {
                        $accModel = \App\Models\Accessory::find($accId);
                    }
                    if (!$accModel && $accName) {
                        $accModel = \App\Models\Accessory::where('name', $accName)->first();
                    }
                    if ($accModel) {
                        $accModel->decrement('qty', min($accModel->qty, $accQty));
                        $accModel->update([
                            'status' => $accModel->qty > 20 ? 'Aman' : ($accModel->qty > 0 ? 'Menipis' : 'Habis')
                        ]);
                    }
                }
            }
        }

        $order->save();

        return redirect()->back()->with('message', 'Order Draft #' . $order->spo_number . ' Berhasil Deal (' . $paymentStatus . ') & Dikirim ke Admin Gudang!');
    }

    /**
     * Dispatch Order to Division (Admin Gudang / Kepala Produksi)
     */
    public function dispatchOrderToDivision(Request $request, $id)
    {
        $validated = $request->validate([
            'target_division' => 'nullable|string', // e.g. divisi_ht, divisi_gm, divisi_bv, divisi_etsa
        ]);

        $order = Order::findOrFail($id);

        if ($order->revision_status === 'pending_gudang') {
            $order->revision_status = 'pending_division';
        }

        // Determine all required processes/divisions for this order
        $procs = (array) ($order->processes ?? []);
        if (is_array($order->items)) {
            foreach ($order->items as $it) {
                if (isset($it['processes']) && is_array($it['processes'])) {
                    foreach ($it['processes'] as $p) {
                        if (!in_array($p, $procs)) {
                            $procs[] = $p;
                        }
                    }
                }
            }
        }
        if (empty($procs)) {
            $procs = ['HT'];
        }
        if (!in_array('HT', $procs)) {
            array_unshift($procs, 'HT');
        }

        $targetDiv = $validated['target_division'] ?? ('divisi_' . strtolower($procs[0]));
        $order->current_division = $targetDiv;
        $order->gudang_released_at = $order->gudang_released_at ?? now();
        
        $currentDivKey = $this->normalizeDivisionKey($targetDiv);
        $progress = (array) ($order->division_progress ?? []);

        // Ensure all required divisions are set in progress tracker
        $divCodes = ['HT', 'GM', 'BV', 'Etsa', 'Bor'];
        foreach ($divCodes as $code) {
            if (in_array($code, $procs) || in_array(strtoupper($code), array_map('strtoupper', $procs))) {
                if (!isset($progress[$code]) || $progress[$code] === 'N/A') {
                    $progress[$code] = 'Belum';
                }
            }
        }
        $progress[$currentDivKey] = 'Menunggu Pengerjaan';
        if ($currentDivKey !== strtoupper($currentDivKey)) {
            $progress[strtoupper($currentDivKey)] = 'Menunggu Pengerjaan';
        }

        $timestamps = (array) ($order->division_timestamps ?? []);
        if (!isset($timestamps[$currentDivKey]) || !is_array($timestamps[$currentDivKey])) {
            $timestamps[$currentDivKey] = ['started_at' => null, 'completed_at' => null];
        }

        $order->division_progress = $progress;
        $order->division_timestamps = $timestamps;
        $order->save();

        $divNames = array_map(function($p) {
            $norm = $this->normalizeDivisionKey((string) $p);
            $labels = [
                'HT' => 'Divisi HT (Potong)',
                'GM' => 'Divisi GM (Gosok)',
                'BV' => 'Divisi BV (Bevel)',
                'Etsa' => 'Divisi Etsa (Blur)',
                'Bor' => 'Divisi Bor (Drilling)',
            ];
            return $labels[$norm] ?? ($labels[$p] ?? ('Divisi ' . $p));
        }, $procs);

        return redirect()->back()->with('message', '🚀 Order #' . $order->spo_number . ' Berhasil Dikirim ke Divisi Bersangkutan: ' . implode(', ', $divNames) . '!');
    }

    /**
     * Complete Order Delivery (Pengiriman -> Selesai)
     */
    public function completeDelivery(Request $request, $id)
    {
        $order = Order::findOrFail($id);

        // Wajib sudah dicek / diverifikasi oleh Satpam sebelum mobil bisa foto bukti pengiriman
        $delivery = Delivery::where('order_id', $order->id)->first();
        $isGateChecked = $delivery && (
            !empty($delivery->gate_checked_at) ||
            !empty($delivery->gate_checked_by) ||
            in_array($delivery->delivery_status, ['Dalam Pengiriman', 'Selesai Terkirim', 'Terkirim'])
        );

        if (!$isGateChecked) {
            $errMsg = '⚠️ Akses Ditolak: Mobil belum dapat mengambil foto bukti pengiriman karena Surat Jalan dan muatan barang untuk Order #' . $order->spo_number . ' belum diverifikasi / ditandatangani oleh Satpam!';
            return redirect()->back()->withErrors(['proof_photo' => $errMsg])->with('message', $errMsg);
        }

        $validated = $request->validate([
            'proof_photo' => $order->proof_photo_path ? 'nullable|image|max:10240' : 'required|image|max:10240',
            'recipient_name' => 'nullable|string|max:255',
            'mark_lunas' => 'nullable|boolean',
            'payment_status' => 'nullable|string',
        ], [
            'proof_photo.required' => 'Wajib melampirkan foto Surat Jalan yang telah ditandatangani penerima sebelum mengonfirmasi pengiriman terkirim!',
            'proof_photo.image' => 'File bukti harus berupa gambar (JPG, PNG, JPEG, WEBP).',
            'proof_photo.max' => 'Ukuran foto bukti tidak boleh lebih dari 10 MB.',
        ]);

        if ($request->hasFile('proof_photo')) {
            $path = $request->file('proof_photo')->store('delivery_proofs', 'public');
            $order->proof_photo_path = $path;
        }

        if (!empty($validated['recipient_name'])) {
            $order->recipient_name = $validated['recipient_name'];
        }

        $order->status = 'selesai';
        $order->current_division = 'selesai';
        $order->delivered_at = $order->delivered_at ?? now();

        $userRole = auth()->user()->role ?? '';
        if ($userRole !== 'driver' && ($request->boolean('mark_lunas') || ($validated['payment_status'] ?? '') === 'Lunas')) {
            $order->payment_status = 'Lunas';
            $order->paid_amount = $order->total_price;
        }

        $order->save();

        Delivery::where('order_id', $order->id)->update([
            'delivery_status' => 'Selesai Terkirim',
            'proof_photo_path' => $order->proof_photo_path,
        ]);

        return redirect()->back()->with('message', '✅ Order #' . $order->spo_number . ' Berhasil Dikonfirmasi Selesai Terkirim ke Konsumen!');
    }

    /**
     * Check if an order has completely finished execution through all required divisions
     */
    protected function isOrderExecutionFinished(Order $order): bool
    {
        if (in_array($order->status, ['selesai', 'pengiriman']) || in_array($order->current_division, ['QC_Ready', 'pengiriman', 'driver'])) {
            return true;
        }

        if ($order->status === 'draft') {
            return false;
        }

        // Active production and internal prep divisions mean it is still being worked on
        $workingDivisions = ['admin_toko', 'admin_gudang', 'divisi_ht', 'divisi_gm', 'divisi_bv', 'divisi_etsa', 'divisi_bor'];
        if (in_array($order->current_division, $workingDivisions)) {
            return false;
        }

        if ($order->status === 'pengerjaan') {
            return false;
        }

        // Check division_progress array
        $progress = (array) ($order->division_progress ?? []);
        if (!empty($progress)) {
            foreach ($progress as $divCode => $status) {
                if ($status === 'N/A') {
                    continue;
                }
                $normKey = $this->normalizeDivisionKey((string) $divCode);
                $upperKey = strtoupper((string) $divCode);
                $effectiveStatus = ($progress[$normKey] ?? null) === 'Selesai' || ($progress[$upperKey] ?? null) === 'Selesai' ? 'Selesai' : $status;
                if ($effectiveStatus !== 'Selesai') {
                    return false;
                }
            }
        }

        return false;
    }

    /**
     * Satpam / Gate Checker - Memverifikasi fisik barang per Orderan SPO di mobil (Klik "Sesuai")
     */
    public function gateCheckOrder(Request $request, $id)
    {
        $userRole = auth()->user()->role ?? '';
        if ($userRole !== 'satpam' && $userRole !== 'owner') {
            return redirect()->back()->with('message', '⚠️ Akses Ditolak: Hanya Satpam / Gate Checker yang berhak memverifikasi kesesuaian barang di mobil!');
        }

        $order = Order::findOrFail($id);
        $delivery = \App\Models\Delivery::where('order_id', $order->id)->first();

        if (!$delivery) {
            $delivery = \App\Models\Delivery::create([
                'waybill_number' => 'SJ-' . ($order->spo_number ?? $order->id),
                'trip_code' => $order->trip_code ?: ('TRIP-' . $order->id),
                'stop_order' => 1,
                'order_id' => $order->id,
                'driver_name' => $order->assigned_driver ?: 'Supir Armada',
                'vehicle_plate' => $order->assigned_vehicle ?: 'Armada Pabrik',
                'waybill_color' => $order->payment_status === 'Lunas' ? 'Putih' : 'Merah',
                'delivery_status' => 'Dalam Pengiriman',
                'delivery_date' => $order->delivery_date ?: date('Y-m-d'),
                'notes' => 'Terverifikasi Sesuai oleh Satpam di Mobil Armada',
                'gate_checked_by' => auth()->id(),
                'gate_checked_at' => now(),
            ]);
        } else {
            $delivery->gate_checked_by = auth()->id();
            $delivery->gate_checked_at = now();
            if ($delivery->delivery_status === 'Menunggu Cek Satpam' || empty($delivery->delivery_status)) {
                $delivery->delivery_status = 'Dalam Pengiriman';
            }
            $delivery->save();
        }

        if ($order->status !== 'selesai') {
            $order->status = 'pengiriman';
            $order->current_division = 'driver';
            $order->save();
        }

        ActivityLog::create([
            'user_id' => auth()->id(),
            'admin_name' => auth()->user()->name ?? 'Petugas Satpam',
            'action_type' => 'CEK_SATPAM_ORDER_SESUAI',
            'target_user_name' => $order->spo_number,
            'description' => 'Satpam (' . (auth()->user()->name ?? 'Satpam') . ') telah memeriksa fisik barang di mobil armada (' . ($order->assigned_vehicle ?? '-') . ') untuk Order #' . $order->spo_number . ' dan mengonfirmasi jumlah barang SESUAI.',
            'created_at' => now(),
        ]);

        return redirect()->back()->with('message', '✅ [SUDAH DICEK SATPAM — SESUAI] Fisik barang untuk Order #' . $order->spo_number . ' di mobil (' . ($order->assigned_vehicle ?? 'Armada') . ') telah diverifikasi SESUAI oleh Satpam dan siap keluar mengirim!');
    }

    /**
     * Satpam / Gate Checker - Memverifikasi fisik seluruh barang pada 1 Trip Mobil dan mengizinkan truk keluar (Gate Pass Approved)
     */
    public function gateCheckDelivery(Request $request, $tripCode)
    {
        $userRole = auth()->user()->role ?? '';
        if ($userRole !== 'satpam' && $userRole !== 'owner') {
            return redirect()->back()->with('message', '⚠️ Akses Ditolak: Hanya Satpam / Gate Checker yang berhak memvalidasi Surat Barang Keluar di gerbang pabrik!');
        }

        $deliveries = \App\Models\Delivery::where('trip_code', $tripCode)->get();
        if ($deliveries->isEmpty()) {
            $ordersInTrip = Order::where('trip_code', $tripCode)->get();
            foreach ($ordersInTrip as $idx => $ord) {
                $del = \App\Models\Delivery::create([
                    'waybill_number' => 'SJ-' . ($ord->spo_number ?? $ord->id),
                    'trip_code' => $tripCode,
                    'stop_order' => $idx + 1,
                    'order_id' => $ord->id,
                    'driver_name' => $ord->assigned_driver ?: 'Supir Armada',
                    'vehicle_plate' => $ord->assigned_vehicle ?: 'Armada Pabrik',
                    'waybill_color' => $ord->payment_status === 'Lunas' ? 'Putih' : 'Merah',
                    'delivery_status' => 'Dalam Pengiriman',
                    'delivery_date' => $ord->delivery_date ?: date('Y-m-d'),
                    'notes' => 'Terverifikasi Sesuai oleh Satpam di Mobil Armada',
                    'gate_checked_by' => auth()->id(),
                    'gate_checked_at' => now(),
                ]);
                $deliveries->push($del);
            }
        }

        if ($deliveries->isEmpty()) {
            return redirect()->back()->withErrors(['message' => 'Surat Barang Keluar tidak ditemukan!']);
        }

        foreach ($deliveries as $del) {
            $del->gate_checked_by = auth()->id();
            $del->gate_checked_at = now();
            if ($del->delivery_status !== 'Selesai Terkirim') {
                $del->delivery_status = 'Dalam Pengiriman';
            }
            $del->save();
            
            // Sync status ke order terkait
            if ($del->order) {
                $order = $del->order;
                if ($order->status !== 'selesai') {
                    $order->status = 'pengiriman';
                    $order->current_division = 'driver';
                    $order->save();
                }
            }
        }

        ActivityLog::create([
            'user_id' => auth()->id(),
            'admin_name' => auth()->user()->name ?? 'Petugas Satpam',
            'action_type' => 'CEK_SATPAM_TRIP_SESUAI',
            'target_user_name' => $tripCode,
            'description' => 'Satpam (' . (auth()->user()->name ?? 'Satpam') . ') telah memeriksa seluruh muatan barang di mobil armada pada Trip #' . $tripCode . ' dan mengonfirmasi seluruh orderan SESUAI untuk keluar mengirim.',
            'created_at' => now(),
        ]);

        return redirect()->back()->with('message', '✅ [SUDAH DICEK SATPAM — SESUAI] Seluruh muatan barang pada mobil (Kode Trip: ' . $tripCode . ') telah diperiksa Satpam, dinyatakan SESUAI, dan diizinkan keluar mengirim.');
    }

    /**
     * Assign Batch Multi-Address Delivery to Vehicle and Driver
     */
    public function assignBatchDelivery(Request $request)
    {
        $isEditingTrip = !empty($request->input('trip_code'));

        $validated = $request->validate([
            'order_ids' => $isEditingTrip ? 'nullable|array' : 'required|array|min:1',
            'order_ids.*' => 'required|exists:orders,id',
            'driver_name' => 'required|string',
            'vehicle_plate' => 'required|string',
            'delivery_date' => 'nullable|date',
            'notes' => $isEditingTrip ? 'nullable|string' : 'required|string',
            'trip_code' => 'nullable|string',
            'order_updates' => 'nullable|array',
        ], [
            'notes.required' => '⚠️ Catatan Rute & Barang Penunjang Gudang WAJIB diisi sebelum menugaskan mobil armada!',
        ]);

        $tripCode = !empty($validated['trip_code']) ? $validated['trip_code'] : ('TRIP-' . date('Ymd') . '-' . rand(1000, 9999));
        $driverName = $validated['driver_name'];
        $vehiclePlate = $validated['vehicle_plate'];
        $deliveryDate = !empty($validated['delivery_date']) ? $validated['delivery_date'] : date('Y-m-d');
        $rawNotes = isset($validated['notes']) ? trim((string) $validated['notes']) : '';
        $notes = $rawNotes !== '' ? $rawNotes : null;
        $orderUpdates = is_array($validated['order_updates'] ?? null) ? $validated['order_updates'] : [];

        // If order_updates is provided (advanced Edit Trip modal), process per-order address/customer/vehicle changes
        if ($isEditingTrip && !empty($orderUpdates)) {
            $keptOrderIds = [];
            $stopCounterByTrip = [];

            foreach ($orderUpdates as $item) {
                $ordId = $item['id'] ?? null;
                if (!$ordId) {
                    continue;
                }
                $order = Order::find($ordId);
                if (!$order) {
                    continue;
                }

                // Update customer name, phone, and delivery address if edited
                if (array_key_exists('customer_name', $item) && trim((string) $item['customer_name']) !== '') {
                    $order->customer_name = trim((string) $item['customer_name']);
                }
                if (array_key_exists('customer_phone', $item) && trim((string) $item['customer_phone']) !== '') {
                    $order->customer_phone = trim((string) $item['customer_phone']);
                }
                if (array_key_exists('customer_address', $item) && trim((string) $item['customer_address']) !== '') {
                    $order->customer_address = trim((string) $item['customer_address']);
                }

                $action = $item['action'] ?? 'keep'; // 'keep' | 'move_vehicle' | 'unassign'

                if ($action === 'unassign') {
                    $order->assigned_driver = null;
                    $order->assigned_vehicle = null;
                    $order->trip_code = null;
                    $order->delivery_date = null;
                    if ($order->status !== 'selesai') {
                        $order->status = 'pengiriman';
                        $order->current_division = 'QC_Ready';
                    }
                    $order->save();

                    Delivery::where('order_id', $order->id)->delete();
                    continue;
                }

                // Determine target vehicle, driver, date, and trip_code for this order
                $targetVehicle = !empty($item['target_vehicle']) ? $item['target_vehicle'] : $vehiclePlate;
                $targetDriver = !empty($item['target_driver']) ? $item['target_driver'] : $driverName;
                $targetDate = !empty($item['target_date']) ? $item['target_date'] : $deliveryDate;

                if ($action === 'move_vehicle' && $targetVehicle !== $vehiclePlate) {
                    // Check if there is already an active trip for $targetVehicle on $targetDate
                    $existingTargetDelivery = Delivery::where('vehicle_plate', $targetVehicle)
                        ->where('delivery_date', $targetDate)
                        ->where('trip_code', '!=', $tripCode)
                        ->first();

                    if ($existingTargetDelivery && !empty($existingTargetDelivery->trip_code)) {
                        $targetTripCode = $existingTargetDelivery->trip_code;
                        if (empty($item['target_driver']) && !empty($existingTargetDelivery->driver_name)) {
                            $targetDriver = $existingTargetDelivery->driver_name;
                        }
                    } else {
                        $dateCompact = str_replace('-', '', $targetDate);
                        $targetTripCode = !empty($item['target_trip_code'])
                            ? $item['target_trip_code']
                            : ('TRIP-' . $dateCompact . '-' . rand(1000, 9999));
                    }
                } else {
                    $targetTripCode = $tripCode;
                    $targetVehicle = $vehiclePlate;
                    $targetDriver = $driverName;
                    $targetDate = $deliveryDate;
                    $keptOrderIds[] = $order->id;
                }

                if (!isset($stopCounterByTrip[$targetTripCode])) {
                    $stopCounterByTrip[$targetTripCode] = 0;
                }
                $stopCounterByTrip[$targetTripCode]++;
                $stopOrder = $stopCounterByTrip[$targetTripCode];

                $order->assigned_driver = $targetDriver;
                $order->assigned_vehicle = $targetVehicle;
                $order->trip_code = $targetTripCode;
                $order->delivery_date = $targetDate;
                if ($order->status !== 'selesai') {
                    $order->status = 'pengiriman';
                    $order->current_division = 'pengiriman';
                }
                $order->shipped_at = $order->shipped_at ?? now();
                $order->save();

                $waybillColor = $order->payment_status === 'Lunas' ? 'Putih' : 'Merah';
                $existingDelivery = Delivery::where('order_id', $order->id)->first();
                $effectiveNotes = $notes ?? ($existingDelivery?->notes ?? 'Penugasan Pengiriman Armada');
                $effectiveStatus = $existingDelivery?->delivery_status ?? 'Menunggu Cek Satpam';

                Delivery::updateOrCreate(
                    ['order_id' => $order->id],
                    [
                        'waybill_number' => 'SJ-' . ($order->spo_number ?? $order->id),
                        'trip_code' => $targetTripCode,
                        'stop_order' => $stopOrder,
                        'driver_name' => $targetDriver,
                        'vehicle_plate' => $targetVehicle,
                        'waybill_color' => $waybillColor,
                        'delivery_status' => $effectiveStatus,
                        'delivery_date' => $targetDate,
                        'notes' => $effectiveNotes,
                    ]
                );
            }

            // Also sync any remaining deliveries in the main tripCode if orders stayed
            if (!empty($keptOrderIds)) {
                $tripUpdatePayload = [
                    'driver_name' => $driverName,
                    'vehicle_plate' => $vehiclePlate,
                    'delivery_date' => $deliveryDate,
                ];
                if ($notes !== null) {
                    $tripUpdatePayload['notes'] = $notes;
                }
                Delivery::where('trip_code', $tripCode)->whereIn('order_id', $keptOrderIds)->update($tripUpdatePayload);
            }

            return redirect()->back()->with('message', '🚚 Data Rute, Alamat Kiriman, & Penugasan Mobil pada Trip #' . $tripCode . ' berhasil diperbarui!');
        }

        $orderIds = $validated['order_ids'] ?? [];
        $orders = Order::whereIn('id', $orderIds)->get();

        // Strict Validation: Ensure all selected orders have completely finished execution through the last division
        $unreadyOrders = [];
        foreach ($orders as $order) {
            if (!$this->isOrderExecutionFinished($order)) {
                $unreadyOrders[] = 'SPO #' . ($order->spo_number ?? $order->id);
            }
        }

        if (!empty($unreadyOrders)) {
            return redirect()->back()->withErrors([
                'message' => '⚠️ Gagal Mengatur Pengiriman: Order ' . implode(', ', $unreadyOrders) . ' belum selesai dieksekusi oleh divisi terakhir!'
            ])->with('error', '⚠️ Gagal Mengatur Pengiriman: Order ' . implode(', ', $unreadyOrders) . ' belum selesai dieksekusi oleh divisi terakhir!');
        }

        foreach ($orders as $index => $order) {
            $stopOrder = $index + 1;

            $order->assigned_driver = $driverName;
            $order->assigned_vehicle = $vehiclePlate;
            $order->trip_code = $tripCode;
            $order->delivery_date = $deliveryDate;
            if ($order->status !== 'selesai') {
                $order->status = 'pengiriman';
                $order->current_division = 'pengiriman';
            }
            $order->shipped_at = $order->shipped_at ?? now();
            $order->save();

            $waybillColor = $order->payment_status === 'Lunas' ? 'Putih' : 'Merah';
            $existingDelivery = Delivery::where('order_id', $order->id)->first();
            $effectiveNotes = $notes ?? ($existingDelivery?->notes ?? 'Penugasan Pengiriman Armada');
            $effectiveStatus = $existingDelivery?->delivery_status ?? 'Menunggu Cek Satpam';

            Delivery::updateOrCreate(
                ['order_id' => $order->id],
                [
                    'waybill_number' => 'SJ-' . ($order->spo_number ?? $order->id),
                    'trip_code' => $tripCode,
                    'stop_order' => $stopOrder,
                    'driver_name' => $driverName,
                    'vehicle_plate' => $vehiclePlate,
                    'waybill_color' => $waybillColor,
                    'delivery_status' => $effectiveStatus,
                    'delivery_date' => $deliveryDate,
                    'notes' => $effectiveNotes,
                ]
            );
        }

        if ($isEditingTrip) {
            $tripUpdatePayload = [
                'driver_name' => $driverName,
                'vehicle_plate' => $vehiclePlate,
                'delivery_date' => $deliveryDate,
            ];
            if ($notes !== null) {
                $tripUpdatePayload['notes'] = $notes;
            }
            Delivery::where('trip_code', $tripCode)->update($tripUpdatePayload);
        }

        return redirect()->back()->with('message', '🚚 Rute Pengiriman Armada #' . $tripCode . ' Berhasil Ditetapkan (' . $driverName . ' — ' . $vehiclePlate . ')! Otomatis masuk ke Admin Gudang (Siap Cetak SJ 4 Warna & Gate Pass) & terbit di Tugas Pengiriman Divisi Supir.');
    }

    /**
     * Store Special Pickup / Fetching Order (Surat Perintah Pengambilan Barang Armada)
     */
    public function storePickupDispatch(Request $request)
    {
        $validated = $request->validate([
            'driver_name' => 'required|string',
            'vehicle_plate' => 'required|string',
            'delivery_date' => 'nullable|date',
            'notes' => 'nullable|string',
            'merge_existing_trip' => 'nullable|boolean',
            'stops' => 'required|array|min:1',
            'stops.*.location_name' => 'required|string',
            'stops.*.contact_phone' => 'nullable|string',
            'stops.*.address' => 'required|string',
            'stops.*.item_description' => 'required|string',
            'stops.*.qty' => 'nullable|numeric|min:1',
            'stops.*.unit' => 'nullable|string',
        ], [
            'stops.required' => '⚠️ Minimal masukkan 1 alamat pengambilan barang!',
            'stops.*.location_name.required' => '⚠️ Nama lokasi / toko / supplier tempat pengambilan wajib diisi!',
            'stops.*.address.required' => '⚠️ Alamat lokasi pengambilan wajib diisi!',
            'stops.*.item_description.required' => '⚠️ Nama barang yang akan diambil wajib diisi!',
        ]);

        $driverName = $validated['driver_name'];
        $vehiclePlate = $validated['vehicle_plate'];
        $deliveryDate = !empty($validated['delivery_date']) ? $validated['delivery_date'] : date('Y-m-d');
        $rawNotes = isset($validated['notes']) ? trim((string) $validated['notes']) : '';
        $notes = $rawNotes !== '' ? $rawNotes : 'Surat Perintah Tugas Pengambilan Barang / Material oleh Armada Pabrik.';
        $mergeExisting = (bool) ($validated['merge_existing_trip'] ?? false);

        $tripCode = null;
        $startingStopOrder = 0;

        if ($mergeExisting) {
            $existingTripDel = Delivery::where('vehicle_plate', $vehiclePlate)
                ->where('delivery_date', $deliveryDate)
                ->first();
            if ($existingTripDel && !empty($existingTripDel->trip_code)) {
                $tripCode = $existingTripDel->trip_code;
                $startingStopOrder = (int) Delivery::where('trip_code', $tripCode)->max('stop_order');
            }
        }

        if (!$tripCode) {
            $dateCompact = str_replace('-', '', $deliveryDate);
            $tripCode = 'TRIP-AMBIL-' . $dateCompact . '-' . rand(100, 999);
        }

        $createdSpos = [];

        foreach ($validated['stops'] as $idx => $stop) {
            $stopOrder = $startingStopOrder + $idx + 1;
            $nextId = (Order::max('id') ?? 0) + 1;
            $spbNumber = 'SPB-' . str_pad($nextId, 4, '0', STR_PAD_LEFT);
            while (Order::where('spo_number', $spbNumber)->exists()) {
                $nextId++;
                $spbNumber = 'SPB-' . str_pad($nextId, 4, '0', STR_PAD_LEFT);
            }

            $qty = isset($stop['qty']) && (float) $stop['qty'] > 0 ? (int) $stop['qty'] : 1;
            $unit = !empty($stop['unit']) ? trim((string) $stop['unit']) : 'Unit/Pcs';
            $itemDesc = trim((string) $stop['item_description']);
            $itemLabel = '[AMBIL BARANG] ' . $itemDesc . ' (' . $qty . ' ' . $unit . ')';

            $order = Order::create([
                'order_date' => $deliveryDate,
                'spo_number' => $spbNumber,
                'customer_name' => trim((string) $stop['location_name']),
                'customer_phone' => !empty($stop['contact_phone']) ? trim((string) $stop['contact_phone']) : '-',
                'customer_address' => trim((string) $stop['address']),
                'glass_type' => $itemLabel,
                'length_cm' => 0,
                'width_cm' => 0,
                'thickness_mm' => 0,
                'processes' => ['HT'],
                'accessories' => [],
                'items' => [
                    [
                        'glass_type' => $itemLabel,
                        'length_cm' => 0,
                        'width_cm' => 0,
                        'thickness_mm' => 0,
                        'qty' => $qty,
                        'unit' => $unit,
                        'is_pickup_task' => true,
                        'processes' => [],
                        'subtotal' => 0,
                    ]
                ],
                'description' => 'SURAT PERINTAH PENGAMBILAN BARANG: Ambil ' . $itemDesc . ' (' . $qty . ' ' . $unit . ') di ' . trim((string) $stop['location_name']),
                'priority_status' => 'Prioritas',
                'deadline_date' => $deliveryDate,
                'subtotal' => 0,
                'priority_fee' => 0,
                'custom_fee' => 0,
                'total_price' => 0,
                'paid_amount' => 0,
                'payment_status' => 'Lunas',
                'status' => 'pengiriman',
                'assigned_driver' => $driverName,
                'assigned_vehicle' => $vehiclePlate,
                'trip_code' => $tripCode,
                'current_division' => 'pengiriman',
                'division_progress' => [
                    'HT' => 'Selesai',
                    'GM' => 'N/A',
                    'BV' => 'N/A',
                    'Etsa' => 'N/A',
                    'Bor' => 'N/A',
                ],
                'is_company_use' => true,
                'gudang_released_at' => now(),
                'execution_completed_at' => now(),
                'shipped_at' => now(),
                'delivery_date' => $deliveryDate,
            ]);

            Delivery::create([
                'waybill_number' => 'SJ-' . $spbNumber,
                'trip_code' => $tripCode,
                'stop_order' => $stopOrder,
                'order_id' => $order->id,
                'driver_name' => $driverName,
                'vehicle_plate' => $vehiclePlate,
                'waybill_color' => 'Kuning',
                'delivery_status' => 'Menunggu Cek Satpam',
                'delivery_date' => $deliveryDate,
                'notes' => '[PERINTAH AMBIL BARANG] ' . $notes,
            ]);

            $createdSpos[] = $spbNumber;
        }

        return redirect()->back()->with('message', '📋 Surat Perintah Pengambilan Barang (' . implode(', ', $createdSpos) . ') pada Trip #' . $tripCode . ' (' . $driverName . ' — ' . $vehiclePlate . ') berhasil diterbitkan! Anda dapat langsung mencetak Surat Perintah Jalan & Gate Pass.');
    }

    /**
     * Store Scrap Glass (Divisi HT)
     */
    public function storeScrap(Request $request)
    {
        $validated = $request->validate([
            'glass_type' => 'required|string',
            'length_cm' => 'required|numeric',
            'width_cm' => 'required|numeric',
            'rak_location' => 'required|string',
        ]);

        $nextId = (ScrapGlass::max('id') ?? 0) + 1;
        $code = 'SCRAP-' . str_pad($nextId, 4, '0', STR_PAD_LEFT);
        while (ScrapGlass::where('scrap_code', $code)->exists()) {
            $nextId++;
            $code = 'SCRAP-' . str_pad($nextId, 4, '0', STR_PAD_LEFT);
        }

        ScrapGlass::create([
            'scrap_code' => $code,
            'glass_type' => $validated['glass_type'],
            'length_cm' => $validated['length_cm'],
            'width_cm' => $validated['width_cm'],
            'rak_location' => $validated['rak_location'],
            'status' => 'Layak Pakai',
        ]);

        return redirect()->back()->with('message', 'Kaca Sisa ' . $code . ' Berhasil Disimpan di ' . $validated['rak_location']);
    }

    /**
     * Lock order for Admin Gudang & Divisions when Admin Toko opens edit/revision modal
     */
    public function lockRevisionEdit(Request $request, $id)
    {
        $order = Order::findOrFail($id);
        if ($order->status === 'pengerjaan') {
            $order->revision_status = 'editing';
            $order->save();
        }
        return redirect()->back();
    }

    /**
     * Cancel revision edit lock if Admin Toko closes edit modal without saving
     */
    public function cancelRevisionLock(Request $request, $id)
    {
        $order = Order::findOrFail($id);
        if ($order->revision_status === 'editing') {
            $order->revision_status = $order->is_revised ? 'acknowledged' : 'none';
            $order->save();
        }
        return redirect()->back();
    }

    /**
     * Submit Revision from Admin Toko
     */
    public function submitRevision(Request $request, $id)
    {
        $order = Order::findOrFail($id);
        $notes = $request->input('notes', 'Revisi ukuran & spesifikasi dari Admin Toko.');
        $order->is_revised = true;
        $order->revision_count = ($order->revision_count ?? 0) + 1;
        $order->revision_notes = $notes;
        $order->revision_status = ($order->current_division === 'admin_gudang') ? 'pending_gudang' : 'pending_division';

        $history = (array) ($order->revision_history ?? []);
        $history[] = [
            'revised_at' => now()->toDateTimeString(),
            'revised_by' => auth()->user()->name ?? 'Admin Toko',
            'notes' => $notes,
            'glass_summary' => $order->glass_type,
        ];
        $order->revision_history = $history;
        $order->save();

        return redirect()->back()->with('message', 'Peringatan Revisi Order ' . $order->spo_number . ' Berhasil Dikirim!');
    }

    /**
     * Acknowledge / Accept Revision (Admin Gudang or Division Worker like Divisi Potong HT)
     */
    public function acknowledgeRevision(Request $request, $id)
    {
        $order = Order::findOrFail($id);

        if ($order->revision_status === 'pending_gudang') {
            $order->revision_status = 'acknowledged';
            $order->save();
            return redirect()->back()->with('message', '✅ Revisi Order #' . $order->spo_number . ' Berhasil Dikonfirmasi Admin Gudang! SPO siap didisposisi.');
        }

        if ($order->revision_status === 'pending_division') {
            $order->revision_status = 'acknowledged';
            $order->save();
            return redirect()->back()->with('message', '🔄 Revisi SPO #' . $order->spo_number . ' Berhasil Diterima & Disetujui Pekerja Divisi! Silakan lanjutkan pekerjaan.');
        }

        $order->revision_status = 'acknowledged';
        $order->save();

        return redirect()->back()->with('message', 'Status revisi SPO #' . $order->spo_number . ' Berhasil Dikonfirmasi.');
    }

    /**
     * Start Working on Division Job (Menunggu -> Sedang Dikerjakan)
     */
    public function startDivisionJob(Request $request, $id)
    {
        $order = Order::findOrFail($id);
        $userRole = auth()->user()->role ?? '';

        if ($userRole !== $order->current_division && $userRole !== 'admin_gudang' && $userRole !== 'owner') {
            return redirect()->back()->with('message', '⚠️ Akses Ditolak: Anda hanya memiliki izin untuk memulai pengerjaan pada divisi Anda sendiri!');
        }

        if ($order->revision_status === 'pending_division') {
            return redirect()->back()->with('message', '⚠️ Akses Ditolak: Orderan #' . $order->spo_number . ' sedang memiliki revisian dari Admin Toko! Harap klik button Terima & Eksekusi Revisi SPO terlebih dahulu.');
        }

        if ($order->complaint_status === 'pending_gudang') {
            return redirect()->back()->with('message', '⚠️ Akses Ditolak: Orderan #' . $order->spo_number . ' sedang dalam proses pelaporan kaca cacat/baret ke Admin Gudang!');
        }

        $currentDiv = $order->current_division;
        $currentDivKey = $this->normalizeDivisionKey($currentDiv);
        $upperDivKey = strtoupper(str_replace('divisi_', '', $currentDiv));
        $progress = (array) ($order->division_progress ?? []);
        $timestamps = (array) ($order->division_timestamps ?? []);

        if ($currentDivKey) {
            $progress[$currentDivKey] = 'Sedang Dikerjakan';
            $progress[$upperDivKey] = 'Sedang Dikerjakan';
            $startedAt = now()->toDateTimeString();
            foreach (array_unique([$currentDivKey, $upperDivKey]) as $k) {
                if (!isset($timestamps[$k]) || !is_array($timestamps[$k])) {
                    $timestamps[$k] = ['started_at' => null, 'completed_at' => null];
                }
                if (empty($timestamps[$k]['started_at'])) {
                    $timestamps[$k]['started_at'] = $startedAt;
                }
            }
        }

        $order->division_progress = $progress;
        $order->division_timestamps = $timestamps;
        $order->save();

        return redirect()->back()->with('message', 'Order #' . $order->spo_number . ' Berhasil Dimulai! Status saat ini: Sedang Dikerjakan di Divisi ' . $currentDivKey);
    }

    /**
     * Complete Division Work or Transfer to Next Division
     */
    public function finishDivisionJob(Request $request, $id)
    {
        $order = Order::findOrFail($id);
        $userRole = auth()->user()->role ?? '';

        // Strict Authorization: Only assigned division staff, admin_gudang, owner, or admin_toko can execute
        if ($userRole !== $order->current_division && $userRole !== 'admin_gudang' && $userRole !== 'owner' && $userRole !== 'admin_toko') {
            return redirect()->back()->with('message', '⚠️ Akses Ditolak: Anda hanya memiliki izin untuk mengeksekusi pekerjaan pada divisi Anda sendiri!');
        }

        if ($order->revision_status === 'pending_division') {
            return redirect()->back()->with('message', '⚠️ Akses Ditolak: Orderan #' . $order->spo_number . ' sedang memiliki revisian yang belum dikonfirmasi! Harap klik button Terima & Eksekusi Revisi SPO terlebih dahulu sebelum menyelesaikan pekerjaan.');
        }

        if ($order->complaint_status === 'pending_gudang') {
            return redirect()->back()->with('message', '⚠️ Akses Ditolak: Orderan #' . $order->spo_number . ' sedang dalam proses pelaporan kaca cacat/baret ke Admin Gudang!');
        }

        $currentDiv = $order->current_division;

        // Auto compute next division according to order's process sequence (HT -> GM -> BV -> ETSA -> BOR -> QC_Ready)
        $autoNextDiv = function ($ord) {
            $fixedSeq = ['HT', 'GM', 'BV', 'ETSA', 'BOR'];
            $reqCodes = ['HT'];
            $addProcess = function ($p) use (&$reqCodes) {
                $code = strtoupper(trim((string)$p));
                if (in_array($code, ['GM', 'BV', 'ETSA', 'BOR']) && !in_array($code, $reqCodes)) {
                    $reqCodes[] = $code;
                }
            };

            $processes = is_array($ord->processes) ? $ord->processes : json_decode($ord->processes ?? '[]', true);
            if (is_array($processes)) {
                foreach ($processes as $p) $addProcess($p);
            }

            $items = is_array($ord->items) ? $ord->items : json_decode($ord->items ?? '[]', true);
            if (is_array($items)) {
                foreach ($items as $it) {
                    $itProcesses = is_array($it['processes'] ?? null) ? $it['processes'] : json_decode($it['processes'] ?? '[]', true);
                    if (is_array($itProcesses)) {
                        foreach ($itProcesses as $p) $addProcess($p);
                    }
                }
            }

            usort($reqCodes, function ($a, $b) use ($fixedSeq) {
                $posA = array_search($a, $fixedSeq);
                $posB = array_search($b, $fixedSeq);
                return ($posA !== false ? $posA : 99) <=> ($posB !== false ? $posB : 99);
            });

            $curKey = strtoupper(str_replace('divisi_', '', $ord->current_division ?? ''));
            $curIdx = array_search($curKey, $reqCodes);
            if ($curIdx !== false && $curIdx < count($reqCodes) - 1) {
                $map = ['HT' => 'divisi_ht', 'GM' => 'divisi_gm', 'BV' => 'divisi_bv', 'ETSA' => 'divisi_etsa', 'BOR' => 'divisi_bor'];
                $nextKey = $reqCodes[$curIdx + 1];
                return $map[$nextKey] ?? 'QC_Ready';
            }

            return 'QC_Ready';
        };

        if ($userRole === 'owner' && $request->filled('next_division') && $request->input('next_division') !== 'auto') {
            $nextDiv = $request->input('next_division');
        } else {
            $nextDiv = $autoNextDiv($order);
        }

        $currentDivKey = $this->normalizeDivisionKey($currentDiv);
        $upperDivKey = strtoupper(str_replace('divisi_', '', $currentDiv));
        $progress = (array) ($order->division_progress ?? []);
        $timestamps = (array) ($order->division_timestamps ?? []);

        if ($currentDivKey) {
            $progress[$currentDivKey] = 'Selesai';
            $progress[$upperDivKey] = 'Selesai';
            $nowStr = now()->toDateTimeString();
            foreach (array_unique([$currentDivKey, $upperDivKey]) as $k) {
                if (!isset($timestamps[$k]) || !is_array($timestamps[$k])) {
                    $timestamps[$k] = ['started_at' => null, 'completed_at' => null];
                }
                if (empty($timestamps[$k]['started_at'])) {
                    $timestamps[$k]['started_at'] = $nowStr;
                }
                $timestamps[$k]['completed_at'] = $nowStr;
            }
        }

        if ($order->is_revised) {
            $order->revision_status = 'resolved';
        }

        if ($order->complaint_status === 're_cut_needed' && $currentDiv === 'divisi_ht') {
            $order->complaint_status = 'resolved';
        }

        if ($nextDiv === 'QC_Ready' || $nextDiv === 'pengiriman') {
            $order->status = 'pengiriman';
            $order->current_division = 'QC_Ready';
            $order->execution_completed_at = $order->execution_completed_at ?? now();
            $order->shipped_at = $order->shipped_at ?? now();
            $order->division_progress = $progress;
            $order->division_timestamps = $timestamps;
            $order->save();
            $msg = 'Pekerjaan Divisi untuk #' . $order->spo_number . ' Selesai & Lolos QC! Siap Dikirim ke Driver.';
        } else {
            $nextDivKey = $this->normalizeDivisionKey($nextDiv);
            $nextUpperKey = strtoupper(str_replace('divisi_', '', $nextDiv));
            $progress[$nextDivKey] = 'Menunggu Pengerjaan';
            $progress[$nextUpperKey] = 'Menunggu Pengerjaan';
            foreach (array_unique([$nextDivKey, $nextUpperKey]) as $nk) {
                if (!isset($timestamps[$nk]) || !is_array($timestamps[$nk])) {
                    $timestamps[$nk] = ['started_at' => null, 'completed_at' => null];
                }
            }

            $order->status = 'pengerjaan';
            $order->current_division = $nextDiv;
            $order->division_progress = $progress;
            $order->division_timestamps = $timestamps;
            $order->save();

            $nextDivLabel = strtoupper(str_replace('_', ' ', $nextDiv));
            $msg = 'Pekerjaan #' . $order->spo_number . ' Selesai di ' . $currentDivKey . ' & Berhasil Diteruskan ke ' . $nextDivLabel . '!';
        }

        return redirect()->back()->with('message', $msg);
    }

    /**
     * Record Raw Material (Sheet Glass) Usage for Order (Divisi HT Potong)
     */
    public function recordRawMaterialUsage(Request $request, $id)
    {
        $order = Order::findOrFail($id);
        $userRole = auth()->user()->role ?? '';

        if ($userRole !== 'divisi_ht' && $userRole !== 'admin_gudang' && $userRole !== 'owner') {
            return redirect()->back()->with('message', '⚠️ Akses Ditolak: Hanya Divisi Potong (HT) atau Admin Gudang yang dapat mencatat pemakaian bahan lembaran!');
        }

        $validated = $request->validate([
            'glass_type' => 'required|string',
            'sheets_used' => 'required|numeric|min:1',
            'notes' => 'nullable|string',
        ]);

        // Kurangi stok SheetGlass dengan pencarian cerdas (Exact Match -> LIKE Match -> Ketebalan & Keyword)
        $sheetGlass = \App\Models\SheetGlass::where('name', $validated['glass_type'])->first();
        if (!$sheetGlass) {
            $sheetGlass = \App\Models\SheetGlass::where('name', 'like', '%' . $validated['glass_type'] . '%')->first();
        }
        if (!$sheetGlass) {
            preg_match('/(\d+)\s*mm/i', $validated['glass_type'], $tm);
            $thick = $tm[1] ?? null;
            $gtLower = strtolower($validated['glass_type']);
            $matchedKw = null;
            foreach (['cermin', 'mirror', 'bening', 'clear', 'tempered', 'riben', 'etsa', 'laminated', 'bronze', 'grey'] as $k) {
                if (str_contains($gtLower, $k)) { $matchedKw = $k; break; }
            }
            $query = \App\Models\SheetGlass::query();
            if ($thick) {
                $query->where('thickness_mm', (int)$thick);
            }
            if ($matchedKw) {
                $query->where(function($q) use ($matchedKw) {
                    $q->where('name', 'like', "%{$matchedKw}%")->orWhere('category', 'like', "%{$matchedKw}%");
                });
            }
            $sheetGlass = $query->first();
        }

        if (!$sheetGlass) {
            $sheetGlass = \App\Models\SheetGlass::first();
        }

        if (!$sheetGlass) {
            return redirect()->back()->with('message', '❌ Gagal: Katalog Master Stok Kaca di Gudang kosong! Harap tambahkan stok lembaran kaca terlebih dahulu.');
        }

        $sheetsUsed = (int) $validated['sheets_used'];
        if ($sheetGlass->qty < $sheetsUsed) {
            return redirect()->back()->with('message', '❌ Gagal: Stok lembaran kaca "' . $sheetGlass->name . '" di Gudang tidak mencukupi (Tersisa: ' . $sheetGlass->qty . ' lembar, Dibutuhkan: ' . $sheetsUsed . ' lembar)!');
        }

        // Kurangi kuantitas & perbarui status alert stok secara otomatis
        $newQty = max(0, $sheetGlass->qty - $sheetsUsed);
        $newStatus = $newQty > 10 ? 'Aman' : ($newQty > 0 ? 'Menipis' : 'Habis');
        $sheetGlass->qty = $newQty;
        $sheetGlass->status = $newStatus;
        $sheetGlass->save();

        // 10. Kaca lembaran baru yang dipakai otomatis masuk ke stok kaca sisa (ScrapGlass)
        $sheetLen = (float) ($sheetGlass->length_cm ?: 244);
        $sheetWid = (float) ($sheetGlass->width_cm ?: 183);

        $maxItemLen = 0;
        $maxItemWid = 0;
        $items = is_array($order->items) ? $order->items : json_decode($order->items ?? '[]', true);
        if (is_array($items) && count($items) > 0) {
            foreach ($items as $it) {
                $l = (float) ($it['length_cm'] ?? 0);
                $w = (float) ($it['width_cm'] ?? 0);
                if ($l > $maxItemLen) $maxItemLen = $l;
                if ($w > $maxItemWid) $maxItemWid = $w;
            }
        } else {
            $maxItemLen = (float) ($order->length_cm ?? 0);
            $maxItemWid = (float) ($order->width_cm ?? 0);
        }

        $remLen = max(10, round($sheetLen - $maxItemLen, 1));
        $remWid = max(10, round($sheetWid - $maxItemWid, 1));

        if ($remLen < 15 && $remWid >= 15) {
            $offcutLen = $sheetLen;
            $offcutWid = $remWid;
        } elseif ($remWid < 15 && $remLen >= 15) {
            $offcutLen = $remLen;
            $offcutWid = $sheetWid;
        } else {
            $offcutLen = $remLen > 0 ? $remLen : round($sheetLen * 0.4, 1);
            $offcutWid = $remWid > 0 ? $remWid : round($sheetWid * 0.6, 1);
        }

        $gtLower = strtolower($validated['glass_type']);
        $rakLoc = 'Rak A01';
        if (str_contains($gtLower, 'cermin') || str_contains($gtLower, 'mirror')) {
            $rakLoc = 'Rak A02';
        } elseif (str_contains($gtLower, 'tempered') || str_contains($gtLower, 'bevel')) {
            $rakLoc = 'Rak B01';
        } elseif (str_contains($gtLower, 'etsa') || str_contains($gtLower, 'sandblast')) {
            $rakLoc = 'Rak B02';
        }

        $sheetsUsed = (int) $validated['sheets_used'];
        $createdScraps = [];

        for ($i = 0; $i < $sheetsUsed; $i++) {
            $maxScrapId = \App\Models\ScrapGlass::max('id') ?? 0;
            $scrapCode = 'SCRAP-' . str_pad($maxScrapId + 1 + $i, 4, '0', STR_PAD_LEFT);
            while (\App\Models\ScrapGlass::where('scrap_code', $scrapCode)->exists()) {
                $maxScrapId++;
                $scrapCode = 'SCRAP-' . str_pad($maxScrapId + 1 + $i, 4, '0', STR_PAD_LEFT);
            }

            \App\Models\ScrapGlass::create([
                'scrap_code' => $scrapCode,
                'glass_type' => $validated['glass_type'],
                'length_cm' => $offcutLen,
                'width_cm' => $offcutWid,
                'rak_location' => $rakLoc,
                'status' => 'Layak Pakai',
            ]);

            $createdScraps[] = $scrapCode;

            ActivityLog::create([
                'user_id' => auth()->id(),
                'admin_name' => auth()->user()->name ?? 'Pekerja Divisi HT',
                'action_type' => 'AUTO_SCRAP_OFFCUT',
                'target_user_name' => $scrapCode,
                'description' => "Otomatis menyimpan sisa potongan lembaran {$validated['glass_type']} ({$offcutLen}×{$offcutWid} cm) ke {$rakLoc} dari pemotongan SPO-{$order->spo_number}.",
                'created_at' => now(),
            ]);
        }

        $rawUsage = (array) ($order->raw_materials_used ?? []);
        $rawUsage[] = [
            'id' => time() . rand(100, 999),
            'glass_type' => $validated['glass_type'],
            'sheets_used' => (int) $validated['sheets_used'],
            'notes' => $validated['notes'] ?? 'Pemotongan bahan lembaran baru Divisi HT',
            'recorded_by' => auth()->user()->name ?? 'Pekerja Divisi HT',
            'recorded_at' => now()->toDateTimeString(),
            'auto_scraps' => $createdScraps,
        ];

        $order->raw_materials_used = $rawUsage;
        $order->save();

        ActivityLog::create([
            'user_id' => auth()->id(),
            'admin_name' => auth()->user()->name ?? 'Pekerja Divisi HT',
            'action_type' => 'CATAT_BAHAN_KACA',
            'target_user_name' => $order->spo_number,
            'description' => 'Mencatat pemakaian ' . $validated['sheets_used'] . ' lembar bahan kaca (' . $validated['glass_type'] . ') untuk SPO ' . $order->spo_number . (!empty($createdScraps) ? ' (Sisa potongan otomatis masuk ke Kaca Sisa: ' . implode(', ', $createdScraps) . ')' : ''),
            'created_at' => now(),
        ]);

        $successMsg = '✅ Pemakaian ' . $validated['sheets_used'] . ' lembar bahan kaca (' . $validated['glass_type'] . ') berhasil dicatat untuk SPO ' . $order->spo_number . '!';
        if (!empty($createdScraps)) {
            $successMsg .= ' Sisa potongan kaca (' . implode(', ', $createdScraps) . ') otomatis masuk ke stok Kaca Sisa di ' . $rakLoc . '.';
        }

        return redirect()->back()->with('message', $successMsg);
    }

    /**
     * Use / Accept Scrap Recommendation by Divisi HT (Potong)
     */
    public function useScrapRecommendation(Request $request, $id)
    {
        $order = Order::findOrFail($id);
        $userRole = auth()->user()->role ?? '';

        if ($userRole !== 'divisi_ht' && $userRole !== 'admin_gudang' && $userRole !== 'owner') {
            return redirect()->back()->with('message', '⚠️ Akses Ditolak: Hanya Divisi Potong (HT) atau Admin Gudang yang dapat mengonfirmasi pemakaian kaca sisa!');
        }

        $scrapId = $request->input('scrap_id');
        $scrapCodeInput = $request->input('scrap_code');

        $scrapItem = null;
        if ($scrapId) {
            $scrapItem = ScrapGlass::find($scrapId);
        } elseif ($scrapCodeInput) {
            $scrapItem = ScrapGlass::where('scrap_code', $scrapCodeInput)->first();
        }

        if (!$scrapItem) {
            $scrapStr = $order->used_scrap_rak ?: '';
            preg_match('/(SCRAP-\d+|SCR-\d+-[A-Za-z0-9]+|SC-[A-Za-z0-9-]+)/i', $scrapStr, $matches);
            $scrapCode = $matches[1] ?? ($matches[0] ?? null);

            if ($scrapCode) {
                $scrapItem = ScrapGlass::where('scrap_code', $scrapCode)->first();
            }
        }

        if ($scrapItem) {
            $scrapItem->update([
                'status' => 'Terpakai'
            ]);
            $scrapLabel = $scrapItem->scrap_code . ' (' . $scrapItem->glass_type . ' ' . $scrapItem->length_cm . '×' . $scrapItem->width_cm . ' cm, ' . $scrapItem->rak_location . ')';
        } else {
            $scrapLabel = $order->used_scrap_rak ?: 'Kaca Sisa Rak Storage';
        }

        $usedStr = '✅ [TERPAKAI DIVISI HT] ' . $scrapLabel . ' (Diambil dari stok rak & dipotong untuk SPO-' . $order->spo_number . ')';
        $order->used_scrap_rak = $usedStr;
        $order->save();

        ActivityLog::create([
            'user_id' => auth()->id(),
            'admin_name' => auth()->user()->name ?? 'Pekerja Divisi HT',
            'action_type' => 'PAKAI_SCRAP',
            'target_user_name' => $order->spo_number,
            'description' => 'Divisi HT Menggunakan kaca sisa ' . $scrapLabel . ' untuk pengerjaan SPO #' . $order->spo_number . '. Stok kaca sisa diperbarui menjadi Terpakai.',
            'created_at' => now(),
        ]);

        return redirect()->back()->with('message', '✅ Pemakaian kaca sisa untuk SPO ' . $order->spo_number . ' berhasil dikonfirmasi! Stok sisa telah diperbarui menjadi Terpakai.');
    }

    /**
     * Reject Scrap Recommendation by Divisi HT (Kaca Baret / Ukuran Tidak Cukup / Rusak + Potong Ulang Sisa Utuh)
     */
    public function rejectScrapRecommendation(Request $request, $id)
    {
        $order = Order::findOrFail($id);
        $userRole = auth()->user()->role ?? '';

        if ($userRole !== 'divisi_ht' && $userRole !== 'admin_gudang' && $userRole !== 'owner') {
            return redirect()->back()->with('message', '⚠️ Akses Ditolak: Hanya Divisi Potong (HT) atau Admin Gudang yang dapat menolak rekomendasi kaca sisa!');
        }

        $validated = $request->validate([
            'reason_type' => 'required|string',
            'notes' => 'nullable|string',
            'resize_scrap' => 'nullable|boolean',
            'new_length_cm' => 'nullable|numeric|min:0',
            'new_width_cm' => 'nullable|numeric|min:0',
            'scrap_id' => 'nullable|exists:scrap_glasses,id',
        ]);

        $reasonLabels = [
            'baret_cacat' => 'Kaca Baret / Cacat / Retak Fisik',
            'ukuran_kurang' => 'Ukuran Fisik Kaca Sisa Tidak Cukup',
            'tidak_ditemukan' => 'Kaca Tidak Ditemukan di Rak Storage',
            'alasan_lain' => 'Alasan Lainnya',
        ];

        $label = $reasonLabels[$validated['reason_type']] ?? $validated['reason_type'];
        $notesStr = !empty(trim($validated['notes'] ?? '')) ? ' ("' . trim($validated['notes']) . '")' : '';

        $oldScrapStr = $order->used_scrap_rak ?: '-';
        preg_match('/SCRAP-\d+/', $oldScrapStr, $matches);
        $scrapCode = $matches[0] ?? null;

        $scrapItem = null;
        if (!empty($validated['scrap_id'])) {
            $scrapItem = ScrapGlass::find($validated['scrap_id']);
        } elseif ($scrapCode) {
            $scrapItem = ScrapGlass::where('scrap_code', $scrapCode)->first();
        }

        $resizeStr = '';
        if ($scrapItem && !empty($validated['resize_scrap']) && !empty($validated['new_length_cm']) && !empty($validated['new_width_cm'])) {
            $oldDim = "{$scrapItem->length_cm}x{$scrapItem->width_cm} cm";
            $scrapItem->update([
                'length_cm' => $validated['new_length_cm'],
                'width_cm' => $validated['new_width_cm'],
                'status' => 'Layak Pakai',
            ]);
            $newDim = "{$validated['new_length_cm']}x{$validated['new_width_cm']} cm";
            $resizeStr = " | ✂️ [DIPOTONG ULANG] Dimensi {$scrapItem->scrap_code} disesuaikan dari {$oldDim} menjadi {$newDim}";

            ActivityLog::create([
                'user_id' => auth()->id(),
                'admin_name' => auth()->user()->name ?? 'Pekerja Divisi HT',
                'action_type' => 'POTONG_ULANG_SCRAP',
                'target_user_name' => $scrapItem->scrap_code,
                'description' => 'Memotong ulang sisa utuh kaca ' . $scrapItem->scrap_code . ' dari ' . $oldDim . ' menjadi ' . $newDim . ' (karena baret/cacat pada penolakan SPO #' . $order->spo_number . ').',
                'created_at' => now(),
            ]);
        } elseif ($scrapItem && $validated['reason_type'] === 'baret_cacat' && empty($validated['resize_scrap'])) {
            $scrapItem->update(['status' => 'Afval/Baret']);
        }

        $rejectionStr = '❌ [DITOLAK DIVISI HT] ' . $label . $notesStr . $resizeStr . ' | (Rekomendasi Toko Semula: ' . $oldScrapStr . ')';

        $order->used_scrap_rak = $rejectionStr;
        $order->save();

        ActivityLog::create([
            'user_id' => auth()->id(),
            'admin_name' => auth()->user()->name ?? 'Pekerja Divisi HT',
            'action_type' => 'TOLAK_SCRAP',
            'target_user_name' => $order->spo_number,
            'description' => 'Divisi HT Menolak rekomendasi penggunaan kaca sisa pada SPO #' . $order->spo_number . '. Alasan: ' . $label . $notesStr . '.' . $resizeStr,
            'created_at' => now(),
        ]);

        return redirect()->back()->with('message', '❌ Penolakan penggunaan kaca sisa untuk SPO ' . $order->spo_number . ' berhasil dicatat!');
    }

    /**
     * Submit Glass Defect / Scratch Complaint from Division
     */
    public function submitGlassComplaint(Request $request, $id)
    {
        $order = Order::findOrFail($id);
        $userRole = auth()->user()->role ?? '';

        if ($userRole !== $order->current_division && $userRole !== 'admin_gudang' && $userRole !== 'owner') {
            return redirect()->back()->with('message', '⚠️ Akses Ditolak: Anda hanya memiliki izin untuk mengajukan komplain pada divisi Anda sendiri!');
        }

        $request->validate([
            'reason' => 'required|string',
            'notes' => 'nullable|string',
            'photo' => 'nullable|image|max:5120',
        ]);

        $photoPath = null;
        if ($request->hasFile('photo')) {
            $photoPath = $request->file('photo')->store('complaints', 'public');
        }

        $rawNotes = trim($request->input('notes', ''));
        $rawDefective = $request->input('defective_items');
        $defectiveItems = [];
        if (is_string($rawDefective)) {
            $defectiveItems = json_decode($rawDefective, true) ?? [];
        } elseif (is_array($rawDefective)) {
            $defectiveItems = $rawDefective;
        }

        $complaintData = [
            'reporting_division' => $order->current_division,
            'reason' => $request->input('reason'),
            'notes' => !empty($rawNotes) ? $rawNotes : '-',
            'defective_items' => $defectiveItems,
            'photo_path' => $photoPath,
            'reported_at' => now()->toDateTimeString(),
            'resolved_at' => null,
            'gudang_decision' => null,
        ];

        $order->complaint_status = 'pending_gudang';
        $order->complaint_data = $complaintData;
        $order->save();

        $divLabel = strtoupper(str_replace('divisi_', '', $order->current_division));
        return redirect()->back()->with('message', '⚠️ Komplain Kaca Cacat/Baret dari Divisi ' . $divLabel . ' untuk SPO #' . $order->spo_number . ' Berhasil Dikirim ke Admin Gudang!');
    }

    /**
     * Resolve Glass Defect Complaint by Admin Gudang (Continue vs Replace Glass)
     */
    public function resolveGlassComplaint(Request $request, $id)
    {
        $order = Order::findOrFail($id);
        $userRole = auth()->user()->role ?? '';

        if ($userRole !== 'admin_gudang' && $userRole !== 'owner') {
            return redirect()->back()->with('message', '⚠️ Akses Ditolak: Hanya Admin Gudang atau Owner yang dapat mengonfirmasi keputusan komplain kaca!');
        }

        $action = $request->input('action'); // 'continue' or 'replace_glass'
        $complaintData = (array) ($order->complaint_data ?? []);

        if ($action === 'continue') {
            $complaintData['gudang_decision'] = 'continue';
            $complaintData['resolved_at'] = now()->toDateTimeString();

            $order->complaint_status = 'resolved';
            $order->complaint_data = $complaintData;
            $order->save();

            return redirect()->back()->with('message', '✅ Keputusan Admin Gudang: Pengerjaan SPO #' . $order->spo_number . ' Dilanjutkan di divisi asal.');
        } elseif ($action === 'replace_glass') {
            $reportingDiv = $order->current_division;
            $reportingDivKey = strtoupper(str_replace('divisi_', '', $reportingDiv));

            $complaintData['gudang_decision'] = 'replace_glass';
            $complaintData['resolved_at'] = now()->toDateTimeString();

            // Update history of reporting division to reflect replaced glass
            $progress = (array) ($order->division_progress ?? []);
            if ($reportingDivKey) {
                $progress[$reportingDivKey] = 'Kaca Diganti Gudang & Dikembalikan ke Potong (HT)';
            }
            // Mark HT as requiring re-cutting for replacement
            $progress['HT'] = 'Potong Ulang (Orderan Ulang Ganti Kaca dari ' . $reportingDivKey . ')';

            $order->complaint_status = 're_cut_needed';
            $order->complaint_data = $complaintData;
            $order->current_division = 'divisi_ht';
            $order->division_progress = $progress;
            $order->save();

            return redirect()->back()->with('message', '🚨 Permintaan Ganti Barang Kaca Disetujui! SPO #' . $order->spo_number . ' telah masuk sebagai Order Ulang Ganti Barang dan dikembalikan ke Divisi Potong (HT).');
        }

        return redirect()->back()->with('message', '⚠️ Keputusan tidak valid!');
    }

    /**
     * Calculate Item Glass & Process Option Pricing
     */
    private function calculateItemPricing(array $it, bool $isCompanyUse = false): array
    {
        $lRaw = str_replace(',', '.', (string)($it['length_cm'] ?? 100));
        $wRaw = str_replace(',', '.', (string)($it['width_cm'] ?? 100));
        $l = (float)$lRaw;
        $w = (float)$wRaw;

        $gt = $it['glass_type'] ?? 'Kaca Cermin 5 mm polos';
        
        // Auto extract thickness from glass_type if present (e.g. 5, 8, 12)
        $t = 5;
        if (preg_match('/(\d+)\s*(?:mm|mili)/i', $gt, $matches)) {
            $t = (int)$matches[1];
        } elseif (isset($it['thickness_mm']) && (int)$it['thickness_mm'] > 0) {
            $t = (int)$it['thickness_mm'];
        }

        $q = max(1, (int)($it['qty'] ?? 1));
        $procs = is_array($it['processes'] ?? null) ? $it['processes'] : ['HT'];

        // 1. Luas & Keliling
        $areaM2 = ($l * $w) / 10000;
        $perimeterM = (2 * ($l + $w)) / 100;

        // 2. Harga Dasar Kaca (per m2 proporsional sesuai katalog jenis kaca)
        $pricePerM2 = (float)($it['price_per_m2'] ?? 0);
        if ($pricePerM2 <= 0) {
            $sheet = SheetGlass::where('name', $gt)->first();
            if ($sheet && (float)$sheet->sell_price > 0) {
                $pricePerM2 = (float)$sheet->sell_price;
            } elseif ($t >= 12) {
                $pricePerM2 = 950000;
            } elseif ($t >= 10) {
                $pricePerM2 = 720000;
            } elseif ($t >= 8) {
                $pricePerM2 = 450000;
            } else {
                $pricePerM2 = 380000;
            }
        }
        $rawBasePrice = round($areaM2 * $pricePerM2);
        // Harga dasar kaca murni proporsional luas area m2
        $baseGlassPrice = $isCompanyUse ? 0 : ($rawBasePrice * $q);

        // 3. Biaya GM, HT, BV, Etsa dengan tarif kustom per jenis kaca (dengan fallback default)
        $rateGM = (float)($it['rate_gm'] ?? 10000);
        $rateHT = (float)($it['rate_ht'] ?? 1000);
        $rateBV = (float)($it['rate_bv'] ?? 15000);
        $rateEtsa = (float)($it['rate_etsa'] ?? 50000);

        // 3. Biaya GM (Gosok Mesin)
        // GM hanya dihitung dari sisi yang dipilih (default 2 sisi panjang + 2 sisi lebar)
        $gmSidesL = isset($it['gm_sides_length']) && $it['gm_sides_length'] !== '' ? min(2, max(0, (int)$it['gm_sides_length'])) : 2;
        $gmSidesW = isset($it['gm_sides_width']) && $it['gm_sides_width'] !== '' ? min(2, max(0, (int)$it['gm_sides_width'])) : 2;
        $gmLengthM = (($gmSidesL * $l) + ($gmSidesW * $w)) / 100;
        $feeGM = (!$isCompanyUse && in_array('GM', $procs)) ? round($gmLengthM * $rateGM) * $q : 0;

        // 4. Biaya HT (Gosok HT / Halus Tepi)
        $feeHT = (!$isCompanyUse && in_array('HT', $procs)) ? round($perimeterM * $rateHT) * $q : 0;

        // 5. Biaya BV (Beveling)
        $bevelWidthCm = (float)str_replace(',', '.', (string)($it['bevel_width_cm'] ?? 1));
        $bvSidesL = isset($it['bv_sides_length']) && $it['bv_sides_length'] !== '' ? min(2, max(0, (int)$it['bv_sides_length'])) : 2;
        $bvSidesW = isset($it['bv_sides_width']) && $it['bv_sides_width'] !== '' ? min(2, max(0, (int)$it['bv_sides_width'])) : 2;
        $bvLengthM = (($bvSidesL * $l) + ($bvSidesW * $w)) / 100;
        $feeBV = (!$isCompanyUse && in_array('BV', $procs)) ? round(($bvLengthM * $rateBV) + ($bevelWidthCm * 10000)) * $q : 0;

        // 6. Biaya Bor (Coakan): Keliling ruas lubang cm * Rp 2.500 * jumlah lubang (Mendukung multi-lubang)
        $feeBor = 0;
        $holesSpecs = [];
        if (in_array('Bor', $procs)) {
            if (isset($it['holes']) && is_array($it['holes']) && count($it['holes']) > 0) {
                foreach ($it['holes'] as $h) {
                    $hl = (float)str_replace(',', '.', (string)($h['hole_length_cm'] ?? $h['length_cm'] ?? 2));
                    $hw = (float)str_replace(',', '.', (string)($h['hole_width_cm'] ?? $h['width_cm'] ?? 2));
                    $hq = max(1, (int)($h['hole_qty'] ?? $h['qty'] ?? 1));
                    $ruas = 2 * ($hl + $hw);
                    if (!$isCompanyUse) {
                        $feeBor += round($ruas * 2500) * $hq * $q;
                    }
                    $holesSpecs[] = [
                        'hole_length_cm' => $hl,
                        'hole_width_cm' => $hw,
                        'hole_qty' => $hq,
                    ];
                }
            } else {
                $holeLCm = (float)str_replace(',', '.', (string)($it['hole_length_cm'] ?? 2));
                $holeWCm = (float)str_replace(',', '.', (string)($it['hole_width_cm'] ?? 2));
                $holeQty = max(1, (int)($it['hole_qty'] ?? 1));
                $holeRuasCm = 2 * ($holeLCm + $holeWCm);
                if (!$isCompanyUse) {
                    $feeBor = round($holeRuasCm * 2500) * $holeQty * $q;
                }
                $holesSpecs[] = [
                    'hole_length_cm' => $holeLCm,
                    'hole_width_cm' => $holeWCm,
                    'hole_qty' => $holeQty,
                ];
            }
        }
        $primaryHoleL = $holesSpecs[0]['hole_length_cm'] ?? 2;
        $primaryHoleW = $holesSpecs[0]['hole_width_cm'] ?? 2;
        $primaryHoleQ = $holesSpecs[0]['hole_qty'] ?? 1;

        // 7. Biaya Etsa (Sandblast): Langsung dihitung dari Luas Area Etsa (m2)
        $etsaLCm = (float)str_replace(',', '.', (string)($it['etsa_length_cm'] ?? $l));
        $etsaWCm = (float)str_replace(',', '.', (string)($it['etsa_width_cm'] ?? $w));
        $etsaQty = max(1, (int)($it['etsa_qty'] ?? 1));
        $etsaAreaM2 = ($etsaLCm * $etsaWCm) / 10000;

        $feeEtsa = 0;
        if (!$isCompanyUse && in_array('Etsa', $procs)) {
            $feeEtsa = round($etsaAreaM2 * $etsaQty * $rateEtsa) * $q;
            // Batas minimum biaya etsa (setengah tarif per m2) per unit
            $feeEtsa = max(($rateEtsa / 2) * $q, $feeEtsa);
        }

        // Total Item Subtotal
        $itemSubtotal = $isCompanyUse ? 0 : ($baseGlassPrice + $feeGM + $feeHT + $feeBV + $feeBor + $feeEtsa);

        return [
            'glass_type' => $gt,
            'length_cm' => $l,
            'width_cm' => $w,
            'thickness_mm' => $t,
            'qty' => $q,
            'position_code' => trim((string)($it['position_code'] ?? $it['code'] ?? '')),
            'notes' => trim((string)($it['notes'] ?? '')),
            'processes' => $procs,
            'bevel_width_cm' => $bevelWidthCm,
            'gm_sides_length' => $gmSidesL,
            'gm_sides_width' => $gmSidesW,
            'bv_sides_length' => $bvSidesL,
            'bv_sides_width' => $bvSidesW,
            'holes' => $holesSpecs,
            'hole_length_cm' => $primaryHoleL,
            'hole_width_cm' => $primaryHoleW,
            'hole_qty' => $primaryHoleQ,
            'etsa_length_cm' => $etsaLCm,
            'etsa_width_cm' => $etsaWCm,
            'etsa_qty' => $etsaQty,
            'etsa_area_m2' => $etsaAreaM2,
            'base_glass_price' => $baseGlassPrice,
            'price_per_m2' => $pricePerM2,
            'rate_gm' => $rateGM,
            'rate_ht' => $rateHT,
            'rate_bv' => $rateBV,
            'rate_etsa' => $rateEtsa,
            'fee_gm' => $feeGM,
            'fee_ht' => $feeHT,
            'fee_bv' => $feeBV,
            'fee_bor' => $feeBor,
            'fee_etsa' => $feeEtsa,
            'subtotal' => $itemSubtotal
        ];
    }

    /**
     * Normalize division role/code into standard progress key ('HT', 'GM', 'BV', 'Etsa', 'Bor')
     */
    protected function normalizeDivisionKey(?string $div): string
    {
        $raw = strtoupper(trim(str_replace('divisi_', '', (string) $div)));
        return match ($raw) {
            'ETSA' => 'Etsa',
            'BOR'  => 'Bor',
            default => $raw,
        };
    }

    /**
     * Helper to dynamically generate division_progress array based on required item processes
     */
    protected function buildDivisionProgress($items = [], $processes = [])
    {
        $req = [];
        if (is_array($processes)) {
            foreach ($processes as $p) {
                $req[strtoupper((string)$p)] = true;
            }
        }
        if (is_array($items)) {
            foreach ($items as $it) {
                if (isset($it['processes']) && is_array($it['processes'])) {
                    foreach ($it['processes'] as $p) {
                        $req[strtoupper((string)$p)] = true;
                    }
                }
            }
        }

        $divKeys = ['HT', 'GM', 'BV', 'Etsa', 'Bor'];
        $progress = [];
        foreach ($divKeys as $code) {
            $upperCode = strtoupper($code);
            // HT (Potong) is ALWAYS mandatory for every order (potong kaca lembaran)
            if ($upperCode === 'HT' || isset($req[$upperCode])) {
                $progress[$code] = 'Belum';
            } else {
                $progress[$code] = 'N/A';
            }
        }
        return $progress;
    }

    /**
     * Store New Employee Account (HRD / Owner Only)
     */
    public function storeUser(Request $request)
    {
        $currentUserRole = auth()->user()->role ?? 'staff';

        if ($currentUserRole !== 'owner' && $currentUserRole !== 'hrd') {
            return redirect()->back()->withErrors(['message' => 'Akses ditolak: Pengelolaan akun karyawan hanya dapat dilakukan oleh Staff HRD & Personalia dan Owner.']);
        }

        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users,email',
            'role' => 'required|string|in:admin_toko,admin_gudang,divisi_ht,divisi_gm,divisi_bv,divisi_etsa,divisi_bor,driver,owner,hrd,finance,satpam',
            'password' => 'required|string|min:6',
        ]);

        $managementRoles = ['owner', 'finance', 'hrd'];
        if ($currentUserRole !== 'owner' && in_array($validated['role'], $managementRoles)) {
            return redirect()->back()->withErrors(['role' => 'Akun level manajemen/keuangan (Owner, Admin Finance, HRD) hanya dapat didaftarkan oleh Owner!']);
        }

        $newUser = User::create([
            'name' => $validated['name'],
            'email' => strtolower(trim($validated['email'])),
            'role' => $validated['role'],
            'password' => Hash::make($validated['password']),
        ]);

        // Record Audit Activity Log
        ActivityLog::create([
            'user_id' => auth()->id(),
            'admin_name' => auth()->user()->name ?? 'Admin System',
            'action_type' => 'BUAT_AKUN',
            'target_user_name' => $newUser->name,
            'description' => 'Membuat akun karyawan baru (' . $newUser->name . ' - ' . $newUser->email . ') dengan peran ' . strtoupper($newUser->role),
        ]);

        return redirect()->back()->with('message', 'Akun karyawan baru (' . $validated['name'] . ') berhasil dibuat!');
    }

    /**
     * Update Employee Account Info or Password
     */
    public function updateUser(Request $request, $id)
    {
        $currentUserRole = auth()->user()->role ?? 'staff';

        if ($currentUserRole !== 'owner' && $currentUserRole !== 'hrd') {
            return redirect()->back()->withErrors(['message' => 'Akses ditolak: Pengelolaan akun karyawan hanya dapat dilakukan oleh Staff HRD & Personalia dan Owner.']);
        }

        $user = User::findOrFail($id);

        $managementRoles = ['owner', 'finance', 'hrd'];
        if ($currentUserRole !== 'owner' && (in_array($user->role, $managementRoles) || in_array($request->input('role'), $managementRoles))) {
            return redirect()->back()->withErrors(['message' => 'Akun level manajemen/keuangan (Owner, Admin Finance, HRD) terlindung dan hanya dapat diubah oleh Owner!']);
        }

        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users,email,' . $id,
            'role' => 'required|string|in:admin_toko,admin_gudang,divisi_ht,divisi_gm,divisi_bv,divisi_etsa,divisi_bor,driver,owner,hrd,finance,satpam',
            'password' => 'nullable|string|min:6',
        ]);

        $updateData = [
            'name' => $validated['name'],
            'email' => strtolower(trim($validated['email'])),
            'role' => $validated['role'],
        ];

        $isPasswordChanged = !empty($validated['password']);
        if ($isPasswordChanged) {
            $updateData['password'] = Hash::make($validated['password']);
        }

        $user->update($updateData);

        // Record Audit Activity Log
        $actionType = $isPasswordChanged ? 'RESET_PASSWORD' : 'EDIT_AKUN';
        $logDesc = $isPasswordChanged 
            ? 'Melakukan reset/pembaruan password & data untuk karyawan (' . $user->name . ' - ' . $user->email . ')'
            : 'Memperbarui informasi profil/peran karyawan (' . $user->name . ' - peran: ' . strtoupper($user->role) . ')';

        ActivityLog::create([
            'user_id' => auth()->id(),
            'admin_name' => auth()->user()->name ?? 'Admin System',
            'action_type' => $actionType,
            'target_user_name' => $user->name,
            'description' => $logDesc,
        ]);

        return redirect()->back()->with('message', 'Data karyawan (' . $user->name . ') berhasil diperbarui!');
    }

    /**
     * Delete / Deactivate Employee Account
     */
    public function destroyUser(Request $request, $id)
    {
        $currentUserRole = auth()->user()->role ?? 'staff';

        if ($currentUserRole !== 'owner' && $currentUserRole !== 'hrd') {
            return redirect()->back()->withErrors(['message' => 'Akses ditolak: Pengelolaan akun karyawan hanya dapat dilakukan oleh Staff HRD & Personalia dan Owner.']);
        }

        if (auth()->id() == $id) {
            return redirect()->back()->withErrors(['message' => 'Anda tidak dapat menghapus akun Anda sendiri yang sedang aktif digunakan!']);
        }

        $user = User::findOrFail($id);

        $managementRoles = ['owner', 'finance', 'hrd'];
        if ($currentUserRole !== 'owner' && in_array($user->role, $managementRoles)) {
            return redirect()->back()->withErrors(['message' => 'Akun level manajemen/keuangan (Owner, Admin Finance, HRD) terlindung dan hanya dapat dihapus/dinonaktifkan oleh Owner!']);
        }

        $deletedName = $user->name;
        $deletedEmail = $user->email;
        $deletedRole = $user->role;
        $user->delete();

        // Record Audit Activity Log
        ActivityLog::create([
            'user_id' => auth()->id(),
            'admin_name' => auth()->user()->name ?? 'Admin System',
            'action_type' => 'HAPUS_AKUN',
            'target_user_name' => $deletedName,
            'description' => 'Menghapus/menonaktifkan akun karyawan (' . $deletedName . ' - ' . $deletedEmail . ' - peran: ' . strtoupper($deletedRole) . ')',
        ]);

        return redirect()->back()->with('message', 'Akun karyawan (' . $deletedName . ') berhasil dihapus/dinonaktifkan dari sistem.');
    }

    /**
     * Store New Financial Transaction (Pembelian Bahan, Alat, Aksesoris, Beban Operasional)
     */
    public function storeFinanceTransaction(Request $request)
    {
        $user = auth()->user();
        $isDriver = ($user && $user->role === 'driver') || $request->input('source_role') === 'driver';

        $validated = $request->validate([
            'type' => 'required|string|in:pembelian_bahan,pembelian_aksesoris,pembelian_alat,biaya_operasional,pemasukan_lain,rekap_bulanan',
            'category' => 'required|string|max:255',
            'title' => 'required|string|max:255',
            'amount' => 'required|numeric|min:0',
            'supplier_name' => 'nullable|string|max:255',
            'invoice_number' => 'nullable|string|max:255',
            'payment_method' => 'nullable|string|max:255',
            'payment_status' => 'nullable|string|in:Lunas,Tempo,DP',
            'transaction_date' => 'required|date',
            'due_date' => 'nullable|date',
            'notes' => 'nullable|string',
            'vehicle_plate' => 'nullable|string|max:255',
            'source_role' => 'nullable|string|max:50',
            'approval_status' => 'nullable|string|in:approved,pending,rejected',
            'receipt_photo' => 'nullable|image|max:10240',
            'receipt_photos' => 'nullable|array',
            'receipt_photos.*' => 'nullable|image|max:10240',
        ]);

        $storedPhotoPaths = [];
        if ($request->hasFile('receipt_photos')) {
            foreach ($request->file('receipt_photos') as $file) {
                if ($file->isValid()) {
                    $storedPhotoPaths[] = $file->store('receipts', 'public');
                }
            }
        } elseif ($request->hasFile('receipt_photo')) {
            $storedPhotoPaths[] = $request->file('receipt_photo')->store('receipts', 'public');
        }

        $receiptPhotoPath = null;
        if (count($storedPhotoPaths) === 1) {
            $receiptPhotoPath = $storedPhotoPaths[0];
        } elseif (count($storedPhotoPaths) > 1) {
            $receiptPhotoPath = json_encode($storedPhotoPaths);
        }

        $prefixMap = [
            'pembelian_bahan' => 'PO-BB',
            'pembelian_aksesoris' => 'PO-ACC',
            'pembelian_alat' => 'PO-ALT',
            'biaya_operasional' => $isDriver ? 'KLM-DRV' : 'EXP',
            'pemasukan_lain' => 'REV-ADD',
            'rekap_bulanan' => 'REKAP-BLN',
        ];

        $prefix = $prefixMap[$validated['type']] ?? 'TRX';
        $period = date('Ym', strtotime($validated['transaction_date']));
        $count = FinanceTransaction::where('transaction_code', 'like', $prefix . '-' . $period . '-%')->count() + 1;
        $trxCode = sprintf('%s-%s-%03d', $prefix, $period, $count);

        $approvalStatus = $isDriver ? 'pending' : ($validated['approval_status'] ?? 'approved');
        $sourceRole = $validated['source_role'] ?? ($user ? $user->role : 'admin_toko');

        $trx = FinanceTransaction::updateOrCreate(
            $validated['type'] === 'rekap_bulanan'
                ? ['type' => 'rekap_bulanan', 'category' => $validated['category']]
                : ['transaction_code' => $trxCode],
            [
                'transaction_code' => $trxCode,
                'type' => $validated['type'],
                'category' => $validated['category'],
                'title' => $validated['title'],
                'amount' => $validated['amount'],
                'supplier_name' => $validated['supplier_name'] ?? null,
                'invoice_number' => $validated['invoice_number'] ?? null,
                'payment_method' => $validated['payment_method'] ?? 'Kas Tunai',
                'payment_status' => $validated['payment_status'] ?? 'Lunas',
                'approval_status' => $approvalStatus,
                'source_role' => $sourceRole,
                'vehicle_plate' => $validated['vehicle_plate'] ?? null,
                'transaction_date' => $validated['transaction_date'],
                'due_date' => $validated['due_date'] ?? null,
                'notes' => $validated['notes'] ?? null,
                'receipt_photo_path' => $receiptPhotoPath,
                'user_id' => auth()->id(),
                'approved_by_user_id' => $approvalStatus === 'approved' ? auth()->id() : null,
                'approved_at' => $approvalStatus === 'approved' ? now() : null,
            ]
        );

        if ($approvalStatus === 'approved') {
            if (preg_match('/\[RESTOCK_GLASS_ID:(\d+)\|QTY:(\d+)/', (string) $trx->notes, $matches)) {
                $glass = SheetGlass::find((int) $matches[1]);
                $restockQty = (int) $matches[2];
                if ($glass && $restockQty > 0) {
                    $newQty = (int) $glass->qty + $restockQty;
                    $glass->update([
                        'qty' => $newQty,
                        'last_restock' => now(),
                        'status' => $newQty > 10 ? 'Aman' : ($newQty > 0 ? 'Menipis' : 'Habis'),
                    ]);
                }
            } elseif (preg_match('/\[RESTOCK_SUPPLY_ID:(\d+)\|QTY:(\d+)(?:\|REQ_ID:(\d+))?/', (string) $trx->notes, $matches)) {
                $supply = Supply::find((int) $matches[1]);
                $restockQty = (int) $matches[2];
                $reqId = isset($matches[3]) ? (int) $matches[3] : null;
                if ($supply && $restockQty > 0) {
                    $newQty = (int) $supply->qty + $restockQty;
                    $supply->update([
                        'qty' => $newQty,
                        'status' => $newQty > ($supply->min_stock ?? 5) ? 'Aman' : ($newQty > 0 ? 'Menipis' : 'Habis'),
                    ]);
                    if ($reqId) {
                        \App\Models\SupplyRestock::where('id', $reqId)->update(['status' => 'Selesai Restok']);
                    }
                }
            } elseif (preg_match('/\[RESTOCK_ACC_ID:(\d+)\|QTY:(\d+)/', (string) $trx->notes, $matches)) {
                $acc = Accessory::find((int) $matches[1]);
                $restockQty = (int) $matches[2];
                if ($acc && $restockQty > 0) {
                    $newQty = (int) $acc->qty + $restockQty;
                    $acc->update([
                        'qty' => $newQty,
                        'status' => $newQty > 20 ? 'Aman' : ($newQty > 0 ? 'Menipis' : 'Habis'),
                    ]);
                }
            } elseif (preg_match('/\[RESTOCK_TOOL_ID:(\d+)\|QTY:(\d+)/', (string) $trx->notes, $matches)) {
                $tool = Tool::find((int) $matches[1]);
                $restockQty = (int) $matches[2];
                if ($tool && $restockQty > 0) {
                    $newTotal = (int) $tool->total_qty + $restockQty;
                    $newAvail = (int) $tool->available_qty + $restockQty;
                    $tool->update([
                        'total_qty' => $newTotal,
                        'available_qty' => $newAvail,
                        'condition' => 'Baik',
                        'notes' => 'Disetujui & dibeli oleh Finance (' . $trx->transaction_code . ')',
                    ]);
                }
            }
        }

        $logDesc = $isDriver
            ? 'Supir (' . ($user->name ?? 'Driver') . ') mengajukan klaim biaya armada ' . $trx->title . ' sebesar Rp ' . number_format($trx->amount, 0, ',', '.') . ' (Status: Menunggu Persetujuan)'
            : 'Mencatat transaksi ' . strtoupper(str_replace('_', ' ', $trx->type)) . ' (' . $trx->title . ') sebesar Rp ' . number_format($trx->amount, 0, ',', '.') . ' (' . $trx->payment_method . ')';

        ActivityLog::create([
            'user_id' => auth()->id(),
            'admin_name' => auth()->user()->name ?? 'Staff Operasional',
            'action_type' => $isDriver ? 'KLAIM_ARMADA_DRIVER' : 'TRANSAKSI_FINANCE',
            'target_user_name' => $trx->transaction_code,
            'description' => $logDesc,
            'created_at' => now(),
        ]);

        $msg = $isDriver
            ? '✅ Klaim biaya armada #' . $trx->transaction_code . ' berhasil diajukan! Menunggu persetujuan Tim Akuntan / Owner.'
            : '✅ Transaksi keuangan #' . $trx->transaction_code . ' (' . $trx->title . ') berhasil dicatat!';

        return redirect()->back()->with('message', $msg);
    }

    /**
     * Approve Finance Transaction (Owner & Tim Finance)
     */
    public function approveFinanceTransaction(Request $request, $id)
    {
        $user = auth()->user();
        if (!$user || !in_array($user->role, ['owner', 'finance', 'admin_finance'])) {
            return redirect()->back()->with('error', 'Hanya Owner atau Tim Finance yang memiliki wewenang untuk menyetujui transaksi pengeluaran kas.');
        }

        $trx = FinanceTransaction::findOrFail($id);

        $isRestockRequest = $trx->type === 'pembelian_aksesoris'
            || $trx->type === 'pembelian_bahan'
            || $trx->type === 'pembelian_alat'
            || str_contains((string) $trx->notes, '[RESTOCK_')
            || str_contains(strtolower((string) $trx->title), 'restok')
            || str_contains(strtolower((string) $trx->title), 'pengajuan');

        $validated = $request->validate([
            'receipt_photo' => 'required|image|max:10240',
            'restock_qty' => 'nullable|integer|min:1',
            'amount' => 'nullable|numeric|min:0',
            'invoice_number' => 'nullable|string|max:255',
            'supplier_name' => 'nullable|string|max:255',
            'payment_method' => 'nullable|string|max:255',
            'notes' => 'nullable|string|max:1000',
        ], [
            'receipt_photo.required' => 'Wajib mengunggah foto Bukti Transfer / Nota Pembayaran dari bagian Finance sebelum menyetujui pengajuan atau klaim ini!',
            'receipt_photo.image' => 'File bukti transfer / nota pembayaran harus berupa gambar (JPG, PNG, JPEG, WEBP).',
            'receipt_photo.max' => 'Ukuran foto bukti transfer / nota pembayaran maksimal 10 MB.',
        ]);

        $receiptPhotoPath = $trx->receipt_photo_path;
        if ($request->hasFile('receipt_photo')) {
            $newPhotoPath = $request->file('receipt_photo')->store('receipts', 'public');
            if (!empty($trx->receipt_photo_path)) {
                $existingPhotos = [];
                if (is_string($trx->receipt_photo_path) && str_starts_with(trim($trx->receipt_photo_path), '[')) {
                    $decoded = json_decode($trx->receipt_photo_path, true);
                    $existingPhotos = is_array($decoded) ? $decoded : [$trx->receipt_photo_path];
                } else {
                    $existingPhotos = [$trx->receipt_photo_path];
                }
                $existingPhotos[] = $newPhotoPath;
                $receiptPhotoPath = json_encode($existingPhotos);
            } else {
                $receiptPhotoPath = $newPhotoPath;
            }
        }

        $finalAmount = isset($validated['amount']) && $validated['amount'] !== null && $validated['amount'] !== ''
            ? (float) $validated['amount']
            : (float) $trx->amount;

        $overrideRestockQty = isset($validated['restock_qty']) && (int) $validated['restock_qty'] > 0
            ? (int) $validated['restock_qty']
            : null;

        $updatedNotes = $trx->notes;
        if ($overrideRestockQty) {
            $updatedNotes = preg_replace('/\|QTY:\d+/', '|QTY:' . $overrideRestockQty, (string) $updatedNotes);
        }
        if (!empty($validated['notes'])) {
            $updatedNotes = trim(($updatedNotes ? $updatedNotes . ' | ' : '') . 'Catatan Finance: ' . $validated['notes']);
        }

        $finalTitle = $trx->title;
        if ($overrideRestockQty) {
            $finalTitle = preg_replace('/\(\+\d+\s/', '(+' . $overrideRestockQty . ' ', (string) $finalTitle);
        }

        $trx->update([
            'title' => $finalTitle,
            'approval_status' => 'approved',
            'payment_status' => 'Lunas',
            'amount' => $finalAmount,
            'invoice_number' => !empty($validated['invoice_number']) ? $validated['invoice_number'] : $trx->invoice_number,
            'supplier_name' => !empty($validated['supplier_name']) ? $validated['supplier_name'] : $trx->supplier_name,
            'payment_method' => !empty($validated['payment_method']) ? $validated['payment_method'] : ($trx->payment_method === 'Menunggu Realisasi Finance' ? 'Transfer Bank / Kas' : $trx->payment_method),
            'receipt_photo_path' => $receiptPhotoPath,
            'notes' => $updatedNotes,
            'approved_by_user_id' => auth()->id(),
            'approved_at' => now(),
        ]);

        // Otomatis tambahkan stok barang sesuai jenis pengajuan restok (Kaca Lembaran / Aksesoris / Sparepart & Perlengkapan)
        $restockedAccInfo = '';
        if (preg_match('/\[RESTOCK_GLASS_ID:(\d+)\|QTY:(\d+)/', (string) $trx->notes, $matches)) {
            $glassId = (int) $matches[1];
            $restockQty = (int) $matches[2];
            $glass = SheetGlass::find($glassId);
            if ($glass && $restockQty > 0) {
                $newQty = (int) $glass->qty + $restockQty;
                $newStatus = $newQty > 10 ? 'Aman' : ($newQty > 0 ? 'Menipis' : 'Habis');
                $glass->update([
                    'qty' => $newQty,
                    'last_restock' => now(),
                    'status' => $newStatus,
                ]);
                $restockedAccInfo = " Stok bahan produksi {$glass->name} otomatis bertambah +{$restockQty} " . ($glass->unit ?? 'Lembar') . " (Total Stok: {$newQty} " . ($glass->unit ?? 'Lembar') . ").";
            }
        } elseif (preg_match('/\[RESTOCK_SUPPLY_ID:(\d+)\|QTY:(\d+)(?:\|REQ_ID:(\d+))?/', (string) $trx->notes, $matches)) {
            $supplyId = (int) $matches[1];
            $restockQty = (int) $matches[2];
            $reqId = isset($matches[3]) ? (int) $matches[3] : null;
            $supply = Supply::find($supplyId);
            if ($supply && $restockQty > 0) {
                $newQty = (int) $supply->qty + $restockQty;
                $newStatus = $newQty > ($supply->min_stock ?? 5) ? 'Aman' : ($newQty > 0 ? 'Menipis' : 'Habis');
                $supply->update([
                    'qty' => $newQty,
                    'status' => $newStatus,
                ]);
                if ($reqId) {
                    \App\Models\SupplyRestock::where('id', $reqId)->update(['status' => 'Selesai Restok']);
                }
                $restockedAccInfo = " Stok sparepart/perlengkapan {$supply->name} otomatis bertambah +{$restockQty} " . ($supply->unit ?? 'Pcs') . " (Total Stok: {$newQty} " . ($supply->unit ?? 'Pcs') . ").";
            }
        } elseif (preg_match('/\[RESTOCK_ACC_ID:(\d+)\|QTY:(\d+)/', (string) $trx->notes, $matches)) {
            $accId = (int) $matches[1];
            $restockQty = (int) $matches[2];
            $acc = Accessory::find($accId);
            if ($acc && $restockQty > 0) {
                $newQty = (int) $acc->qty + $restockQty;
                $newStatus = $newQty > 20 ? 'Aman' : ($newQty > 0 ? 'Menipis' : 'Habis');
                $acc->update([
                    'qty' => $newQty,
                    'status' => $newStatus,
                ]);
                $restockedAccInfo = " Stok aksesoris {$acc->name} otomatis bertambah +{$restockQty} " . ($acc->unit ?? 'Pcs') . " (Total Stok: {$newQty} " . ($acc->unit ?? 'Pcs') . ").";
            }
        } elseif (preg_match('/\[RESTOCK_TOOL_ID:(\d+)\|QTY:(\d+)/', (string) $trx->notes, $matches)) {
            $toolId = (int) $matches[1];
            $restockQty = (int) $matches[2];
            $tool = Tool::find($toolId);
            if ($tool && $restockQty > 0) {
                $newTotal = (int) $tool->total_qty + $restockQty;
                $newAvail = (int) $tool->available_qty + $restockQty;
                $tool->update([
                    'total_qty' => $newTotal,
                    'available_qty' => $newAvail,
                    'condition' => 'Baik',
                    'notes' => 'Disetujui & dibeli oleh Finance (' . $trx->transaction_code . ')',
                ]);
                $restockedAccInfo = " Stok alat penunjang {$tool->name} otomatis bertambah +{$restockQty} Unit (Total Siap Pakai: {$newAvail} Unit).";
            }
        } elseif ($trx->type === 'pembelian_aksesoris') {
            if (preg_match('/\(\+(\d+)\s/i', (string) $trx->title, $qtyMatch)) {
                $restockQty = (int) $qtyMatch[1];
                $acc = Accessory::where('status', 'Pengajuan Restock')->get()->first(function ($item) use ($trx) {
                    return str_contains(strtolower((string) $trx->title), strtolower((string) $item->name));
                });
                if ($acc && $restockQty > 0) {
                    $newQty = (int) $acc->qty + $restockQty;
                    $newStatus = $newQty > 20 ? 'Aman' : ($newQty > 0 ? 'Menipis' : 'Habis');
                    $acc->update([
                        'qty' => $newQty,
                        'status' => $newStatus,
                    ]);
                    $restockedAccInfo = " Stok aksesoris {$acc->name} otomatis bertambah +{$restockQty} " . ($acc->unit ?? 'Pcs') . " (Total Stok: {$newQty} " . ($acc->unit ?? 'Pcs') . ").";
                }
            }
        }

        ActivityLog::create([
            'user_id' => auth()->id(),
            'admin_name' => auth()->user()->name ?? ($user->role === 'owner' ? 'Owner / Direksi' : 'Finance & Accounting'),
            'action_type' => 'APPROVE_KLAIM_FINANCE',
            'target_user_name' => $trx->transaction_code,
            'description' => 'Menyetujui & mengunggah nota pembayaran ' . $trx->transaction_code . ' (' . $trx->title . ') sebesar Rp ' . number_format($trx->amount, 0, ',', '.') . '.' . $restockedAccInfo,
            'created_at' => now(),
        ]);

        return redirect()->back()->with('message', 'Pengajuan #' . $trx->transaction_code . ' berhasil DISETUJUI beserta Nota Bukti Pembayaran dan dibukukan ke Laporan Keuangan!' . $restockedAccInfo);
    }

    /**
     * Reject Finance Transaction (Owner & Tim Finance)
     */
    public function rejectFinanceTransaction(Request $request, $id)
    {
        $user = auth()->user();
        if (!$user || !in_array($user->role, ['owner', 'finance', 'admin_finance'])) {
            return redirect()->back()->with('error', 'Hanya Owner atau Tim Finance yang memiliki wewenang untuk menolak transaksi pengeluaran kas.');
        }

        $trx = FinanceTransaction::findOrFail($id);
        $reason = $request->input('rejection_reason', 'Klaim ditolak oleh verifikator');
        
        $trx->update([
            'approval_status' => 'rejected',
            'rejection_reason' => $reason,
        ]);

        if (preg_match('/\[RESTOCK_GLASS_ID:(\d+)\|QTY:(\d+)/', (string) $trx->notes, $matches)) {
            $glass = SheetGlass::find((int) $matches[1]);
            if ($glass && $glass->status === 'Pengajuan Proses Restock') {
                $revertedStatus = $glass->qty > 10 ? 'Aman' : ($glass->qty > 0 ? 'Menipis' : 'Habis');
                $glass->update(['status' => $revertedStatus]);
            }
        } elseif (preg_match('/\[RESTOCK_SUPPLY_ID:(\d+)\|QTY:(\d+)(?:\|REQ_ID:(\d+))?/', (string) $trx->notes, $matches)) {
            if (!empty($matches[3])) {
                \App\Models\SupplyRestock::where('id', (int) $matches[3])->update(['status' => 'Ditolak Finance']);
            }
        } elseif (preg_match('/\[RESTOCK_ACC_ID:(\d+)\|QTY:(\d+)/', (string) $trx->notes, $matches)) {
            $acc = Accessory::find((int) $matches[1]);
            if ($acc && $acc->status === 'Pengajuan Restock') {
                $revertedStatus = $acc->qty > 20 ? 'Aman' : ($acc->qty > 0 ? 'Menipis' : 'Habis');
                $acc->update(['status' => $revertedStatus]);
            }
        } elseif (preg_match('/\[RESTOCK_TOOL_ID:(\d+)\|QTY:(\d+)/', (string) $trx->notes, $matches)) {
            $tool = Tool::find((int) $matches[1]);
            if ($tool && $tool->condition === 'Pengajuan Pembelian' && (int) $tool->total_qty === 0) {
                $tool->delete();
            }
        }

        ActivityLog::create([
            'user_id' => auth()->id(),
            'admin_name' => auth()->user()->name ?? ($user->role === 'owner' ? 'Owner / Direksi' : 'Finance & Accounting'),
            'action_type' => 'TOLAK_KLAIM_FINANCE',
            'target_user_name' => $trx->transaction_code,
            'description' => 'Menolak klaim ' . $trx->transaction_code . ' (' . $trx->title . '). Alasan: ' . $reason,
            'created_at' => now(),
        ]);

        return redirect()->back()->with('message', 'Pengajuan #' . $trx->transaction_code . ' telah DITOLAK.');
    }

    /**
     * Settle Order Full Payment (Pelunasan Order oleh Admin Toko dengan Bukti Pembayaran)
     */
    public function settleCodHandover(Request $request, $id)
    {
        $order = Order::findOrFail($id);

        $validated = $request->validate([
            'payment_proof' => $order->payment_proof_path ? 'nullable|image|max:10240' : 'required|image|max:10240',
            'payment_method' => 'nullable|string|max:100',
            'notes' => 'nullable|string|max:500',
        ], [
            'payment_proof.required' => 'Wajib mengunggah foto bukti pembayaran / struk transfer pelunasan customer terlebih dahulu!',
            'payment_proof.image' => 'File bukti pembayaran harus berupa gambar (JPG, PNG, JPEG, WEBP).',
            'payment_proof.max' => 'Ukuran foto bukti pembayaran maksimal 10 MB.',
        ]);

        $sisaCod = max(0, (float)($order->total_price - $order->paid_amount));

        if ($request->hasFile('payment_proof')) {
            $path = $request->file('payment_proof')->store('payment_proofs', 'public');
            $order->payment_proof_path = $path;
        }

        if (!empty($validated['payment_method'])) {
            $order->payment_method = $validated['payment_method'];
        }

        $order->payment_status = 'Lunas';
        $order->paid_amount = $order->total_price;

        $hasCompletedDelivery = !empty($order->delivered_at) ||
            Delivery::where('order_id', $order->id)->where('delivery_status', 'Selesai Terkirim')->exists();

        if ($hasCompletedDelivery) {
            $order->status = 'selesai';
            $order->current_division = 'selesai';
        }

        $order->save();

        $methodLabel = !empty($validated['payment_method']) ? ' (' . $validated['payment_method'] . ')' : '';

        ActivityLog::create([
            'user_id' => auth()->id(),
            'admin_name' => auth()->user()->name ?? 'Admin Toko & Kasir',
            'action_type' => 'PELUNASAN_ORDER_LUNAS',
            'target_user_name' => $order->spo_number,
            'description' => 'Konfirmasi pelunasan pembayaran Order #' . $order->spo_number . ' sebesar Rp ' . number_format($sisaCod, 0, ',', '.') . ' (' . $order->customer_name . ')' . $methodLabel . ' beserta lampiran bukti pembayaran oleh Admin Toko.',
            'created_at' => now(),
        ]);

        return redirect()->back()->with('message', 'Status pembayaran Order #' . $order->spo_number . ' (Rp ' . number_format($sisaCod, 0, ',', '.') . ') beserta bukti pembayaran berhasil diubah menjadi LUNAS!');
    }

    /**
     * Delete Financial Transaction
     */
    public function destroyFinanceTransaction(Request $request, $id)
    {
        $trx = FinanceTransaction::findOrFail($id);
        $code = $trx->transaction_code;
        $title = $trx->title;
        $amount = $trx->amount;
        $trx->delete();

        ActivityLog::create([
            'user_id' => auth()->id(),
            'admin_name' => auth()->user()->name ?? (auth()->user()?->role === 'owner' ? 'Owner / Direksi' : 'Finance & Akuntansi'),
            'action_type' => 'HAPUS_TRANSAKSI_FINANCE',
            'target_user_name' => $code,
            'description' => 'Menghapus transaksi keuangan ' . $code . ' (' . $title . ') sebesar Rp ' . number_format($amount, 0, ',', '.'),
            'created_at' => now(),
        ]);

        return redirect()->back()->with('message', 'Transaksi keuangan #' . $code . ' berhasil dihapus.');
    }

    /**
     * Helper validation to prevent order glass cut sizes from exceeding stock sheet glass dimensions
     */
    private function validateItemGlassDimensions(array $items)
    {
        foreach ($items as $it) {
            $l = (float)($it['length_cm'] ?? 0);
            $w = (float)($it['width_cm'] ?? 0);
            $glassType = trim($it['glass_type'] ?? '');

            if ($l <= 0 || $w <= 0) continue;

            $matchedSheet = null;
            if (!empty($glassType)) {
                $matchedSheet = SheetGlass::where('name', $glassType)
                    ->orWhere('name', 'like', '%' . $glassType . '%')
                    ->first();
            }

            if ($matchedSheet && (float)$matchedSheet->length_cm > 0 && (float)$matchedSheet->width_cm > 0) {
                $sheetLen = (float)$matchedSheet->length_cm;
                $sheetWid = (float)$matchedSheet->width_cm;
            } else {
                $maxLen = (float)SheetGlass::max('length_cm');
                $maxWid = (float)SheetGlass::max('width_cm');
                $sheetLen = $maxLen > 0 ? $maxLen : 366.0;
                $sheetWid = $maxWid > 0 ? $maxWid : 244.0;
            }

            $maxDim = max($sheetLen, $sheetWid);
            $minDim = min($sheetLen, $sheetWid);

            $itemMax = max($l, $w);
            $itemMin = min($l, $w);

            if ($itemMax > $maxDim || $itemMin > $minDim) {
                return "Ukuran potongan kaca {$l} x {$w} cm pada item '{$glassType}' melebihi batas lembaran kaca yang tersedia di gudang (Maksimal Lembaran: {$maxDim} x {$minDim} cm)!";
            }
        }
        return null;
    }
}

