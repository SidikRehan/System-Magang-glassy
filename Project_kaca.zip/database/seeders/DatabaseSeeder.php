<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database with Multi-Staff & Role Accounts.
     */
    public function run(): void
    {
        $password = Hash::make('password');

        $users = [
            // Admin Toko Accounts (Multi-Staff Kasir & Sales Toko)
            [
                'name' => 'Admin Toko Utama',
                'email' => 'toko@sypglass.co.id',
                'role' => 'admin_toko',
                'password' => $password,
            ],
            [
                'name' => 'Kasir Toko 1 - Ani',
                'email' => 'toko1@sypglass.co.id',
                'role' => 'admin_toko',
                'password' => $password,
            ],
            [
                'name' => 'Kasir Toko 2 - Doni',
                'email' => 'toko2@sypglass.co.id',
                'role' => 'admin_toko',
                'password' => $password,
            ],

            // Gudang & Divisi Operasional Accounts
            [
                'name' => 'Admin Gudang Manufaktur',
                'email' => 'gudang@sypglass.co.id',
                'role' => 'admin_gudang',
                'password' => $password,
            ],
            [
                'name' => 'Staff Divisi HT (Potong/Bor)',
                'email' => 'ht@sypglass.co.id',
                'role' => 'divisi_ht',
                'password' => $password,
            ],
            [
                'name' => 'Staff Divisi GM (Gosok Halus)',
                'email' => 'gm@sypglass.co.id',
                'role' => 'divisi_gm',
                'password' => $password,
            ],
            [
                'name' => 'Staff Divisi BV (Bevel)',
                'email' => 'bv@sypglass.co.id',
                'role' => 'divisi_bv',
                'password' => $password,
            ],
            [
                'name' => 'Staff Divisi Etsa (Blur)',
                'email' => 'etsa@sypglass.co.id',
                'role' => 'divisi_etsa',
                'password' => $password,
            ],
            [
                'name' => 'Staff Divisi Bor (Coak/Lubang)',
                'email' => 'bor@sypglass.co.id',
                'role' => 'divisi_bor',
                'password' => $password,
            ],
            [
                'name' => 'Pak Dadang (Satpam / Gate Checker)',
                'email' => 'satpam@sypglass.co.id',
                'role' => 'satpam',
                'password' => $password,
            ],
            [
                'name' => 'Pak Budi (Supir Utama DC)',
                'email' => 'driver@sypglass.co.id',
                'role' => 'driver',
                'password' => $password,
            ],
            [
                'name' => 'Pak Mulyadi (Driver Engkel)',
                'email' => 'mulyadi.driver@sypglass.co.id',
                'role' => 'driver',
                'password' => $password,
            ],
            [
                'name' => 'Pak Asep (Driver L300)',
                'email' => 'asep.driver@sypglass.co.id',
                'role' => 'driver',
                'password' => $password,
            ],
            [
                'name' => 'Pak Hendra (Driver Subcon)',
                'email' => 'hendra.driver@sypglass.co.id',
                'role' => 'driver',
                'password' => $password,
            ],
            [
                'name' => 'Bapak Ir. Hendra (Owner & Direktur Utama)',
                'email' => 'owner@sypglass.co.id',
                'role' => 'owner',
                'password' => $password,
            ],
            [
                'name' => 'Sarah HRD & Personalia',
                'email' => 'hrd@sypglass.co.id',
                'role' => 'hrd',
                'password' => $password,
            ],
            [
                'name' => 'Rini Safitri (Finance & Accounting)',
                'email' => 'finance@sypglass.co.id',
                'role' => 'finance',
                'password' => $password,
            ],
        ];

        foreach ($users as $u) {
            User::updateOrCreate(
                ['email' => $u['email']],
                $u
            );
        }

        $this->call([
            GlassSystemSeeder::class,
            FinanceTransactionSeeder::class,
        ]);
    }
}
