import React, { useState } from 'react';
import { TrendingUp, BarChart3, Activity, ArrowUpRight } from 'lucide-react';

export default function CandlestickChart({ canViewPricing = true }) {
    // Mode tampilan grafik: 'line', 'area', 'bar'
    const [chartMode, setChartMode] = useState('line');
    // Timeframe: 'monthly', 'weekly'
    const [timeframe, setTimeframe] = useState('monthly');
    const [hoveredCandle, setHoveredCandle] = useState(null);

    // Data Penjualan Bulanan (Omset dalam Juta Rupiah & SPO Volume)
    const monthlyData = [
        { period: 'Jan', open: 43.0, high: 51.2, low: 40.0, close: 48.5, volume: 22, growth: '+12.8%', note: 'Awal tahun proyek ruko & residential' },
        { period: 'Feb', open: 48.5, high: 62.0, low: 46.5, close: 59.2, volume: 28, growth: '+22.1%', note: 'Permintaan cermin & tempered naik' },
        { period: 'Mar', open: 59.2, high: 71.5, low: 56.0, close: 67.8, volume: 32, growth: '+14.5%', note: 'Proyek partisi kantor & etsa masjid' },
        { period: 'Apr', open: 67.8, high: 69.5, low: 58.0, close: 61.5, volume: 26, growth: '-9.3%', isBearish: true, note: 'Periode libur panjang & koreksi bahan' },
        { period: 'Mei', open: 61.5, high: 87.0, low: 60.5, close: 84.3, volume: 39, growth: '+37.1%', note: 'Rebound tajam kanopi tempered & bevel' },
        { period: 'Jun', open: 84.3, high: 99.8, low: 82.0, close: 96.7, volume: 44, growth: '+14.7%', note: 'Proyek interior apartemen & hotel' },
        { period: 'Jul', open: 96.7, high: 115.5, low: 93.0, close: 112.4, volume: 51, growth: '+16.2%', note: 'Permintaan kaca shower & laminated naik' },
        { period: 'Agu', open: 112.4, high: 134.0, low: 108.5, close: 128.5, volume: 58, growth: '+14.3%', isPeak: true, note: 'Puncak rekor penjualan 2026 (All-Time High)' },
    ];

    // Data Mingguan (Agustus - September 2026)
    const weeklyData = [
        { period: 'M1 Agu', open: 108.0, high: 116.5, low: 106.0, close: 114.2, volume: 12, growth: '+5.7%' },
        { period: 'M2 Agu', open: 114.2, high: 122.0, low: 112.0, close: 120.5, volume: 14, growth: '+5.5%' },
        { period: 'M3 Agu', open: 120.5, high: 129.0, low: 118.5, close: 125.8, volume: 15, growth: '+4.4%' },
        { period: 'M4 Agu', open: 125.8, high: 134.0, low: 123.0, close: 128.5, volume: 17, growth: '+2.1%', isPeak: true },
        { period: 'M1 Sep', open: 128.5, high: 136.5, low: 126.0, close: 133.2, volume: 16, growth: '+3.7%' },
        { period: 'M2 Sep', open: 133.2, high: 139.0, low: 130.5, close: 137.8, volume: 18, growth: '+3.5%' },
    ];

    const currentDataset = timeframe === 'monthly' ? monthlyData : weeklyData;

    // Hitung Min dan Max untuk Skala Sumbu Y
    const minVal = Math.min(...currentDataset.map(d => d.low)) * 0.85;
    const maxVal = Math.max(...currentDataset.map(d => d.high)) * 1.08;
    const maxVolume = Math.max(...currentDataset.map(d => d.volume)) * 1.2;

    // Dimensi SVG
    const svgWidth = 720;
    const svgHeight = 270;
    const chartBottom = 200; // batas bawah chart garis
    const volumeHeight = 55; // tinggi sub-chart volume
    const paddingLeft = 55;
    const paddingRight = 25;
    const usableWidth = svgWidth - paddingLeft - paddingRight;

    const getY = (val) => chartBottom - ((val - minVal) / (maxVal - minVal)) * (chartBottom - 25);
    const getVolHeight = (vol) => (vol / maxVolume) * volumeHeight;

    const stepX = usableWidth / currentDataset.length;

    // Line Points string untuk Grafik Tren Line
    const linePoints = currentDataset.map((d, idx) => {
        const x = paddingLeft + (idx + 0.5) * stepX;
        const y = getY(d.close);
        return `${x},${y}`;
    }).join(' ');

    const areaPathD = `M ${paddingLeft + 0.5 * stepX},${chartBottom} ` +
        currentDataset.map((d, i) => `L ${paddingLeft + (i + 0.5) * stepX},${getY(d.close)}`).join(' ') +
        ` L ${paddingLeft + (currentDataset.length - 0.5) * stepX},${chartBottom} Z`;

    const activeItem = hoveredCandle || currentDataset[currentDataset.length - 1];

    return (
        <div className="bg-white border border-slate-200 rounded-2xl p-5 sm:p-6 space-y-4 shadow-xs relative overflow-hidden">
            {/* HEADER CHART CONTROLS */}
            <div className="flex flex-wrap justify-between items-start gap-4 border-b border-slate-100 pb-4 relative z-10">
                <div>
                    <div className="flex items-center gap-2.5">
                        <TrendingUp className="w-5 h-5 text-[#1b68b0]" />
                        <h3 className="font-black text-[#242222] text-lg tracking-tight">
                            {canViewPricing ? 'Grafik Tren Penjualan & Omset' : 'Grafik Tren Produksi & Volume SPO'}
                        </h3>
                        <span className="bg-emerald-50 text-emerald-700 text-[10px] font-black px-2.5 py-0.5 rounded-full border border-emerald-200 font-mono">
                            Tren Bullish (+38.5% YoY)
                        </span>
                    </div>
                    <p className="text-xs text-slate-500 font-medium mt-1">
                        Visualisasi kurva tren pergerakan omset pesanan kaca & volume produksi pabrik
                    </p>
                </div>

                {/* MODE & TIMEFRAME SWITCHERS */}
                <div className="flex flex-wrap items-center gap-2 text-xs">
                    {/* TIMEFRAME BUTTONS */}
                    <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200 font-mono">
                        <button
                            onClick={() => setTimeframe('monthly')}
                            className={`px-3 py-1 rounded-lg font-bold transition cursor-pointer ${timeframe === 'monthly' ? 'bg-white text-[#1b68b0] shadow-xs border border-slate-200' : 'text-slate-600 hover:text-[#242222]'}`}
                        >
                            Bulanan (2026)
                        </button>
                        <button
                            onClick={() => setTimeframe('weekly')}
                            className={`px-3 py-1 rounded-lg font-bold transition cursor-pointer ${timeframe === 'weekly' ? 'bg-white text-[#1b68b0] shadow-xs border border-slate-200' : 'text-slate-600 hover:text-[#242222]'}`}
                        >
                            Mingguan (Q3)
                        </button>
                    </div>

                    {/* CHART TYPE SWITCHER */}
                    <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200 font-mono">
                        <button
                            onClick={() => setChartMode('line')}
                            title="Tampilan Garis Tren"
                            className={`px-2.5 py-1 rounded-lg font-bold transition cursor-pointer ${chartMode === 'line' ? 'bg-white text-[#1b68b0] shadow-xs border border-slate-200' : 'text-slate-600 hover:text-[#242222]'}`}
                        >
                            Line
                        </button>
                        <button
                            onClick={() => setChartMode('area')}
                            title="Tampilan Area Wave"
                            className={`px-2.5 py-1 rounded-lg font-bold transition cursor-pointer ${chartMode === 'area' ? 'bg-white text-[#1b68b0] shadow-xs border border-slate-200' : 'text-slate-600 hover:text-[#242222]'}`}
                        >
                            Area
                        </button>
                        <button
                            onClick={() => setChartMode('bar')}
                            title="Tampilan Volume Bar"
                            className={`px-2.5 py-1 rounded-lg font-bold transition cursor-pointer ${chartMode === 'bar' ? 'bg-white text-[#1b68b0] shadow-xs border border-slate-200' : 'text-slate-600 hover:text-[#242222]'}`}
                        >
                            Volume
                        </button>
                    </div>
                </div>
            </div>

            {/* TICKER HUD SUMMARY STRIP */}
            <div className="grid grid-cols-2 sm:grid-cols-6 gap-2 bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs font-mono">
                <div>
                    <span className="text-slate-500 text-[10px] block font-bold">PERIODE</span>
                    <strong className="text-[#1b68b0] font-black text-sm">{activeItem.period} 2026</strong>
                </div>
                <div>
                    <span className="text-slate-500 text-[10px] block font-bold">OPEN (PEMBUKA)</span>
                    <strong className="text-slate-700 font-bold">
                        {canViewPricing ? `Rp ${activeItem.open}M` : `${activeItem.open} SPO`}
                    </strong>
                </div>
                <div>
                    <span className="text-slate-500 text-[10px] block font-bold">HIGH (TERTINGGI)</span>
                    <strong className="text-emerald-700 font-bold">
                        {canViewPricing ? `Rp ${activeItem.high}M` : `${activeItem.high} SPO`}
                    </strong>
                </div>
                <div>
                    <span className="text-slate-500 text-[10px] block font-bold">LOW (TERENDAH)</span>
                    <strong className="text-rose-600 font-bold">
                        {canViewPricing ? `Rp ${activeItem.low}M` : `${activeItem.low} SPO`}
                    </strong>
                </div>
                <div>
                    <span className="text-slate-500 text-[10px] block font-bold">NOMINAL OMSET</span>
                    <strong className="text-[#242222] font-black text-sm">
                        {canViewPricing ? `Rp ${activeItem.close}M` : `${activeItem.close} SPO`}
                    </strong>
                </div>
                <div>
                    <span className="text-slate-500 text-[10px] block font-bold">VOLUME ORDER</span>
                    <span className="text-amber-700 font-bold">
                        {activeItem.volume} SPO ({activeItem.growth})
                    </span>
                </div>
            </div>

            {/* SVG VISUALIZATION */}
            <div className="w-full overflow-x-auto select-none pt-2">
                <svg
                    viewBox={`0 0 ${svgWidth} ${svgHeight}`}
                    className="w-full h-64 sm:h-72 overflow-visible"
                >
                    <defs>
                        <filter id="line-glow" x="-20%" y="-20%" width="140%" height="140%">
                            <feDropShadow dx="0" dy="2" stdDeviation="3" floodColor="#1b68b0" floodOpacity="0.25" />
                        </filter>
                        <linearGradient id="area-grad" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#1b68b0" stopOpacity="0.25" />
                            <stop offset="100%" stopColor="#1b68b0" stopOpacity="0.0" />
                        </linearGradient>
                    </defs>

                    {/* HORIZONTAL GRIDLINES & Y-AXIS LABELS */}
                    {[130, 100, 70, 40].map((levelVal) => {
                        const yPos = getY(levelVal);
                        return (
                            <g key={levelVal}>
                                <line
                                    x1={paddingLeft}
                                    y1={yPos}
                                    x2={svgWidth - paddingRight}
                                    y2={yPos}
                                    stroke="#e2e8f0"
                                    strokeDasharray="4 4"
                                    strokeWidth="1"
                                />
                                <text
                                    x={paddingLeft - 8}
                                    y={yPos + 3}
                                    fill="#94a3b8"
                                    fontSize="9"
                                    fontFamily="monospace"
                                    textAnchor="end"
                                >
                                    {canViewPricing ? `${levelVal}M` : `${levelVal}`}
                                </text>
                            </g>
                        );
                    })}

                    {/* SEPARATOR LINE ANTARA TREN & VOLUME */}
                    <line
                        x1={paddingLeft}
                        y1={chartBottom + 2}
                        x2={svgWidth - paddingRight}
                        y2={chartBottom + 2}
                        stroke="#cbd5e1"
                        strokeWidth="1"
                    />
                    <text
                        x={paddingLeft - 8}
                        y={chartBottom + 16}
                        fill="#94a3b8"
                        fontSize="8"
                        fontFamily="monospace"
                        textAnchor="end"
                    >
                        VOL
                    </text>

                    {/* AREA GRADIENT SHADING */}
                    {chartMode === 'area' && (
                        <path
                            d={areaPathD}
                            fill="url(#area-grad)"
                        />
                    )}

                    {/* MAIN TREND LINE */}
                    {chartMode !== 'bar' && (
                        <polyline
                            points={linePoints}
                            fill="none"
                            stroke="#1b68b0"
                            strokeWidth="3.5"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            filter="url(#line-glow)"
                        />
                    )}

                    {/* DATA NODES & VOLUME HISTOGRAM */}
                    {currentDataset.map((d, idx) => {
                        const centerX = paddingLeft + (idx + 0.5) * stepX;
                        const closeY = getY(d.close);
                        const candleWidth = Math.min(26, stepX * 0.55);
                        const isBullish = d.close >= d.open;
                        const isHovered = hoveredCandle?.period === d.period;

                        return (
                            <g
                                key={d.period}
                                className="cursor-pointer transition-opacity duration-200"
                                onMouseEnter={() => setHoveredCandle(d)}
                                onMouseLeave={() => setHoveredCandle(null)}
                            >
                                {/* HOVER COLUMN HIGHLIGHT BEAM */}
                                {isHovered && (
                                    <rect
                                        x={centerX - stepX * 0.45}
                                        y={10}
                                        width={stepX * 0.9}
                                        height={svgHeight - 35}
                                        fill="#1b68b0"
                                        fillOpacity="0.06"
                                        rx="8"
                                    />
                                )}

                                {/* NODE DOT ON TREND LINE */}
                                {chartMode !== 'bar' && (
                                    <g>
                                        <circle
                                            cx={centerX}
                                            cy={closeY}
                                            r={isHovered ? 7 : 4.5}
                                            fill={isBullish ? '#70b03c' : '#e11d48'}
                                            stroke="#ffffff"
                                            strokeWidth="2.5"
                                            className="transition-all duration-200"
                                        />

                                        {/* VALUE BADGE ON HOVER */}
                                        {isHovered && (
                                            <g>
                                                <rect
                                                    x={centerX - 35}
                                                    y={closeY - 32}
                                                    width="70"
                                                    height="18"
                                                    fill="#ffffff"
                                                    stroke="#cbd5e1"
                                                    strokeWidth="1"
                                                    rx="4"
                                                    filter="drop-shadow(0 2px 4px rgba(0,0,0,0.08))"
                                                />
                                                <text
                                                    x={centerX}
                                                    y={closeY - 20}
                                                    textAnchor="middle"
                                                    fill="#1b68b0"
                                                    fontSize="9"
                                                    fontWeight="bold"
                                                    fontFamily="monospace"
                                                >
                                                    {canViewPricing ? `Rp ${d.close}M` : `${d.close} SPO`}
                                                </text>
                                            </g>
                                        )}
                                    </g>
                                )}

                                {/* VOLUME HISTOGRAM BAR */}
                                <g>
                                    <rect
                                        x={centerX - (candleWidth * 0.7) / 2}
                                        y={svgHeight - 25 - getVolHeight(d.volume)}
                                        width={candleWidth * 0.7}
                                        height={getVolHeight(d.volume)}
                                        fill={isBullish ? '#70b03c' : '#f43f5e'}
                                        fillOpacity={isHovered ? 0.9 : 0.6}
                                        rx="2"
                                    />
                                </g>

                                {/* X-AXIS PERIOD LABEL */}
                                <text
                                    x={centerX}
                                    y={svgHeight - 8}
                                    fill={isHovered ? '#1b68b0' : (d.isPeak ? '#1b68b0' : '#64748b')}
                                    fontSize="10"
                                    fontFamily="monospace"
                                    fontWeight={d.isPeak || isHovered ? 'bold' : 'normal'}
                                    textAnchor="middle"
                                >
                                    {d.period}
                                </text>
                            </g>
                        );
                    })}
                </svg>
            </div>

            {/* CHART FOOTER METRICS */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-200 text-xs">
                <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-blue-50 border border-blue-200 flex items-center justify-center text-[#1b68b0] font-bold">
                        <BarChart3 className="w-4 h-4" />
                    </div>
                    <div>
                        <span className="text-slate-500 text-[11px] block font-medium">Rata-rata Omset Bulanan:</span>
                        <strong className="text-[#242222] font-mono text-xs">
                            {canViewPricing ? 'Rp 82.350.000' : '38.6 SPO'}
                        </strong>
                    </div>
                </div>

                <div className="flex items-center gap-3 border-t sm:border-t-0 sm:border-l border-slate-200 pt-2 sm:pt-0 sm:pl-3">
                    <div className="w-8 h-8 rounded-lg bg-emerald-50 border border-emerald-200 flex items-center justify-center text-[#70b03c] font-bold">
                        <ArrowUpRight className="w-4 h-4" />
                    </div>
                    <div>
                        <span className="text-slate-500 text-[11px] block font-medium">Bulan Puncak (All-Time High):</span>
                        <strong className="text-[#70b03c] font-mono text-xs">
                            {canViewPricing ? 'Agustus (Rp 128.5M)' : 'Agustus (58 SPO)'}
                        </strong>
                    </div>
                </div>

                <div className="flex items-center gap-3 border-t sm:border-t-0 sm:border-l border-slate-200 pt-2 sm:pt-0 sm:pl-3">
                    <div className="w-8 h-8 rounded-lg bg-purple-50 border border-purple-200 flex items-center justify-center text-purple-600 font-bold">
                        <Activity className="w-4 h-4" />
                    </div>
                    <div>
                        <span className="text-slate-500 text-[11px] block font-medium">Indikator Tren Moving Average:</span>
                        <strong className="text-purple-700 font-mono text-xs">
                            Garis MA-3 Bullish (+38.5% YoY)
                        </strong>
                    </div>
                </div>
            </div>
        </div>
    );
}
