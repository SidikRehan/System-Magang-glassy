import React, { useState } from 'react';
import { 
    Archive, Plus, Search, 
    ClipboardList, Send, 
    Box, MessageSquare, Package, User, Calendar,
    Edit, Trash2, X
} from 'lucide-react';
import { router } from '@inertiajs/react';
import EditSupplyModal from '@/Components/Modals/EditSupplyModal';

export default function WarehouseSuppliesTab({
    userRole,
    warehouseSuppliesList = [],
    supplyRestockRequests = [],
    supplyUsageLogs = [],
    supplySubTab = 'katalog',
    setSupplySubTab,
    supplySearchTerm = '',
    setSupplySearchTerm,
    handleOpenRequestRestockModal,
    setShowAddSupplyModal,
    setShowUseSupplyModal,
    handleApproveRestockRequest,
    handleCompleteRestockRequest,
    handleOpenSketchLightbox,
}) {
    const [showEditSupplyModal, setShowEditSupplyModal] = useState(false);
    const [selectedSupplyToEdit, setSelectedSupplyToEdit] = useState(null);

    const needingRestockSupplies = warehouseSuppliesList.filter(s => s.status === 'Menipis' || s.status === 'Habis').length;
    const activeRestockRequests = supplyRestockRequests.filter(r => r.status !== 'Selesai Restok').length;

    const filteredSupplies = warehouseSuppliesList.filter(s =>
        (s.name || '').toLowerCase().includes(supplySearchTerm.toLowerCase()) ||
        (s.item_code || '').toLowerCase().includes(supplySearchTerm.toLowerCase()) ||
        (s.category || '').toLowerCase().includes(supplySearchTerm.toLowerCase())
    );

    return (
        <div className="space-y-6">
            {/* HEADER TAB */}
            <div className="flex flex-wrap justify-between items-center gap-4">
                <div>
                    <h2 className="text-2xl font-black text-[#242222] flex items-center gap-2.5">
                        <Archive className="w-6 h-6 text-[#1b68b0]" />
                        <span>Perlengkapan & Consumables Gudang</span>
                    </h2>
                    <p className="text-slate-500 text-xs font-medium mt-1">
                        Monitoring inventory operasional gudang (APD, lakban, cutter, oli mesin potong) serta alur pengajuan restok ke Admin Toko.
                    </p>
                </div>
            </div>

            {/* 4 STATS CARDS */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
                    <span className="text-xs text-slate-500 font-semibold block">Total Jenis Perlengkapan</span>
                    <h3 className="text-2xl font-black text-[#1b68b0] mt-1">{warehouseSuppliesList.length} Item</h3>
                </div>
                <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
                    <span className="text-xs text-slate-500 font-semibold block">Stok Aman</span>
                    <h3 className="text-2xl font-black text-[#70b03c] mt-1">{warehouseSuppliesList.filter(s => s.status === 'Aman').length} Item</h3>
                </div>
                <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
                    <span className="text-xs text-slate-500 font-semibold block">Stok Menipis / Perlu Restok</span>
                    <div className="flex items-center gap-2 mt-1">
                        <h3 className={`text-2xl font-black ${needingRestockSupplies > 0 ? 'text-amber-600' : 'text-slate-700'}`}>
                            {needingRestockSupplies} Item
                        </h3>
                        {needingRestockSupplies > 0 && (
                            <span className="bg-amber-50 text-amber-700 text-[10px] font-bold px-2 py-0.5 rounded-full border border-amber-200">
                                Perlu Restok
                            </span>
                        )}
                    </div>
                </div>
                <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs">
                    <span className="text-xs text-slate-500 font-semibold block">Pengajuan Restok Aktif</span>
                    <div className="flex items-center gap-2 mt-1">
                        <h3 className={`text-2xl font-black ${activeRestockRequests > 0 ? 'text-purple-600' : 'text-slate-700'}`}>
                            {activeRestockRequests} Pengajuan
                        </h3>
                        {activeRestockRequests > 0 && (
                            <span className="bg-purple-50 text-purple-700 text-[10px] font-bold px-2 py-0.5 rounded-full border border-purple-200">
                                Aktif
                            </span>
                        )}
                    </div>
                </div>
            </div>

            {/* BUTTON AJUKAN ITEM BARU GUDANG */}
            {(userRole === 'admin_gudang' || userRole === 'admin_toko' || userRole === 'owner') && (
                <div className="flex justify-start">
                    <button
                        onClick={() => setShowAddSupplyModal(true)}
                        className="bg-[#1b68b0] hover:bg-[#15528c] text-white font-bold px-4 py-2.5 rounded-xl shadow-xs text-xs flex items-center gap-2 transition cursor-pointer"
                    >
                        <Plus className="w-4 h-4" />
                        <span>Ajukan Barang Gudang Baru ke Finance</span>
                    </button>
                </div>
            )}

            {/* BUTTON ACTION & SUBTAB TOGGLE */}
            <div className="flex flex-wrap items-center justify-between gap-4 bg-white border border-slate-200 p-3 rounded-2xl shadow-xs">
                {/* SUBTAB PILLS */}
                <div className="flex flex-wrap items-center gap-1.5 bg-slate-100 p-1 rounded-xl border border-slate-200">
                    <button
                        onClick={() => setSupplySubTab('katalog')}
                        className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                            supplySubTab === 'katalog' 
                                ? 'bg-white text-[#1b68b0] shadow-xs border border-slate-200' 
                                : 'text-slate-600 hover:text-[#242222]'
                        }`}
                    >
                        <Box className="w-3.5 h-3.5" />
                        <span>Katalog Perlengkapan ({warehouseSuppliesList.length})</span>
                    </button>
                    <button
                        onClick={() => setSupplySubTab('usage_log')}
                        className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                            supplySubTab === 'usage_log' 
                                ? 'bg-white text-[#1b68b0] shadow-xs border border-slate-200' 
                                : 'text-slate-600 hover:text-[#242222]'
                        }`}
                    >
                        <ClipboardList className="w-3.5 h-3.5" />
                        <span>Log Pemakaian ({supplyUsageLogs.length})</span>
                    </button>
                    <button
                        onClick={() => setSupplySubTab('restock_requests')}
                        className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
                            supplySubTab === 'restock_requests' 
                                ? 'bg-white text-[#1b68b0] shadow-xs border border-slate-200' 
                                : 'text-slate-600 hover:text-[#242222]'
                        }`}
                    >
                        <Send className="w-3.5 h-3.5" />
                        <span>Pengajuan Restok</span>
                        {activeRestockRequests > 0 && (
                            <span className="bg-purple-100 text-purple-700 text-[10px] font-black px-2 py-0.5 rounded-full font-mono">
                                {activeRestockRequests}
                            </span>
                        )}
                    </button>
                </div>

                {/* ACTION BUTTONS */}
                <div className="flex flex-wrap items-center gap-2">
                    {(userRole === 'admin_gudang' || userRole === 'admin_toko' || userRole === 'owner') && (
                        <>
                            <button
                                onClick={() => handleOpenRequestRestockModal(null)}
                                className="bg-amber-500 hover:bg-amber-600 text-white font-bold px-3.5 py-2 rounded-xl text-xs flex items-center gap-1.5 transition shadow-xs cursor-pointer"
                            >
                                <Send className="w-3.5 h-3.5" />
                                <span>Ajukan Restok Stok Menipis</span>
                            </button>
                            {(userRole === 'admin_gudang' || userRole === 'owner') && (
                                <button
                                    onClick={() => setShowUseSupplyModal(true)}
                                    className="bg-[#1b68b0] hover:bg-[#15528c] text-white font-bold px-3.5 py-2 rounded-xl text-xs flex items-center gap-1.5 transition shadow-xs cursor-pointer"
                                >
                                    <ClipboardList className="w-3.5 h-3.5" />
                                    <span>Catat Pemakaian</span>
                                </button>
                            )}
                        </>
                    )}
                </div>
            </div>

            {/* SUBTAB CONTENT 1: KATALOG PERLENGKAPAN */}
            {supplySubTab === 'katalog' && (
                <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4 shadow-xs">
                    <div className="flex flex-wrap justify-between items-center gap-4 border-b border-slate-100 pb-3">
                        <div className="flex items-center gap-3">
                            <h3 className="font-black text-[#242222] text-sm flex items-center gap-2">
                                <Box className="w-4 h-4 text-[#1b68b0]" />
                                <span>Master Inventory Perlengkapan Gudang</span>
                            </h3>
                            <span className="text-xs bg-blue-50 text-[#1b68b0] px-2.5 py-0.5 rounded-full border border-blue-200 font-mono font-bold">
                                {filteredSupplies.length} Items
                            </span>
                        </div>

                        <div className="relative">
                            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                            <input
                                type="text"
                                placeholder="Cari Kode / Nama / Kategori..."
                                value={supplySearchTerm}
                                onChange={e => setSupplySearchTerm(e.target.value)}
                                className="bg-white border border-slate-300 rounded-xl pl-8 pr-3 py-1.5 text-xs text-[#242222] focus:border-[#1b68b0] focus:ring-1 focus:ring-[#1b68b0] focus:outline-none w-64"
                            />
                        </div>
                    </div>

                    <div className="overflow-x-auto border border-slate-200 rounded-xl">
                        <table className="w-full text-left text-xs">
                            <thead className="bg-slate-50/80 text-slate-500 uppercase font-bold text-[11px] border-b border-slate-200">
                                <tr>
                                    <th className="p-3 w-16 text-center">Foto Sample</th>
                                    <th className="p-3">Kode</th>
                                    <th className="p-3">Nama Perlengkapan / Sparepart</th>
                                    <th className="p-3">Kategori</th>
                                    <th className="p-3 text-center">Stok</th>
                                    <th className="p-3">Lokasi Simpan</th>
                                    <th className="p-3 text-center">Status</th>
                                    <th className="p-3 text-right">Aksi</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100">
                                {filteredSupplies.map(s => (
                                    <tr key={s.id} className="hover:bg-slate-50/70 transition">
                                        <td className="p-2 text-center">
                                            {s.image_path ? (
                                                <div 
                                                    onClick={() => handleOpenSketchLightbox && handleOpenSketchLightbox(s.image_path, s.name, {
                                                        type: 'supply',
                                                        subtitle: `Kode Barang: ${s.item_code || '-'} • ${s.name}`,
                                                        badge: 'Bahan Pembantu Gudang',
                                                        description: `Dokumentasi visual barang habis pakai operasional pabrik (${s.category || 'Perlengkapan'}). Digunakan untuk verifikasi stok fisik dan pengambilan barang di ${s.location || 'gudang'}.`,
                                                        itemCode: s.item_code,
                                                        category: s.category,
                                                        location: s.location || 'Gudang Utama',
                                                        stockQty: `${s.stock_qty ?? s.qty ?? 0} ${s.unit || 'unit'}`,
                                                    })}
                                                    className="w-10 h-10 rounded-xl overflow-hidden border border-slate-200 shadow-2xs mx-auto cursor-pointer group relative bg-white"
                                                    title="Klik untuk memperbesar foto sample perlengkapan"
                                                >
                                                    <img src={s.image_path.startsWith('http') || s.image_path.startsWith('blob:') || s.image_path.startsWith('/') ? s.image_path : `/storage/${s.image_path}`} alt={s.name} className="w-full h-full object-cover group-hover:scale-110 transition duration-200" />
                                                </div>
                                            ) : (
                                                <div className="w-10 h-10 rounded-xl bg-blue-50/80 border border-blue-100 flex items-center justify-center mx-auto text-[#1b68b0] shadow-2xs">
                                                    <Package className="w-5 h-5 text-[#1b68b0]" />
                                                </div>
                                            )}
                                        </td>
                                        <td className="p-3 font-mono text-[#1b68b0] font-bold">{s.item_code}</td>
                                        <td className="p-3 font-bold text-[#242222]">{s.name}</td>
                                        <td className="p-3 text-slate-500">{s.category}</td>
                                        <td className="p-3 text-center font-extrabold text-[#242222]">
                                            {s.stock_qty ?? s.qty ?? 0} <span className="text-[10px] text-slate-400 font-normal">{s.unit}</span>
                                        </td>
                                        <td className="p-3 text-slate-500">{s.location || 'Gudang Utama'}</td>
                                        <td className="p-3 text-center">
                                            <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${s.status === 'Aman' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : s.status === 'Menipis' ? 'bg-amber-50 text-amber-700 border border-amber-200' : 'bg-rose-50 text-rose-700 border border-rose-200'}`}>
                                                {s.status}
                                            </span>
                                        </td>
                                        <td className="p-3 text-right">
                                            <div className="flex items-center justify-end gap-1.5">
                                                {(userRole === 'admin_gudang' || userRole === 'admin_toko' || userRole === 'owner') && (
                                                    <button
                                                        onClick={() => handleOpenRequestRestockModal(s)}
                                                        className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1 cursor-pointer ${s.status !== 'Aman' ? 'bg-amber-500 hover:bg-amber-600 text-white shadow-xs' : 'bg-amber-50 hover:bg-amber-100 text-amber-700 border border-amber-200 shadow-2xs'}`}
                                                        title="Ajukan Pembelian / Restok Sparepart & Inventaris ini ke Finance"
                                                    >
                                                        <Send className="w-3.5 h-3.5" /> Ajukan Restok
                                                    </button>
                                                )}
                                                {(userRole === 'admin_gudang' || userRole === 'admin_toko' || userRole === 'owner') && (
                                                    <>
                                                        <button
                                                            onClick={() => { setSelectedSupplyToEdit(s); setShowEditSupplyModal(true); }}
                                                            className="bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 font-bold px-2 py-1.5 rounded-lg text-xs transition flex items-center gap-1 cursor-pointer shadow-2xs"
                                                            title="Edit Perlengkapan"
                                                        >
                                                            <Edit className="w-3.5 h-3.5" /> Edit
                                                        </button>
                                                        <button
                                                            onClick={() => {
                                                                if (confirm(`Yakin ingin menghapus perlengkapan "${s.name}"? Data yang dihapus tidak dapat dikembalikan.`)) {
                                                                    router.delete(route('inventory.supplies.destroy', s.id), { preserveScroll: true });
                                                                }
                                                            }}
                                                            className="bg-white hover:bg-rose-50 text-rose-600 hover:text-rose-700 border border-slate-200 hover:border-rose-200 font-bold p-1.5 rounded-lg text-xs transition flex items-center justify-center cursor-pointer shadow-2xs"
                                                            title="Hapus Perlengkapan"
                                                        >
                                                            <Trash2 className="w-3.5 h-3.5" />
                                                        </button>
                                                    </>
                                                )}
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                                {filteredSupplies.length === 0 && (
                                    <tr>
                                        <td colSpan="8" className="p-8 text-center text-slate-400 text-xs italic">
                                            Tidak ada perlengkapan yang sesuai dengan pencarian.
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}

            {/* SUBTAB CONTENT 2: LOG PEMAKAIAN */}
            {supplySubTab === 'usage_log' && (
                <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4 shadow-xs">
                    <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                        <ClipboardList className="w-4 h-4 text-[#1b68b0]" />
                        <h3 className="font-black text-[#242222] text-sm">Riwayat & Log Pemakaian Perlengkapan Operasional</h3>
                    </div>
                    <div className="overflow-x-auto border border-slate-200 rounded-xl">
                        <table className="w-full text-left text-xs">
                            <thead className="bg-slate-50/80 text-slate-500 uppercase font-bold text-[11px] border-b border-slate-200">
                                <tr>
                                    <th className="p-3">Tanggal</th>
                                    <th className="p-3">Kode & Nama Perlengkapan</th>
                                    <th className="p-3 text-center">Jumlah Dipakai</th>
                                    <th className="p-3">Divisi Pengambil</th>
                                    <th className="p-3">Nama Pengambil</th>
                                    <th className="p-3">Catatan Pemakaian</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100">
                                {supplyUsageLogs.map(log => (
                                    <tr key={log.id} className="hover:bg-slate-50/70 transition">
                                        <td className="p-3 text-slate-500 flex items-center gap-1.5">
                                            <Calendar className="w-3.5 h-3.5 text-slate-400" />
                                            <span>{log.usage_date}</span>
                                        </td>
                                        <td className="p-3">
                                            <div className="font-bold text-[#242222]">{log.item_name}</div>
                                            <div className="text-[10px] font-mono text-[#1b68b0]">{log.item_code}</div>
                                        </td>
                                        <td className="p-3 text-center font-black text-[#1b68b0]">
                                            {log.used_qty} {log.unit}
                                        </td>
                                        <td className="p-3 font-semibold text-slate-700">{log.user_division}</td>
                                        <td className="p-3 text-slate-700">
                                            <div className="flex items-center gap-1">
                                                <User className="w-3.5 h-3.5 text-slate-400" />
                                                <span>{log.taker_name}</span>
                                            </div>
                                        </td>
                                        <td className="p-3 text-slate-500 italic">{log.notes || '-'}</td>
                                    </tr>
                                ))}
                                {supplyUsageLogs.length === 0 && (
                                    <tr>
                                        <td colSpan="6" className="p-8 text-center text-slate-400 text-xs italic">
                                            Belum ada log pemakaian perlengkapan gudang.
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}

            {/* SUBTAB CONTENT 3: PENGAJUAN RESTOK KE ADMIN TOKO */}
            {supplySubTab === 'restock_requests' && (
                <div className="bg-white border border-slate-200 rounded-2xl p-5 space-y-4 shadow-xs">
                    <div className="flex flex-wrap justify-between items-center gap-4 border-b border-slate-100 pb-3">
                        <div>
                            <h3 className="font-black text-[#242222] text-sm flex items-center gap-2">
                                <Send className="w-4 h-4 text-[#1b68b0]" />
                                <span>Daftar Pengajuan Pembelian Sparepart & Perlengkapan ke Finance</span>
                            </h3>
                            <p className="text-xs text-slate-500 font-medium">Monitoring pengajuan restok sparepart/inventaris produksi yang diajukan ke bagian Finance untuk disetujui & dipesan.</p>
                        </div>
                        {(userRole === 'admin_gudang' || userRole === 'admin_toko' || userRole === 'owner') && (
                            <button
                                onClick={() => handleOpenRequestRestockModal(null)}
                                className="bg-amber-500 hover:bg-amber-600 text-white font-bold px-3.5 py-2 rounded-xl text-xs flex items-center gap-1.5 transition shadow-xs cursor-pointer"
                            >
                                <Plus className="w-3.5 h-3.5" /> Ajukan Restok ke Finance
                            </button>
                        )}
                    </div>

                    <div className="overflow-x-auto border border-slate-200 rounded-xl">
                        <table className="w-full text-left text-xs">
                            <thead className="bg-slate-50/80 text-slate-500 uppercase font-bold text-[11px] border-b border-slate-200">
                                <tr>
                                    <th className="p-3">Tanggal</th>
                                    <th className="p-3">Kode & Nama Perlengkapan</th>
                                    <th className="p-3 text-center">Jumlah Restok</th>
                                    <th className="p-3">Prioritas</th>
                                    <th className="p-3">Diajukan Oleh</th>
                                    <th className="p-3">Catatan / Keperluan</th>
                                    <th className="p-3 text-center">Status</th>
                                    <th className="p-3 text-right">Aksi</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-100">
                                {supplyRestockRequests.map(req => (
                                    <tr key={req.id} className="hover:bg-slate-50/70 transition">
                                        <td className="p-3 text-slate-500">{req.requested_at || req.request_date || '-'}</td>
                                        <td className="p-3">
                                            <div className="font-bold text-[#242222]">{req.item_name}</div>
                                            <div className="text-[10px] font-mono text-[#1b68b0]">{req.item_code} (Sisa: {req.current_stock ?? 0} {req.unit})</div>
                                        </td>
                                        <td className="p-3 text-center font-black text-amber-700">
                                            +{req.request_qty} {req.unit}
                                        </td>
                                        <td className="p-3">
                                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${String(req.priority || 'Biasa').includes('Mendesak') || String(req.priority || '').includes('Darurat') ? 'bg-rose-50 text-rose-700 border border-rose-200' : 'bg-slate-100 text-slate-700'}`}>
                                                {req.priority || 'Mendesak / Stok Menipis'}
                                            </span>
                                        </td>
                                        <td className="p-3 text-slate-700">{req.requested_by || req.requester_name || 'Admin Gudang'}</td>
                                        <td className="p-3 text-slate-500 italic max-w-xs truncate">{req.notes || '-'}</td>
                                        <td className="p-3 text-center">
                                            <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${String(req.status || '').startsWith('Menunggu') ? 'bg-amber-50 text-amber-700 border border-amber-200' : String(req.status || '').startsWith('Disetujui') ? 'bg-blue-50 text-blue-700 border border-blue-200' : 'bg-emerald-50 text-emerald-700 border border-emerald-200'}`}>
                                                {req.status}
                                            </span>
                                        </td>
                                        <td className="p-3 text-right">
                                            <div className="flex justify-end gap-1.5">
                                                {String(req.status || '').startsWith('Menunggu') && !String(req.status || '').includes('Finance') && (userRole === 'admin_toko' || userRole === 'owner') && (
                                                    <button
                                                        onClick={() => handleApproveRestockRequest(req.id)}
                                                        className="bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 font-bold px-2.5 py-1.5 rounded-lg text-xs transition shadow-2xs cursor-pointer flex items-center gap-1"
                                                        title="Teruskan pengajuan ini ke bagian Finance untuk disetujui & dipesan"
                                                    >
                                                        <Send className="w-3.5 h-3.5" /> Teruskan ke Finance
                                                    </button>
                                                )}

                                                {String(req.status || '').startsWith('Menunggu') && (userRole === 'admin_gudang' || userRole === 'owner') && (
                                                    <button
                                                        onClick={() => {
                                                            if (confirm(`Batalkan pengajuan restok "${req.item_name}"?`)) {
                                                                router.delete(route('inventory.supplies.restock_cancel', req.id), { preserveScroll: true });
                                                            }
                                                        }}
                                                        className="bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-bold px-2.5 py-1.5 rounded-lg text-xs transition shadow-2xs cursor-pointer flex items-center gap-1"
                                                        title="Batalkan pengajuan restok barang ini (antisipasi salah klik)"
                                                    >
                                                        <X className="w-3.5 h-3.5" /> Batal
                                                    </button>
                                                )}

                                                {String(req.status || '').startsWith('Disetujui') && (userRole === 'admin_gudang' || userRole === 'admin_toko' || userRole === 'owner') && (
                                                    <button
                                                        onClick={() => handleCompleteRestockRequest(req)}
                                                        className="bg-blue-50 hover:bg-blue-100 text-[#1b68b0] border border-blue-200 font-bold px-2.5 py-1.5 rounded-lg text-xs transition shadow-2xs cursor-pointer flex items-center gap-1"
                                                        title="Konfirmasi barang sudah tiba di gudang"
                                                    >
                                                        <Box className="w-3.5 h-3.5" /> Tiba
                                                    </button>
                                                )}

                                                <button
                                                    onClick={() => {
                                                        const waMsg = `Halo Admin Toko SYP Glass,%0A%0AFollow-up Pengajuan Restok Perlengkapan Gudang:%0A• Barang: [${req.item_code}] ${req.item_name}%0A• Jumlah: ${req.request_qty} ${req.unit}%0A• Status Saat Ini: ${req.status}`;
                                                        window.open(`https://api.whatsapp.com/send?text=${waMsg}`, '_blank');
                                                    }}
                                                    className="bg-white hover:bg-slate-50 text-emerald-700 border border-slate-200 px-2 py-1.5 rounded-lg text-xs font-bold transition shadow-2xs cursor-pointer flex items-center gap-1"
                                                    title="Kirim pesan WhatsApp"
                                                >
                                                    <MessageSquare className="w-3.5 h-3.5" /> WA
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                                {supplyRestockRequests.length === 0 && (
                                    <tr>
                                        <td colSpan="8" className="p-8 text-center text-slate-400 text-xs italic">
                                            Belum ada data pengajuan restok.
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}

            {/* MODAL EDIT PERLENGKAPAN GUDANG */}
            <EditSupplyModal
                show={showEditSupplyModal}
                onClose={() => {
                    setShowEditSupplyModal(false);
                    setSelectedSupplyToEdit(null);
                }}
                supply={selectedSupplyToEdit}
            />
        </div>
    );
}
